<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Clinic Management System</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: "Segoe UI", Arial, sans-serif; }
body { background: #f4f8fb; color: #333; line-height: 1.6; }

/* Header Styles */
header { 
    background: linear-gradient(135deg, #4168a1, #0aa2c0); 
    color: white; 
    padding: 20px 60px; 
    display: flex; 
    justify-content: space-between; 
    align-items: center;
    position: sticky;
    top: 0;
    z-index: 1000;
    box-shadow: 0 2px 15px rgba(0,0,0,0.1);
}
header h1 { font-size: 24px; letter-spacing: 1px; }
nav { display: flex; gap: 20px; }
nav a { 
    color: white; 
    text-decoration: none; 
    padding: 8px 15px;
    border-radius: 5px;
    font-weight: 500;
    transition: all 0.3s;
}
nav a:hover { 
    background: rgba(255,255,255,0.1); 
    transform: translateY(-2px);
}

/* Hero Section */
.hero { 
    height: 85vh; 
    display: flex; 
    align-items: center; 
    justify-content: space-between; 
    padding: 60px; 
    background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url("https://images.unsplash.com/photo-1586773860418-d37222d8fce3") center/cover; 
    color: white; 
}
.hero-text { max-width: 600px; }
.hero-text h2 { font-size: 46px; margin-bottom: 20px; }
.hero-text p { font-size: 18px; line-height: 1.6; margin-bottom: 30px; }
.hero-buttons a { 
    display: inline-block; 
    padding: 14px 28px; 
    margin-right: 15px; 
    background: #5482c7; 
    color: white; 
    text-decoration: none; 
    border-radius: 30px; 
    font-weight: bold; 
    transition: 0.3s; 
}
.hero-buttons a.secondary { background: transparent; border: 2px solid white; }
.hero-buttons a:hover { transform: translateY(-3px); background: #4a76b8; }

/* Features Section */
.features { 
    padding: 80px 60px; 
    background: white; 
    text-align: center; 
}
.features h2 { font-size: 36px; margin-bottom: 40px; }
.feature-grid { 
    display: grid; 
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
    gap: 30px; 
}
.feature-box { 
    background: #f4f8fb; 
    padding: 30px; 
    border-radius: 15px; 
    transition: 0.3s; 
    border: 1px solid #e0e0e0;
}
.feature-box:hover { 
    transform: translateY(-8px); 
    box-shadow: 0 10px 25px rgba(0,0,0,0.1); 
    border-color: #4168a1;
}
.feature-box h3 { margin-bottom: 15px; color: #6189c5; }

/* Roles Section */
.roles { padding: 80px 60px; background: #eef5ff; }
.roles h2 { text-align: center; font-size: 36px; margin-bottom: 40px; }
.role-grid { 
    display: grid; 
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); 
    gap: 25px; 
}
.role { 
    background: white; 
    padding: 25px; 
    border-radius: 15px; 
    text-align: center;
    transition: transform 0.3s;
}
.role:hover {
    transform: translateY(-5px);
}
.role h3 { margin-bottom: 10px; color: #0aa2c0; }

/* Advanced Modules */
.advanced-modules {
    padding: 80px 60px;
    background: #f8fafc;
}
.advanced-modules h2 {
    text-align: center;
    font-size: 36px;
    margin-bottom: 40px;
    color: #2c3e50;
}
.module-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}
.module-card {
    background: white;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: all 0.3s;
    border-left: 5px solid #4168a1;
}
.module-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}
.module-card h3 {
    color: #4168a1;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.module-card p {
    color: #666;
    line-height: 1.6;
}
.module-icon {
    font-size: 24px;
    color: #0aa2c0;
}

/* Contact Section */
.contact-section {
    padding: 80px 60px;
    background: linear-gradient(135deg, #4168a1, #0aa2c0);
    color: white;
}
.contact-section h2 {
    text-align: center;
    font-size: 36px;
    margin-bottom: 40px;
}
.contact-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 40px;
}
.contact-form input,
.contact-form textarea {
    width: 100%;
    padding: 15px;
    margin-bottom: 15px;
    border: none;
    border-radius: 8px;
    background: rgba(255,255,255,0.9);
}
.contact-form button {
    background: #ffdd57;
    color: #333;
    border: none;
    padding: 15px 30px;
    border-radius: 30px;
    font-weight: bold;
    cursor: pointer;
    transition: 0.3s;
}
.contact-form button:hover {
    background: #ffd32a;
    transform: translateY(-2px);
}

/* About Section */
.about-section {
    padding: 80px 60px;
    background: white;
}
.about-section h2 {
    text-align: center;
    font-size: 36px;
    margin-bottom: 40px;
    color: #2c3e50;
}
.about-content {
    max-width: 800px;
    margin: 0 auto;
    text-align: center;
}

/* Footer */
.footer { 
    background: #2c3e50; 
    color: white; 
    padding: 60px; 
}
.footer-grid { 
    display: grid; 
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); 
    gap: 40px; 
}
.footer h3 { 
    margin-bottom: 20px; 
    font-size: 18px; 
    color: #ffdd57; 
    position: relative;
    padding-bottom: 10px;
}
.footer h3::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 50px;
    height: 3px;
    background: #0aa2c0;
}
.footer p, .footer a { 
    font-size: 14px; 
    line-height: 1.6; 
    color: #e9f1ff; 
    text-decoration: none; 
    margin-bottom: 10px;
    display: block;
}
.footer a:hover { 
    color: #ffdd57; 
    padding-left: 5px;
    transition: all 0.3s;
}
.footer-bottom { 
    margin-top: 40px; 
    text-align: center; 
    border-top: 1px solid rgba(255,255,255,0.3); 
    padding-top: 20px; 
    font-size: 13px; 
    color: #bdc3c7;
}

/* Responsive Design */
@media (max-width: 768px) {
    header { padding: 20px; flex-direction: column; gap: 15px; }
    nav { flex-wrap: wrap; justify-content: center; }
    .hero { padding: 40px 20px; text-align: center; }
    .hero-text h2 { font-size: 32px; }
    .features, .roles, .advanced-modules, .about-section, .contact-section { 
        padding: 40px 20px; 
    }
    .footer { padding: 40px 20px; }
}
</style>
</head>

<body>

<!-- HEADER -->
<header>
    <img src="download.png" alt="Clinic Logo" style="width: 100px;  height: auto;">
    <h1>Clinic Management System</h1>
    <nav>
        <a href="#home">Home</a>
        <a href="#about">About</a>
        <a href="#features">Features</a>
        <a href="#modules">Advanced Modules</a>
        <a href="#contact">Contact</a>
        <a href="login.php" style="background: rgba(255,255,255,0.2);">Login</a>
        <a href="singup.php" style="background: #ffdd57; color: #333; font-weight: bold;">Signup</a>
    </nav>
</header>

<!-- HERO (Home Section) -->
<section style="height: 1200PX;" id="home" class="hero">
    <div class="hero-text">
        <h2>Bonga Universty Clinic Managment systems</h2>
        <h1>BU Clinic, Student Health: Better Care</h1>
        <p>
            A complete digital solution to manage patients, doctors,
            appointments, medical records, and billing — all in one secure system.
        </p>
        <div class="hero-buttons">
            <a href="login.php">Get Started</a>
            <a href="#about" class="secondary">Learn More</a>
        </div>
    </div>
</section>

<!-- FEATURES -->
<section id="features" class="features">
    <h2>System Features</h2>
    <div class="feature-grid">
        <div class="feature-box">
            <img src="admin.png" alt="Patient Management" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px;">
            <h3>Patient Management</h3>
            <p>Register, track, and manage patient medical history securely with comprehensive profiles and health tracking.</p>
        </div>
        <div class="feature-box">
            <img src="doc.png" alt="Doctor Scheduling" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px;">
            <h3>Doctor Scheduling</h3>
            <p>Smart appointment scheduling with real-time doctor availability, automated reminders, and calendar sync.</p>
        </div>
        <div class="feature-box">
            <img src="med.png" alt="Medical Records" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px;">
            <h3>Medical Records</h3>
            <p>Centralized electronic health records with secure access, prescription tracking, and treatment history.</p>
        </div>
        <div class="feature-box">
            <img src="pationt.png" alt="Billing & Reports" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px;">
            <h3>Billing & Reports</h3>
            <p>Automated billing system with insurance integration, financial reports, and payment tracking.</p>
        </div>
    </div>
</section>

<!-- ABOUT SECTION -->
<section style="background-color: #627d83;" id="about" class="about-section">
    <h2>About Our System</h2>
    <div class="about-content">
        <p style="font-size: 18px; line-height: 1.8; margin-bottom: 30px;">
            The Clinic Management System is a comprehensive healthcare solution designed to streamline 
            medical practice operations. Our platform bridges the gap between patients, doctors, and 
            administrators through innovative technology.
        </p>
        <div style="display: flex; flex-wrap: wrap; gap: 30px; justify-content: center; margin-top: 40px;">
            <div style="flex: 1; min-width: 250px; background: #f4f8fb; padding: 25px; border-radius: 10px;">
                <h3 style="color: #4168a1; margin-bottom: 15px;">Our Mission</h3>
                <p>To provide accessible, efficient, and secure healthcare management solutions for modern clinics.</p>
            </div>
            <div style="flex: 1; min-width: 250px; background: #f4f8fb; padding: 25px; border-radius: 10px;">
                <h3 style="color: #4168a1; margin-bottom: 15px;">Our Vision</h3>
                <p>To revolutionize healthcare management through technology innovation and user-centric design.</p>
            </div>
        </div>
    </div>
</section>

<!-- ADVANCED MODULES -->
<section style="background-color: #b6a7bb;" id="modules" class="advanced-modules">
    <h2>Advanced System Modules</h2>
    <div class="module-grid">
        <div class="module-card">
            <h3><i class="fas fa-robot module-icon"></i> AI-Powered Diagnostics</h3>
            <p>Advanced artificial intelligence algorithms assist in preliminary diagnosis and treatment recommendations based on symptoms and medical history.</p>
        </div>
        <div class="module-card">
            <h3><i class="fas fa-chart-line module-icon"></i> Analytics Dashboard</h3>
            <p>Comprehensive analytics with real-time insights into clinic performance, patient statistics, and revenue tracking.</p>
        </div>
        <div class="module-card">
            <h3><i class="fas fa-mobile-alt module-icon"></i> Mobile Integration</h3>
            <p>Fully responsive mobile application for patients to book appointments, view records, and receive notifications.</p>
        </div>
        <div class="module-card">
            <h3><i class="fas fa-shield-alt module-icon"></i> Security Suite</h3>
            <p>Advanced encryption, multi-factor authentication, and HIPAA compliance for maximum data security.</p>
        </div>
        <div class="module-card">
            <h3><i class="fas fa-pills module-icon"></i> Pharmacy Management</h3>
            <p>Integrated pharmacy module for inventory management, prescription fulfillment, and drug interaction alerts.</p>
        </div>
        <div class="module-card">
            <h3><i class="fas fa-video module-icon"></i> Telemedicine</h3>
            <p>Virtual consultation module with video conferencing, screen sharing, and remote patient monitoring.</p>
        </div>
        <div class="module-card">
            <h3><i class="fas fa-database module-icon"></i> Data Migration</h3>
            <p>Seamless migration from legacy systems with data validation and integrity checks.</p>
        </div>
        <div class="module-card">
            <h3><i class="fas fa-bell module-icon"></i> Smart Alerts</h3>
            <p>Automated alerts for critical values, appointment reminders, medication schedules, and follow-ups.</p>
        </div>
    </div>
</section>

<!-- ROLES -->
<section class="roles">
    <h2>System Users</h2>
    <div class="role-grid">
        <div class="role">
            <img src="admin.png" alt="Admin" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px;">
            <h3>Administrator</h3>
            <p>Full system control, user management, reports generation, and system configuration.</p>
        </div>
        <div class="role">
            <img src="doc.png" alt="Doctor" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px;">
            <h3>Doctor</h3>
            <p>Patient consultations, diagnosis, prescription management, and medical records.</p>
        </div>
        <div class="role">
            <img src="med.png" alt="Receptionist" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px;">
            <h3>Receptionist</h3>
            <p>Appointment scheduling, patient registration, billing, and front desk operations.</p>
        </div>
        <div class="role">
            <img src="pationt.png" alt="Patient" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 15px;">
            <h3>Patient</h3>
            <p>Appointment booking, medical history access, prescription viewing, and communication.</p>
        </div>
    </div>
</section>

<!-- CONTACT SECTION -->
<section style="background-color: #adda65;" id="contact" class="contact-section">
    <h2>Contact Us</h2>
    <div class="contact-grid">
        <div>
            <h3>Get in Touch</h3>
            <p><i class="fas fa-map-marker-alt"></i> Addis Ababa, Ethiopia</p>
            <p><i class="fas fa-phone"></i> +251 900 000 000</p>
            <p><i class="fas fa-envelope"></i> clinic@example.com</p>
            <p><i class="fas fa-clock"></i> Mon – Fri: 8:00 AM – 6:00 PM</p>
           <div style="margin-top: 20px;">
    <a href="https://www.facebook.com/YourClinicPage" target="_blank" rel="noopener noreferrer" style="display: inline-block; margin-right: 15px; font-size: 20px; color: #1877f2; text-decoration: none;" aria-label="Facebook">
        <i class="fab fa-facebook"></i>
    </a>
    <a href="https://twitter.com/YourClinicHandle" target="_blank" rel="noopener noreferrer" style="display: inline-block; margin-right: 15px; font-size: 20px; color: #1da1f2; text-decoration: none;" aria-label="Twitter">
        <i class="fab fa-twitter"></i>
    </a>
    <a href="https://www.linkedin.com/company/YourClinicName" target="_blank" rel="noopener noreferrer" style="display: inline-block; margin-right: 15px; font-size: 20px; color: #0a66c2; text-decoration: none;" aria-label="LinkedIn">
        <i class="fab fa-linkedin"></i>
    </a>
    <a href="https://www.instagram.com/YourClinicHandle" target="_blank" rel="noopener noreferrer" style="display: inline-block; font-size: 20px; color: #e1306c; text-decoration: none;" aria-label="Instagram">
        <i class="fab fa-instagram"></i>
    </a>
</div>
        </div>
        <div>
            <form class="contact-form">
                <input type="text" placeholder="Your Name" required>
                <input type="email" placeholder="Your Email" required>
                <input type="text" placeholder="Subject" required>
                <textarea placeholder="Your Message" rows="5" required></textarea>
                <button type="submit">Send Message</button>
            </form>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="footer">
    <div class="footer-grid">
        <div>
            <h3>Clinic Management System</h3>
            <p>
                A comprehensive digital healthcare management platform designed to 
                streamline clinic operations, enhance patient care, and improve 
                administrative efficiency.
            </p>
            <p><strong>Version:</strong> 3.0.1</p>
            <p><strong>Release Date:</strong> January 2024</p>
        </div>
        <div>
            <h3>Quick Navigation</h3>
            <a href="#home">Home</a>
            <a href="#about">About System</a>
            <a href="#features">Core Features</a>
            <a href="#modules">Advanced Modules</a>
            <a href="#contact">Contact Support</a>
            <a href="login.php">Login Portal</a>
            <a href="singup.php">User Registration</a>
        </div>
        <div>
            <h3>System Modules</h3>
            <a href="#">Patient Management</a>
            <a href="#">Doctor Scheduling</a>
            <a href="#">Medical Records</a>
            <a href="#">Billing System</a>
            <a href="#">Pharmacy Module</a>
            <a href="#">Laboratory Module</a>
            <a href="#">Reporting & Analytics</a>
        </div>
        <div>
            <h3>Technical Support</h3>
            <p><i class="fas fa-headset"></i> Support: support@clinic.com</p>
            <p><i class="fas fa-bug"></i> Bug Reports: bugs@clinic.com</p>
            <p><i class="fas fa-download"></i> Documentation</p>
            <p><i class="fas fa-code-branch"></i> API Access</p>
            <p><i class="fas fa-cloud-upload-alt"></i> System Updates</p>
            <p><i class="fas fa-database"></i> Data Backup</p>
        </div>
    </div>
    <div class="footer-bottom">
        <p>© 2026 Clinic Management System | Developed for Academic Purpose | All Rights Reserved</p>
        <p style="margin-top: 10px; font-size: 12px;">
            <a href="#" style="margin: 0 10px;">Privacy Policy</a> | 
            <a href="#" style="margin: 0 10px;">Terms of Service</a> | 
            <a href="#" style="margin: 0 10px;">Cookie Policy</a> | 
            <a href="#" style="margin: 0 10px;">HIPAA Compliance</a>
    <a href="https://www.w3schools.com/">
    <span style="font-size: 40px; font-weight: bold;">W-3schools</span>
</a>   </p>
    </div>
</footer>

<!-- Smooth Scroll Script -->
<script>
// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        if(targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if(targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 80,
                behavior: 'smooth'
            });
        }
    });
});

// Form submission handler
document.querySelector('.contact-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for your message! We will contact you soon.');
    this.reset();
});

// Add active class to current section in navigation
window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('nav a');
    
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if(scrollY >= (sectionTop - 100)) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if(link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});
</script>

</body>
</html>