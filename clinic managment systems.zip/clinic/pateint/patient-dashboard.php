<?php
session_start();
require "../db.php";

// Check if user is logged in and is patient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'patient') {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Patient Dashboard</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Arial, sans-serif;
}

body {
    background: #e3f2fd;
    display: flex;
}

/* Sidebar */
.sidebar {
    width: 250px;
    background: #1565c0;
    color: white;
    height: 100vh;
    position: fixed;
    padding: 20px;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 12px 15px;
    margin: 8px 0;
    border-radius: 5px;
    transition: background 0.3s;
}

.sidebar a:hover {
    background: #1976d2;
}

/* Main Content */
.main {
    margin-left: 250px;
    padding: 20px;
    width: calc(100% - 250px);
}

.header {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.header h1 {
    color: #1565c0;
    margin-bottom: 10px;
}

/* Cards */
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.card {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    text-align: center;
    transition: transform 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

.card h3 {
    color: #1565c0;
    margin-bottom: 15px;
}

.btn {
    display: inline-block;
    background: #1565c0;
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    text-decoration: none;
    margin-top: 10px;
}

.logout-btn {
    position: absolute;
    bottom: 20px;
    left: 20px;
    right: 20px;
    background: #d32f2f;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    text-align: center;
    text-decoration: none;
    display: block;
}
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>Patient Panel</h2>
    <a href="patient-dashboard.php" style="background: rgba(255,255,255,0.2);">Dashboard</a>
    <a href="#">My Appointments</a>
    <a href="#">Prescriptions</a>
    <a href="#">Medical History</a>
    <a href="#">My Profile</a>
    <a href="../logout.php" class="logout-btn">Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <div class="header">
        <h1>Welcome <?php echo $_SESSION['name']; ?> 👤</h1>
        <p>Patient Dashboard - Clinic Management System</p>
    </div>

    <div class="cards">
        <div class="card">
            <h3>Upcoming Appointments</h3>
            <h2 style="font-size: 36px; color: #1565c0;">2</h2>
            <p>You have 2 appointments scheduled</p>
            <a href="#" class="btn">View All</a>
        </div>

        <div class="card">
            <h3>Active Prescriptions</h3>
            <h2 style="font-size: 36px; color: #4caf50;">3</h2>
            <p>Prescriptions from doctors</p>
            <a href="#" class="btn">View Prescriptions</a>
        </div>

        <div class="card">
            <h3>Medical Records</h3>
            <p>View your complete medical history and test results</p>
            <a href="#" class="btn">View Records</a>
        </div>

        <div class="card">
            <h3>Book Appointment</h3>
            <p>Schedule a new appointment with a doctor</p>
            <a href="#" class="btn">Book Now</a>
        </div>
    </div>
</div>

</body>
</html>