<?php
session_start();
require "../db.php";

// Check if user is logged in and is receptionist
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'receptionist') {
    header("Location: ../login.php");
    exit();
}

// Initialize variables
$action = $_GET['action'] ?? 'dashboard';
$success_message = $_GET['success'] ?? '';
$error_message = $_GET['error'] ?? '';

// Handle different actions
switch($action) {
    case 'register':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
            
            try {
                $stmt = $conn->prepare("INSERT INTO patients (name, email, phone, address, created_at) VALUES (?, ?, ?, ?, NOW())");
                $stmt->bind_param("ssss", $name, $email, $phone, $address);
                if ($stmt->execute()) {
                    $success_message = "Patient registered successfully! Patient ID: " . $conn->insert_id;
                } else {
                    $error_message = "Error registering patient.";
                }
            } catch (Exception $e) {
                $error_message = "Please create patients table first.";
            }
        }
        break;
        
    case 'book_appointment':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $patient_name = $_POST['patient_name'];
            $patient_phone = $_POST['patient_phone'];
            $doctor = $_POST['doctor'];
            $date = $_POST['date'];
            $time = $_POST['time'];
            $reason = $_POST['reason'];
            
            try {
                $stmt = $conn->prepare("INSERT INTO appointments (patient_name, patient_phone, doctor, appointment_date, appointment_time, reason, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'scheduled', NOW())");
                $stmt->bind_param("ssssss", $patient_name, $patient_phone, $doctor, $date, $time, $reason);
                if ($stmt->execute()) {
                    $success_message = "Appointment booked successfully!";
                }
            } catch (Exception $e) {
                $error_message = "Please create appointments table first.";
            }
        }
        break;
        
    case 'pay_bill':
        if (isset($_GET['id'])) {
            $bill_id = $_GET['id'];
            try {
                $stmt = $conn->prepare("UPDATE invoices SET status = 'paid', paid_date = NOW() WHERE id = ?");
                $stmt->bind_param("i", $bill_id);
                if ($stmt->execute()) {
                    $success_message = "Payment recorded successfully!";
                }
            } catch (Exception $e) {
                $error_message = "Please create invoices table first.";
            }
        }
        break;
        
    case 'search':
        $search_results = [];
        if (isset($_GET['query'])) {
            $query = "%" . $_GET['query'] . "%";
            try {
                $stmt = $conn->prepare("SELECT * FROM patients WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? LIMIT 10");
                $stmt->bind_param("sss", $query, $query, $query);
                $stmt->execute();
                $search_results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            } catch (Exception $e) {
                // Table doesn't exist, use sample data
                $search_results = [
                    ['id' => 1, 'name' => 'John Doe', 'phone' => '555-0101', 'email' => 'john@example.com'],
                    ['id' => 2, 'name' => 'Jane Smith', 'phone' => '555-0102', 'email' => 'jane@example.com']
                ];
            }
        }
        break;
}

// Fetch dashboard statistics with fallback
$today = date('Y-m-d');
$stats = [
    'registrations' => 0,
    'appointments' => 0,
    'pending_bills' => 0
];

try {
    // Count new registrations today
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM patients WHERE DATE(created_at) = ?");
    if ($stmt) {
        $stmt->bind_param("s", $today);
        $stmt->execute();
        $result = $stmt->get_result();
        $stats['registrations'] = $result->fetch_assoc()['count'] ?? 5;
        $stmt->close();
    }
} catch (Exception $e) {
    $stats['registrations'] = 5;
}

try {
    // Count today's appointments
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM appointments WHERE DATE(appointment_date) = ? AND status = 'scheduled'");
    if ($stmt) {
        $stmt->bind_param("s", $today);
        $stmt->execute();
        $result = $stmt->get_result();
        $stats['appointments'] = $result->fetch_assoc()['count'] ?? 12;
        $stmt->close();
    }
} catch (Exception $e) {
    $stats['appointments'] = 12;
}

try {
    // Count pending bills
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM invoices WHERE status = 'unpaid' AND due_date <= CURDATE()");
    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();
        $stats['pending_bills'] = $result->fetch_assoc()['count'] ?? 3;
        $stmt->close();
    }
} catch (Exception $e) {
    $stats['pending_bills'] = 3;
}

// Fetch today's appointments for display
$today_appointments = [];
try {
    $stmt = $conn->prepare("SELECT * FROM appointments WHERE DATE(appointment_date) = ? AND status = 'scheduled' ORDER BY appointment_time");
    if ($stmt) {
        $stmt->bind_param("s", $today);
        $stmt->execute();
        $today_appointments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
} catch (Exception $e) {
    $today_appointments = [
        ['id' => 1, 'patient_name' => 'John Doe', 'doctor' => 'Dr. Smith', 'appointment_time' => '09:00', 'reason' => 'Checkup'],
        ['id' => 2, 'patient_name' => 'Jane Smith', 'doctor' => 'Dr. Johnson', 'appointment_time' => '10:30', 'reason' => 'Follow-up']
    ];
}

// Fetch pending bills for display
$pending_bills_list = [];
try {
    $stmt = $conn->prepare("SELECT * FROM invoices WHERE status = 'unpaid' AND due_date <= CURDATE() ORDER BY due_date LIMIT 5");
    if ($stmt) {
        $stmt->execute();
        $pending_bills_list = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
} catch (Exception $e) {
    $pending_bills_list = [
        ['id' => 1, 'patient_name' => 'John Doe', 'amount' => 150.00, 'due_date' => $today],
        ['id' => 2, 'patient_name' => 'Jane Smith', 'amount' => 200.00, 'due_date' => date('Y-m-d', strtotime('-2 days'))]
    ];
}

$receptionistName = htmlspecialchars($_SESSION['name'] ?? 'Receptionist', ENT_QUOTES, 'UTF-8');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptionist Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #fff3cd 0%, #f8f9fa 100%);
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header */
        .header {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
            border-left: 5px solid #d4a017;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content h1 {
            color: #d4a017;
            margin-bottom: 5px;
            font-size: 2.2rem;
        }

        .header-content p {
            color: #666;
            font-size: 1.1rem;
        }

        .date-display {
            text-align: right;
            color: #888;
        }

        /* Messages */
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Cards */
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            text-align: center;
            transition: all 0.3s ease;
            border-top: 4px solid;
        }

        .card:nth-child(1) { border-top-color: #d4a017; }
        .card:nth-child(2) { border-top-color: #28a745; }
        .card:nth-child(3) { border-top-color: #dc3545; }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .card h3 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.3rem;
            font-weight: 600;
        }

        .count {
            font-size: 3.5rem;
            font-weight: bold;
            margin: 15px 0;
            display: block;
        }

        .count.new-reg { color: #d4a017; }
        .count.appointments { color: #28a745; }
        .count.pending { color: #dc3545; }

        .card p {
            color: #666;
            margin-bottom: 20px;
            font-size: 1rem;
        }

        /* Buttons */
        .btn {
            display: inline-block;
            background: #d4a017;
            color: white;
            padding: 12px 30px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }

        .btn:hover {
            background: #b8860b;
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(212, 160, 23, 0.3);
        }

        /* Quick Actions */
        .quick-actions {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }

        .quick-actions h2 {
            color: #333;
            margin-bottom: 25px;
            font-size: 1.8rem;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .action-btn {
            background: #f8f9fa;
            color: #333;
            padding: 18px 15px;
            border-radius: 10px;
            text-decoration: none;
            text-align: center;
            transition: all 0.3s ease;
            border: 2px solid #e9ecef;
            font-weight: 500;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        .action-btn:hover {
            background: #d4a017;
            color: white;
            border-color: #d4a017;
            transform: translateY(-3px);
        }

        .action-btn i {
            font-size: 1.5rem;
        }

        /* Forms */
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        /* Tables */
        .table-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        th {
            background: #f8f9fa;
            color: #333;
            font-weight: 600;
        }

        tr:hover {
            background: #f9f9f9;
        }

        .status {
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .status.scheduled { background: #d4edda; color: #155724; }
        .status.unpaid { background: #f8d7da; color: #721c24; }

        .action-cell {
            white-space: nowrap;
        }

        /* Search */
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }

        .search-form {
            display: flex;
            gap: 10px;
        }

        .search-form input {
            flex: 1;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
        }

        /* Logout */
        .logout-btn {
            display: block;
            width: 200px;
            margin: 40px auto 0;
            background: #dc3545;
            color: white;
            padding: 15px;
            border-radius: 8px;
            text-decoration: none;
            text-align: center;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: #c82333;
            transform: scale(1.05);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .cards {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .date-display {
                text-align: center;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="container">
 <!-- Header -->
<div class="header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 30px; border-radius: 10px; margin-bottom: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
    
    <!-- Left Side: Welcome Message -->
    <div style="display: flex; align-items: center; gap: 20px; flex: 1;">
        <!-- Profile Picture with Upload Options -->
        <div style="position: relative;">
            <div id="profileAvatar" style="width: 70px; height: 70px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; font-weight: bold; color: white; box-shadow: 0 3px 10px rgba(0,0,0,0.2); cursor: pointer; overflow: hidden;" onclick="showProfileOptions()">
                <!-- Profile Initial or Image -->
                <span id="avatarInitial"><?php echo strtoupper(substr($receptionistName, 0, 1)); ?></span>
            </div>
            
            <!-- Upload Camera Icon -->
            <div style="position: absolute; bottom: 0; right: 0; background: #4CAF50; color: white; border: 2px solid white; border-radius: 50%; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.2);" onclick="document.getElementById('profileImageUpload').click()">
                <i class="fas fa-camera"></i>
            </div>
            
            <!-- Hidden File Input -->
            <input type="file" id="profileImageUpload" accept="image/*" style="display: none;" onchange="uploadProfileImage(this)">
        </div>
        
        <!-- Welcome Message -->
        <div>
            <h1 style="margin: 0; font-size: 24px; display: flex; align-items: center; gap: 10px;">
                Welcome <?php echo $receptionistName; ?> <i class="fas fa-hospital-user"></i>
                <!-- Profile Actions Dropdown Trigger -->
                <span onclick="toggleProfileActions()" style="cursor: pointer; font-size: 16px; color: rgba(255,255,255,0.8); background: rgba(255,255,255,0.1); padding: 4px 8px; border-radius: 4px; margin-left: 10px;">
                    <i class="fas fa-caret-down"></i> Profile
                </span>
            </h1>
            <p style="margin: 5px 0; color: rgba(255,255,255,0.9);">Receptionist Dashboard - Clinic Management System</p>
            
            <!-- Last Update Indicator -->
            <small style="color: rgba(255,255,255,0.8); display: flex; align-items: center; gap: 15px; margin-top: 5px;">
                <span><i class="far fa-calendar-alt"></i> <?php echo date('F j, Y'); ?></span>
                <span><i class="far fa-clock"></i> <?php echo date('h:i A'); ?></span>
                <span id="lastUpdate" style="font-size: 11px; background: rgba(255,255,255,0.15); padding: 2px 8px; border-radius: 10px; display: none;"></span>
            </small>
        </div>
    </div>
    
    <!-- Right Side: Actions & Logout -->
    <div style="display: flex; align-items: center; gap: 15px;">
        <!-- Notification Bell -->
        <div style="position: relative; cursor: pointer;" onclick="showNotifications()">
            <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-bell" style="font-size: 18px;"></i>
            </div>
            <span id="notificationCount" style="position: absolute; top: -5px; right: -5px; background: #e74c3c; color: white; font-size: 12px; padding: 2px 6px; border-radius: 50%; min-width: 20px; text-align: center; display: none;">0</span>
        </div>
        
        <!-- Print Button -->
        <button onclick="window.print()" style="background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 10px 20px; border-radius: 25px; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: all 0.3s;">
            <i class="fas fa-print"></i> Print
        </button>
        
        <!-- Logout -->
        <a href="../logout.php" style="background: rgba(231, 76, 60, 0.9); color: white; padding: 10px 25px; border-radius: 25px; text-decoration: none; display: flex; align-items: center; gap: 8px; transition: all 0.3s;">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>
</div>

<!-- Profile Actions Dropdown -->
<div id="profileActions" style="display: none; position: absolute; top: 140px; left: 30px; background: white; border-radius: 10px; padding: 10px 0; box-shadow: 0 5px 25px rgba(0,0,0,0.2); min-width: 250px; z-index: 1000; border: 1px solid #e0e0e0;">
    <div style="padding: 15px; border-bottom: 1px solid #eee; background: #f8f9fa; border-radius: 10px 10px 0 0;">
        <strong style="color: #333; font-size: 16px;">Profile Actions</strong>
        <small style="color: #666; display: block; margin-top: 5px;">Manage your account</small>
    </div>
    
    <button onclick="showEditProfileModal()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
        <i class="fas fa-user-edit" style="color: #2196F3; width: 20px;"></i>
        <div>
            <div style="font-weight: 500;">Edit Profile</div>
            <small style="color: #888; font-size: 12px;">Update personal information</small>
        </div>
    </button>
    
    <button onclick="document.getElementById('profileImageUpload').click()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
        <i class="fas fa-camera" style="color: #4CAF50; width: 20px;"></i>
        <div>
            <div style="font-weight: 500;">Upload Photo</div>
            <small style="color: #888; font-size: 12px;">Change profile picture</small>
        </div>
    </button>
    
    <button onclick="showUpdateProfileModal()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
        <i class="fas fa-sync-alt" style="color: #FF9800; width: 20px;"></i>
        <div>
            <div style="font-weight: 500;">Update Profile</div>
            <small style="color: #888; font-size: 12px;">Sync latest information</small>
        </div>
    </button>
    
    <div style="padding: 10px 15px; background: #f8f9fa;">
        <strong style="color: #333; font-size: 14px;">Account Settings</strong>
    </div>
    
    <button onclick="showChangePasswordModal()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
        <i class="fas fa-key" style="color: #9C27B0; width: 20px;"></i>
        <div>
            <div style="font-weight: 500;">Change Password</div>
            <small style="color: #888; font-size: 12px;">Update login credentials</small>
        </div>
    </button>
    
    <button onclick="showDeleteAccountModal()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #e74c3c; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
        <i class="fas fa-trash-alt" style="width: 20px;"></i>
        <div>
            <div style="font-weight: 500;">Delete Account</div>
            <small style="color: #e74c3c; font-size: 12px;">Permanently remove account</small>
        </div>
    </button>
</div>

<!-- Edit Profile Modal -->
<div id="editProfileModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
            <h2 style="margin: 0; color: #333; font-size: 24px;">
                <i class="fas fa-user-edit" style="color: #2196F3; margin-right: 10px;"></i>
                Edit Profile Information
            </h2>
            <button onclick="closeEditProfileModal()" style="background: none; border: none; font-size: 28px; cursor: pointer; color: #999; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 50%;">&times;</button>
        </div>
        
        <!-- Profile Picture Section -->
        <div style="text-align: center; margin-bottom: 25px;">
            <div id="editProfileAvatar" style="width: 100px; height: 100px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 36px; font-weight: bold; color: white; overflow: hidden; position: relative;">
                <span id="editAvatarInitial"><?php echo strtoupper(substr($receptionistName, 0, 1)); ?></span>
            </div>
            <input type="file" id="editProfileImage" accept="image/*" style="display: none;" onchange="updateProfileImage(this)">
            <button onclick="document.getElementById('editProfileImage').click()" style="background: #2196F3; color: white; border: none; padding: 8px 20px; border-radius: 20px; cursor: pointer; font-size: 14px;">
                <i class="fas fa-upload"></i> Change Photo
            </button>
        </div>
        
        <!-- Edit Form -->
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600;">Full Name *</label>
                <input type="text" id="editFullName" value="<?php echo $receptionistName; ?>" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600;">Email Address *</label>
                <input type="email" id="editEmail" placeholder="your.email@clinic.com" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600;">Phone Number</label>
                <input type="tel" id="editPhone" placeholder="+251 900 000 000" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600;">Address</label>
                <textarea id="editAddress" placeholder="Your address..." rows="3" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px; resize: vertical;"></textarea>
            </div>
        </div>
        
        <div style="display: flex; gap: 15px; margin-top: 30px;">
            <button onclick="saveProfileChanges()" style="flex: 1; background: linear-gradient(135deg, #4CAF50, #45a049); color: white; border: none; padding: 14px; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 10px;">
                <i class="fas fa-save"></i> Save Changes
            </button>
            <button onclick="closeEditProfileModal()" style="flex: 1; background: #f8f9fa; color: #666; border: 2px solid #e0e0e0; padding: 14px; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: 600;">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div id="changePasswordModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 450px; width: 90%; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
            <h2 style="margin: 0; color: #333; font-size: 22px;">
                <i class="fas fa-key" style="color: #9C27B0; margin-right: 10px;"></i>
                Change Password
            </h2>
            <button onclick="closeChangePasswordModal()" style="background: none; border: none; font-size: 28px; cursor: pointer; color: #999;">&times;</button>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600;">Current Password</label>
                <input type="password" id="currentPassword" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600;">New Password</label>
                <input type="password" id="newPassword" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600;">Confirm New Password</label>
                <input type="password" id="confirmPassword" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
            </div>
        </div>
        
        <div style="display: flex; gap: 15px; margin-top: 30px;">
            <button onclick="updatePassword()" style="flex: 1; background: #9C27B0; color: white; border: none; padding: 14px; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: 600;">
                Update Password
            </button>
            <button onclick="closeChangePasswordModal()" style="flex: 1; background: #f8f9fa; color: #666; border: 2px solid #e0e0e0; padding: 14px; border-radius: 8px; cursor: pointer; font-size: 16px;">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- Delete Account Modal -->
<div id="deleteAccountModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 500px; width: 90%; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
        <div style="text-align: center; margin-bottom: 25px;">
            <div style="width: 80px; height: 80px; background: #e74c3c; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 36px; margin: 0 auto 20px;">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h2 style="margin: 0; color: #e74c3c; font-size: 24px;">Delete Account</h2>
            <p style="color: #666; margin-top: 10px;">This action cannot be undone!</p>
        </div>
        
        <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 25px;">
            <p style="color: #333; margin-bottom: 15px;"><strong>⚠️ Warning:</strong> Deleting your account will:</p>
            <ul style="color: #666; padding-left: 20px; margin: 0;">
                <li>Permanently remove your profile</li>
                <li>Delete all your data from the system</li>
                <li>Cancel all pending appointments</li>
                <li>Require admin approval to restore</li>
            </ul>
        </div>
        
        <div>
            <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600;">Type "DELETE" to confirm</label>
            <input type="text" id="deleteConfirmation" placeholder="Type DELETE here" style="width: 100%; padding: 12px; border: 2px solid #e74c3c; border-radius: 8px; font-size: 16px;">
        </div>
        
        <div style="display: flex; gap: 15px; margin-top: 30px;">
            <button onclick="confirmDeleteAccount()" style="flex: 1; background: #e74c3c; color: white; border: none; padding: 14px; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: 600;">
                Delete Account
            </button>
            <button onclick="closeDeleteAccountModal()" style="flex: 1; background: #f8f9fa; color: #666; border: 2px solid #e0e0e0; padding: 14px; border-radius: 8px; cursor: pointer; font-size: 16px;">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- Sample Data Warning -->
<?php if ($stats['registrations'] == 5 || $stats['appointments'] == 12 || $stats['pending_bills'] == 3): ?>
<div id="sampleDataWarning" style="background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center; gap: 10px;">
        <i class="fas fa-exclamation-triangle" style="color: #ff9800;"></i>
        <span>You are viewing sample data. Actual data will appear when connected to database.</span>
    </div>
    <button onclick="document.getElementById('sampleDataWarning').style.display='none'" style="background: none; border: none; color: #856404; cursor: pointer; font-size: 20px;">&times;</button>
</div>
<?php endif; ?>

<!-- JavaScript for Profile Management -->
<script>
// Load saved profile data
window.addEventListener('load', function() {
    loadProfileData();
    loadProfileImage();
});

// Toggle profile actions dropdown
function toggleProfileActions() {
    const dropdown = document.getElementById('profileActions');
    const isVisible = dropdown.style.display === 'block';
    
    // Hide all other dropdowns
    closeAllModals();
    
    // Toggle this dropdown
    dropdown.style.display = isVisible ? 'none' : 'block';
}

// Close all modals and dropdowns
function closeAllModals() {
    document.getElementById('profileActions').style.display = 'none';
    closeEditProfileModal();
    closeChangePasswordModal();
    closeDeleteAccountModal();
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('profileActions');
    const target = event.target;
    
    if (!target.closest('.header') && !target.closest('#profileActions')) {
        dropdown.style.display = 'none';
    }
});

// Profile image upload
function uploadProfileImage(input) {
    if (!input.files || !input.files[0]) return;
    
    const file = input.files[0];
    const maxSize = 5 * 1024 * 1024; // 5MB
    
    if (file.size > maxSize) {
        showMessage('Image size should be less than 5MB', 'error');
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        // Update profile avatar
        updateAvatarDisplay(e.target.result);
        
        // Save to localStorage for demo
        localStorage.setItem('receptionistProfileImage', e.target.result);
        
        showMessage('Profile image uploaded successfully!', 'success');
    };
    
    reader.readAsDataURL(file);
}

// Update profile image from edit modal
function updateProfileImage(input) {
    uploadProfileImage(input);
}

// Update avatar display
function updateAvatarDisplay(imageSrc) {
    const avatar = document.getElementById('profileAvatar');
    const editAvatar = document.getElementById('editProfileAvatar');
    const initial = document.getElementById('avatarInitial');
    const editInitial = document.getElementById('editAvatarInitial');
    
    // Update main header avatar
    if (avatar && initial) {
        initial.style.display = 'none';
        let img = avatar.querySelector('img');
        if (!img) {
            img = document.createElement('img');
            img.style.cssText = 'width: 100%; height: 100%; object-fit: cover;';
            avatar.appendChild(img);
        }
        img.src = imageSrc;
    }
    
    // Update edit modal avatar
    if (editAvatar && editInitial) {
        editInitial.style.display = 'none';
        let editImg = editAvatar.querySelector('img');
        if (!editImg) {
            editImg = document.createElement('img');
            editImg.style.cssText = 'width: 100%; height: 100%; object-fit: cover;';
            editAvatar.appendChild(editImg);
        }
        editImg.src = imageSrc;
    }
}

// Load saved profile image
function loadProfileImage() {
    const savedImage = localStorage.getItem('receptionistProfileImage');
    if (savedImage) {
        updateAvatarDisplay(savedImage);
    }
}

// Load profile data
function loadProfileData() {
    const savedData = localStorage.getItem('receptionistProfileData');
    if (savedData) {
        const data = JSON.parse(savedData);
        document.getElementById('editFullName').value = data.name || '<?php echo $receptionistName; ?>';
        document.getElementById('editEmail').value = data.email || '';
        document.getElementById('editPhone').value = data.phone || '';
        document.getElementById('editAddress').value = data.address || '';
    }
}

// Show edit profile modal
function showEditProfileModal() {
    document.getElementById('editProfileModal').style.display = 'flex';
    document.getElementById('profileActions').style.display = 'none';
}

function closeEditProfileModal() {
    document.getElementById('editProfileModal').style.display = 'none';
}

// Show update profile modal
function showUpdateProfileModal() {
    // In real app, this would fetch latest data from server
    showEditProfileModal();
}

// Show change password modal
function showChangePasswordModal() {
    document.getElementById('changePasswordModal').style.display = 'flex';
    document.getElementById('profileActions').style.display = 'none';
}

function closeChangePasswordModal() {
    document.getElementById('changePasswordModal').style.display = 'none';
}

// Show delete account modal
function showDeleteAccountModal() {
    document.getElementById('deleteAccountModal').style.display = 'flex';
    document.getElementById('profileActions').style.display = 'none';
}

function closeDeleteAccountModal() {
    document.getElementById('deleteAccountModal').style.display = 'none';
}

// Save profile changes
function saveProfileChanges() {
    const name = document.getElementById('editFullName').value;
    const email = document.getElementById('editEmail').value;
    const phone = document.getElementById('editPhone').value;
    const address = document.getElementById('editAddress').value;
    
    if (!name || !email) {
        showMessage('Name and email are required', 'error');
        return;
    }
    
    // Update welcome message
    document.querySelector('h1').innerHTML = `Welcome ${name} <i class="fas fa-hospital-user"></i> <span onclick="toggleProfileActions()" style="cursor: pointer; font-size: 16px; color: rgba(255,255,255,0.8); background: rgba(255,255,255,0.1); padding: 4px 8px; border-radius: 4px; margin-left: 10px;"><i class="fas fa-caret-down"></i> Profile</span>`;
    
    // Update last update time
    const now = new Date();
    const lastUpdate = document.getElementById('lastUpdate');
    lastUpdate.textContent = `Updated: ${now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    lastUpdate.style.display = 'inline-block';
    
    // Save to localStorage for demo
    const profileData = {
        name: name,
        email: email,
        phone: phone,
        address: address,
        updatedAt: now.toISOString()
    };
    localStorage.setItem('receptionistProfileData', JSON.stringify(profileData));
    
    showMessage('Profile updated successfully!', 'success');
    closeEditProfileModal();
}

// Update password
function updatePassword() {
    const current = document.getElementById('currentPassword').value;
    const newPass = document.getElementById('newPassword').value;
    const confirmPass = document.getElementById('confirmPassword').value;
    
    if (!current || !newPass || !confirmPass) {
        showMessage('Please fill all password fields', 'error');
        return;
    }
    
    if (newPass !== confirmPass) {
        showMessage('New passwords do not match', 'error');
        return;
    }
    
    if (newPass.length < 6) {
        showMessage('Password must be at least 6 characters', 'error');
        return;
    }
    
    // In real app, verify current password with server
    showMessage('Password updated successfully!', 'success');
    closeChangePasswordModal();
    
    // Clear password fields
    document.getElementById('currentPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
}

// Delete account
function confirmDeleteAccount() {
    const confirmation = document.getElementById('deleteConfirmation').value;
    
    if (confirmation !== 'DELETE') {
        showMessage('Please type "DELETE" to confirm', 'error');
        return;
    }
    
    if (confirm('⚠️ Final confirmation: Delete your account permanently?')) {
        // In real app, send delete request to server
        localStorage.removeItem('receptionistProfileData');
        localStorage.removeItem('receptionistProfileImage');
        
        showMessage('Account deletion request submitted. Admin will review.', 'warning');
        closeDeleteAccountModal();
        
        // Redirect to logout after 3 seconds
        setTimeout(() => {
            window.location.href = '../logout.php';
        }, 3000);
    }
}

// Show notifications
function showNotifications() {
    showMessage('No new notifications', 'info');
}

// Utility function to show messages
function showMessage(text, type) {
    const colors = {
        success: '#4CAF50',
        error: '#f44336',
        warning: '#ff9800',
        info: '#2196F3'
    };
    
    // Remove existing message
    const oldMsg = document.getElementById('tempMessage');
    if (oldMsg) oldMsg.remove();
    
    // Create new message
    const msg = document.createElement('div');
    msg.id = 'tempMessage';
    msg.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${colors[type] || colors.info};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 10001;
        animation: slideIn 0.3s ease;
        font-weight: 500;
    `;
    msg.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}"></i> ${text}`;
    document.body.appendChild(msg);
    
    setTimeout(() => {
        if (msg.parentElement) msg.remove();
    }, 3000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    #profileActions button:hover {
        background: #f8f9fa;
        padding-left: 20px;
    }
    
    #editProfileModal > div,
    #changePasswordModal > div,
    #deleteAccountModal > div {
        animation: fadeIn 0.3s ease;
    }
    
    #profileAvatar:hover {
        transform: scale(1.05);
        transition: transform 0.3s;
    }
`;
document.head.appendChild(style);

// Close modals on outside click
document.getElementById('editProfileModal').addEventListener('click', function(e) {
    if (e.target.id === 'editProfileModal') closeEditProfileModal();
});

document.getElementById('changePasswordModal').addEventListener('click', function(e) {
    if (e.target.id === 'changePasswordModal') closeChangePasswordModal();
});

document.getElementById('deleteAccountModal').addEventListener('click', function(e) {
    if (e.target.id === 'deleteAccountModal') closeDeleteAccountModal();
});
</script>

    <!-- Messages -->
    <?php if ($success_message): ?>
    <div class="message success">
        <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
    <div class="message error">
        <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
    </div>
    <?php endif; ?>

    <!-- Dashboard View -->
    <?php if ($action === 'dashboard'): ?>
        <!-- Statistics Cards -->
        <div class="cards">
            <div class="card">
                <h3><i class="fas fa-user-plus"></i> New Registrations</h3>
                <span class="count new-reg"><?php echo $stats['registrations']; ?></span>
                <p>Patients registered today</p>
                <button onclick="showModal('register')" class="btn">
                    <i class="fas fa-plus-circle"></i> Register Patient
                </button>
            </div>

            <div class="card">
                <h3><i class="fas fa-calendar-check"></i> Today's Appointments</h3>
                <span class="count appointments"><?php echo $stats['appointments']; ?></span>
                <p>Appointments scheduled for today</p>
                <button onclick="showModal('appointments')" class="btn">
                    <i class="fas fa-eye"></i> View All
                </button>
            </div>

            <div class="card">
                <h3><i class="fas fa-file-invoice-dollar"></i> Pending Bills</h3>
                <span class="count pending"><?php echo $stats['pending_bills']; ?></span>
                <p>Overdue payments to collect</p>
                <button onclick="showModal('bills')" class="btn">
                    <i class="fas fa-money-check-alt"></i> Collect Payment
                </button>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <h2><i class="fas fa-bolt"></i> systems Actions</h2>
            <div class="action-buttons">
                <button onclick="showModal('register')" class="action-btn">
                    <i class="fas fa-user-plus"></i>
                    <span>Register Patient</span>
                </button>
                <button onclick="showModal('book_appointment')" class="action-btn">
                    <i class="fas fa-calendar-plus"></i>
                    <span>Book Appointment</span>
                </button>
                <button onclick="showModal('bills')" class="action-btn">
                    <i class="fas fa-credit-card"></i>
                    <span>Process Payment</span>
                </button>
                <button onclick="showModal('search')" class="action-btn">
                    <i class="fas fa-search"></i>
                    <span>Search Patient</span>
                </button>
                <button onclick="printPrescription()" class="action-btn">
                    <i class="fas fa-prescription"></i>
                    <span>Print Slip</span>
                </button>
                <button onclick="generateReport()" class="action-btn">
                    <i class="fas fa-chart-bar"></i>
                    <span>Generate Report</span>
                </button>
            </div>
        </div>

        <!-- Today's Appointments Table -->
        <div class="table-container">
            <h2><i class="fas fa-calendar-day"></i> Today's Appointments</h2>
            <table>
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Reason</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($today_appointments as $appointment): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($appointment['appointment_time']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['patient_name']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['doctor'] ?? 'Dr. Smith'); ?></td>
                        <td><?php echo htmlspecialchars($appointment['reason'] ?? 'Checkup'); ?></td>
                        <td><span class="status scheduled">Scheduled</span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Pending Bills Table -->
        <div class="table-container">
            <h2><i class="fas fa-clock"></i> Pending Bills</h2>
            <table>
                <thead>
                    <tr>
                        <th>Patient</th>
                        <th>Amount</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($pending_bills_list as $bill): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($bill['patient_name']); ?></td>
                        <td>$<?php echo number_format($bill['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($bill['due_date']); ?></td>
                        <td><span class="status unpaid">Unpaid</span></td>
                        <td class="action-cell">
                            <button onclick="payBill(<?php echo $bill['id']; ?>)" class="btn" style="padding: 8px 15px; font-size: 0.9rem;">
                                <i class="fas fa-money-bill-wave"></i> Pay
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

    <!-- Search Results -->
    <?php if ($action === 'search' && isset($search_results)): ?>
    <div class="table-container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2><i class="fas fa-search"></i> Search Results</h2>
            <a href="?action=dashboard" class="btn">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($search_results as $result): ?>
                <tr>
                    <td><?php echo $result['id']; ?></td>
                    <td><?php echo htmlspecialchars($result['name']); ?></td>
                    <td><?php echo htmlspecialchars($result['phone']); ?></td>
                    <td><?php echo htmlspecialchars($result['email']); ?></td>
                    <td class="action-cell">
                        <button onclick="bookForPatient('<?php echo htmlspecialchars($result['name']); ?>', '<?php echo htmlspecialchars($result['phone']); ?>')" class="btn" style="padding: 8px 15px; font-size: 0.9rem;">
                            <i class="fas fa-calendar-plus"></i> Book Appointment
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    
</div>

<!-- Modals -->
<div id="registerModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-user-plus"></i> Register New Patient</h2>
            <button onclick="hideModal('register')" class="modal-close">&times;</button>
        </div>
        <form method="POST" action="?action=register">
            <div class="form-row">
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label>Phone Number *</label>
                    <input type="tel" name="phone" required>
                </div>
            </div>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email">
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="address">
            </div>
            <button type="submit" class="btn" style="width: 100%;">
                <i class="fas fa-save"></i> Register Patient
            </button>
        </form>
    </div>
</div>

<div id="bookAppointmentModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-calendar-plus"></i> Book Appointment</h2>
            <button onclick="hideModal('book_appointment')" class="modal-close">&times;</button>
        </div>
        <form method="POST" action="?action=book_appointment">
            <div class="form-row">
                <div class="form-group">
                    <label>Patient Name *</label>
                    <input type="text" name="patient_name" id="patient_name" required>
                </div>
                <div class="form-group">
                    <label>Phone Number *</label>
                    <input type="tel" name="patient_phone" id="patient_phone" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Doctor *</label>
                    <select name="doctor" required>
                        <option value="">Select Doctor</option>
                        <option value="Dr. Smith">Dr. Smith</option>
                        <option value="Dr. Johnson">Dr. Johnson</option>
                        <option value="Dr. Williams">Dr. Williams</option>
                        <option value="Dr. Brown">Dr. Brown</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Date *</label>
                    <input type="date" name="date" required min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label>Time *</label>
                    <input type="time" name="time" required>
                </div>
            </div>
            <div class="form-group">
                <label>Reason for Visit</label>
                <textarea name="reason" rows="3"></textarea>
            </div>
            <button type="submit" class="btn" style="width: 100%;">
                <i class="fas fa-calendar-check"></i> Book Appointment
            </button>
        </form>
    </div>
</div>

<div id="appointmentsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-calendar-day"></i> Today's Appointments</h2>
            <button onclick="hideModal('appointments')" class="modal-close">&times;</button>
        </div>
        <div style="max-height: 400px; overflow-y: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($today_appointments as $appointment): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($appointment['appointment_time']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['patient_name']); ?></td>
                        <td><?php echo htmlspecialchars($appointment['doctor'] ?? 'Dr. Smith'); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <button onclick="hideModal('appointments'); showModal('book_appointment')" class="btn" style="width: 100%; margin-top: 20px;">
            <i class="fas fa-plus-circle"></i> Book New Appointment
        </button>
    </div>
</div>

<div id="billsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-file-invoice-dollar"></i> Pending Bills</h2>
            <button onclick="hideModal('bills')" class="modal-close">&times;</button>
        </div>
        <div style="max-height: 400px; overflow-y: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Patient</th>
                        <th>Amount</th>
                        <th>Due Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($pending_bills_list as $bill): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($bill['patient_name']); ?></td>
                        <td>$<?php echo number_format($bill['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($bill['due_date']); ?></td>
                        <td>
                            <button onclick="payBill(<?php echo $bill['id']; ?>)" class="btn" style="padding: 8px 15px; font-size: 0.9rem;">
                                <i class="fas fa-money-bill-wave"></i> Pay
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="searchModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-search"></i> Search Patient</h2>
            <button onclick="hideModal('search')" class="modal-close">&times;</button>
        </div>
        <form method="GET" action="">
            <input type="hidden" name="action" value="search">
            <div class="form-group">
                <label>Search by Name, Phone, or Email</label>
                <input type="text" name="query" placeholder="Enter search term..." required>
            </div>
            <button type="submit" class="btn" style="width: 100%;">
                <i class="fas fa-search"></i> Search
            </button>
        </form>
    </div>
</div>

<script>
    // Modal Functions
    function showModal(modalId) {
        document.getElementById(modalId + 'Modal').style.display = 'flex';
    }

    function hideModal(modalId) {
        document.getElementById(modalId + 'Modal').style.display = 'none';
    }

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target.className === 'modal') {
            event.target.style.display = 'none';
        }
    }

    // Pay Bill Function
    function payBill(billId) {
        if (confirm('Mark this bill as paid?')) {
            window.location.href = '?action=pay_bill&id=' + billId;
        }
    }

    // Book for specific patient
    function bookForPatient(name, phone) {
        document.getElementById('patient_name').value = name;
        document.getElementById('patient_phone').value = phone;
        hideModal('search');
        showModal('book_appointment');
    }

    // Print prescription
    function printPrescription() {
        alert('Printing prescription slip...');
        // In real implementation, this would open print dialog
        window.print();
    }

    // Generate report
    function generateReport() {
        alert('Generating daily report...');
        // In real implementation, this would download a report
    }

    // Animate counts
    document.addEventListener('DOMContentLoaded', function() {
        const counts = document.querySelectorAll('.count');
        counts.forEach(count => {
            const target = parseInt(count.textContent);
            let current = 0;
            const increment = target / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    count.textContent = target;
                    clearInterval(timer);
                } else {
                    count.textContent = Math.floor(current);
                }
            }, 20);
        });
    });

    // Set minimum date to today for appointment booking
    document.addEventListener('DOMContentLoaded', function() {
        const dateInput = document.querySelector('input[type="date"]');
        if (dateInput) {
            dateInput.min = new Date().toISOString().split('T')[0];
        }
    });
</script>

</body>
</html>