<?php
session_start();
require "db.php";

$error = "";

if (isset($_POST['login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        // Check plain text password
        if ($password === $user['password']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name']    = $user['name'];
            $_SESSION['role']    = $user['role'];

            // Redirect based on role
            switch($user['role']) {
                case 'admin':
                    header("Location: admin/admin-dashboard.php");
                    break;
                case 'doctor':
                    header("Location: doctors/doctor-dashboard.php");
                    break;
                case 'receptionist':
                    header("Location: receptionist/receptionist-dashboard.php");
                    break;
                case 'staff':
                    header("Location: staff/staff-dashboard.php");
                    break;
                case 'patient':
                    header("Location: patient/patient-dashboard.php");
                    break;
                default:
                    header("Location: login.php");
            }
            exit();
        } else {
            $error = "Invalid password";
        }
    } else {
        $error = "User not found";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Clinic Login</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.login-container {
    background: white;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    width: 100%;
    max-width: 400px;
}

.login-box h2 {
    color: #333;
    text-align: center;
    margin-bottom: 10px;
}

.login-box h3 {
    color: #666;
    text-align: center;
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group input {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #ddd;
    border-radius: 8px;
    font-size: 16px;
    transition: border-color 0.3s;
}

.form-group input:focus {
    border-color: #667eea;
    outline: none;
}

.error-message {
    color: #e74c3c;
    text-align: center;
    margin-bottom: 15px;
    padding: 10px;
    background: #ffeaea;
    border-radius: 5px;
}

.login-btn {
    width: 100%;
    padding: 14px;
    background: #667eea;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.3s;
}

.login-btn:hover {
    background: #5a6fd8;
}

.back-home {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #667eea;
    text-decoration: none;
}

.back-home:hover {
    text-decoration: underline;
}

.demo-credentials {
    margin-top: 20px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 8px;
    font-size: 14px;
    color: #666;
}

.demo-credentials h4 {
    margin-bottom: 10px;
    color: #333;
}

.demo-credentials p {
    margin: 5px 0;
    font-size: 13px;
}
</style>
</head>
<body>

<div class="login-container">
     <img src="logo.png" 
     alt="Clinic Logo" 
     style="width: 100px; height: 100px; object-fit: contain; display: block; margin: 0 auto 20px;">
    <div class="login-box">
        <h2>Clinic Management System</h2>
        <h3>Login</h3>
        
        <?php if ($error): ?>
            <div class="error-message"><?= $error ?></div>
        <?php endif; ?>
        
        <!--div class="demo-credentials">
           <h4>Demo Credentials:</h4>
            <p><strong>Admin:</strong> admin@clinic.com / admin123</p>
            <p><strong>Doctor:</strong> doctor@clinic.com / doctor123</p>
            <p><strong>Receptionist:</strong> receptionist@clinic.com / reception123</p>
            <p><strong>Staff:</strong> staff@clinic.com / staff123</p>
            <p><strong>Patient:</strong> patient@clinic.com / patient123</p>
        </div-->
        
        <form method="post">
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" name="login" class="login-btn">Login</button>
        </form>
        
        <a href="index.php" class="back-home">← Back to Home</a>
    </div>
</div>

</body>
</html>