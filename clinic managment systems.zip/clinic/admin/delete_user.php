<?php
session_start();
require "../db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Prevent deleting yourself
    if ($id == $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'error' => 'You cannot delete your own account']);
        exit();
    }
    
    // Check if user exists
    $check = $conn->query("SELECT id FROM users WHERE id = $id");
    if ($check->num_rows == 0) {
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit();
    }
    
    // Delete user
    if ($conn->query("DELETE FROM users WHERE id = $id")) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No user ID provided']);
}
?>