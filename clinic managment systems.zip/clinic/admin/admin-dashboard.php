<?php
session_start();
require_once __DIR__ . '/../db.php';


// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_name = $_SESSION['name'] ?? 'Admin';

// Handle form submissions with fallback data
$message = '';
$message_type = '';
$success_data = [];

// Add User
if (isset($_POST['add_user'])) {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'patient';
    
    // Save to session for demo
    if (!isset($_SESSION['users'])) {
        $_SESSION['users'] = [];
    }
    
    $user_id = count($_SESSION['users']) + 1;
    $_SESSION['users'][] = [
        'id' => $user_id,
        'name' => $name,
        'email' => $email,
        'password' => md5($password),
        'role' => $role,
        'status' => 'active',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    // If added as doctor, also add to doctors list
    if ($role === 'doctor') {
        if (!isset($_SESSION['doctors'])) {
            $_SESSION['doctors'] = [];
        }
        
        $_SESSION['doctors'][] = [
            'id' => count($_SESSION['doctors']) + 1,
            'user_id' => $user_id,
            'name' => $name,
            'specialization' => 'General Physician',
            'experience' => 0,
            'phone' => '',
            'status' => 'active'
        ];
    }
    
    $message = "User added successfully! User ID: USR-$user_id";
    $message_type = "success";
}

// Add Doctor
if (isset($_POST['add_doctor'])) {
    $doctor_name = $_POST['doctor_name'] ?? '';
    $specialization = $_POST['specialization'] ?? '';
    $experience = $_POST['experience'] ?? 0;
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    
    if (!isset($_SESSION['doctors'])) {
        $_SESSION['doctors'] = [];
    }
    
    $doctor_id = count($_SESSION['doctors']) + 1;
    $_SESSION['doctors'][] = [
        'id' => $doctor_id,
        'name' => $doctor_name,
        'specialization' => $specialization,
        'experience' => $experience,
        'phone' => $phone,
        'email' => $email,
        'status' => 'active',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $message = "Doctor added successfully! Doctor ID: DR-$doctor_id";
    $message_type = "success";
}

// Update Settings
if (isset($_POST['update_settings'])) {
    if (!isset($_SESSION['clinic_settings'])) {
        $_SESSION['clinic_settings'] = [];
    }
    
    $_SESSION['clinic_settings'] = [
        'clinic_name' => $_POST['clinic_name'] ?? 'Medicare Clinic',
        'clinic_email' => $_POST['clinic_email'] ?? 'contact@clinic.com',
        'clinic_phone' => $_POST['clinic_phone'] ?? '+1 234 567 8900',
        'clinic_address' => $_POST['clinic_address'] ?? '123 Medical Street, Healthcare City',
        'opening_time' => $_POST['opening_time'] ?? '08:00',
        'closing_time' => $_POST['closing_time'] ?? '20:00',
        'appointment_duration' => $_POST['appointment_duration'] ?? 30,
        'updated_at' => date('Y-m-d H:i:s')
    ];
    
    $message = "Clinic settings updated successfully!";
    $message_type = "success";
}

// Generate Report
if (isset($_POST['generate_report'])) {
    $report_type = $_POST['report_type'] ?? '';
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    
    if (!isset($_SESSION['reports'])) {
        $_SESSION['reports'] = [];
    }
    
    $report_id = count($_SESSION['reports']) + 1;
    $report_title = ucfirst($report_type) . " Report - " . date('F Y');
    
    $_SESSION['reports'][] = [
        'id' => $report_id,
        'title' => $report_title,
        'type' => $report_type,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'generated_by' => $admin_name,
        'generated_at' => date('Y-m-d H:i:s')
    ];
    
    $message = "Report generated successfully! Report ID: REP-$report_id";
    $message_type = "success";
    $success_data = ['report_id' => $report_id];
}

// Update User Status
if (isset($_GET['update_status'])) {
    $user_id = $_GET['id'] ?? 0;
    $new_status = $_GET['status'] ?? '';
    
    if (isset($_SESSION['users']) && isset($_SESSION['users'][$user_id-1])) {
        $_SESSION['users'][$user_id-1]['status'] = $new_status;
        $message = "User status updated to " . ucfirst($new_status) . "!";
        $message_type = "success";
    }
}

// Update Doctor Status
if (isset($_GET['update_doctor_status'])) {
    $doctor_id = $_GET['id'] ?? 0;
    $new_status = $_GET['status'] ?? '';
    
    if (isset($_SESSION['doctors']) && isset($_SESSION['doctors'][$doctor_id-1])) {
        $_SESSION['doctors'][$doctor_id-1]['status'] = $new_status;
        $message = "Doctor status updated to " . ucfirst($new_status) . "!";
        $message_type = "success";
    }
}

// Update Appointment Status
if (isset($_GET['update_appointment_status'])) {
    $appointment_id = $_GET['id'] ?? 0;
    $new_status = $_GET['status'] ?? '';
    
    if (isset($_SESSION['appointments']) && isset($_SESSION['appointments'][$appointment_id-1])) {
        $_SESSION['appointments'][$appointment_id-1]['status'] = $new_status;
        $message = "Appointment status updated to " . ucfirst($new_status) . "!";
        $message_type = "success";
    }
}

// Delete User
if (isset($_GET['delete_user'])) {
    $user_id = $_GET['id'] ?? 0;
    
    if (isset($_SESSION['users']) && isset($_SESSION['users'][$user_id-1])) {
        array_splice($_SESSION['users'], $user_id-1, 1);
        $message = "User deleted successfully!";
        $message_type = "success";
    }
}

// Delete Doctor
if (isset($_GET['delete_doctor'])) {
    $doctor_id = $_GET['id'] ?? 0;
    
    if (isset($_SESSION['doctors']) && isset($_SESSION['doctors'][$doctor_id-1])) {
        array_splice($_SESSION['doctors'], $doctor_id-1, 1);
        $message = "Doctor deleted successfully!";
        $message_type = "success";
    }
}

// Fetch data for dashboard (with fallback sample data)
$total_users = 156;
$total_doctors = 24;
$total_appointments = 542;
$today_appointments = 18;
$pending_appointments = 12;
$revenue_today = 2850;
$revenue_month = 52800;

// Try to get real data
try {
    $result = $conn->query("SELECT COUNT(*) as count FROM users");
    if ($result) $total_users = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

try {
    $result = $conn->query("SELECT COUNT(*) as count FROM doctors");
    if ($result) $total_doctors = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

// Sample data arrays
$users_data = $_SESSION['users'] ?? [
    ['id' => 1, 'name' => 'John Doe', 'email' => 'john@example.com', 'role' => 'patient', 'status' => 'active', 'created_at' => '2024-01-15'],
    ['id' => 2, 'name' => 'Dr. Sarah Smith', 'email' => 'sarah@example.com', 'role' => 'doctor', 'status' => 'active', 'created_at' => '2024-01-10'],
    ['id' => 3, 'name' => 'Mike Wilson', 'email' => 'mike@example.com', 'role' => 'staff', 'status' => 'active', 'created_at' => '2024-01-05'],
    ['id' => 4, 'name' => 'Robert Johnson', 'email' => 'robert@example.com', 'role' => 'patient', 'status' => 'inactive', 'created_at' => '2024-01-01'],
    ['id' => 5, 'name' => 'Dr. Emma Davis', 'email' => 'emma@example.com', 'role' => 'doctor', 'status' => 'active', 'created_at' => '2023-12-28']
];

$doctors_data = $_SESSION['doctors'] ?? [
    ['id' => 1, 'name' => 'Dr. Sarah Smith', 'specialization' => 'Cardiology', 'experience' => 10, 'phone' => '+1 234 567 8901', 'status' => 'active'],
    ['id' => 2, 'name' => 'Dr. Emma Davis', 'specialization' => 'Neurology', 'experience' => 8, 'phone' => '+1 234 567 8902', 'status' => 'active'],
    ['id' => 3, 'name' => 'Dr. James Wilson', 'specialization' => 'Orthopedics', 'experience' => 12, 'phone' => '+1 234 567 8903', 'status' => 'active'],
    ['id' => 4, 'name' => 'Dr. Lisa Brown', 'specialization' => 'Pediatrics', 'experience' => 6, 'phone' => '+1 234 567 8904', 'status' => 'inactive'],
    ['id' => 5, 'name' => 'Dr. Michael Chen', 'specialization' => 'Dermatology', 'experience' => 9, 'phone' => '+1 234 567 8905', 'status' => 'active']
];

$appointments_data = $_SESSION['appointments'] ?? [
    ['id' => 1, 'patient_name' => 'John Doe', 'doctor_name' => 'Dr. Sarah Smith', 'date' => date('Y-m-d'), 'time' => '09:00 AM', 'reason' => 'Heart Checkup', 'status' => 'confirmed'],
    ['id' => 2, 'patient_name' => 'Jane Smith', 'doctor_name' => 'Dr. Emma Davis', 'date' => date('Y-m-d'), 'time' => '10:30 AM', 'reason' => 'Migraine', 'status' => 'pending'],
    ['id' => 3, 'patient_name' => 'Robert Johnson', 'doctor_name' => 'Dr. James Wilson', 'date' => date('Y-m-d'), 'time' => '11:45 AM', 'reason' => 'Knee Pain', 'status' => 'confirmed'],
    ['id' => 4, 'patient_name' => 'Sarah Wilson', 'doctor_name' => 'Dr. Lisa Brown', 'date' => date('Y-m-d'), 'time' => '02:15 PM', 'reason' => 'Child Vaccination', 'status' => 'pending'],
    ['id' => 5, 'patient_name' => 'Michael Brown', 'doctor_name' => 'Dr. Michael Chen', 'date' => date('Y-m-d'), 'time' => '03:30 PM', 'reason' => 'Skin Allergy', 'status' => 'completed']
];

$reports_data = $_SESSION['reports'] ?? [
    ['id' => 1, 'title' => 'Monthly Financial Report - January 2024', 'type' => 'financial', 'generated_by' => 'Admin', 'generated_at' => '2024-01-31 18:30:00'],
    ['id' => 2, 'title' => 'Clinical Statistics - December 2023', 'type' => 'clinical', 'generated_by' => 'Admin', 'generated_at' => '2023-12-31 17:45:00'],
    ['id' => 3, 'title' => 'Staff Performance Report - Q4 2023', 'type' => 'staff', 'generated_by' => 'Admin', 'generated_at' => '2023-12-31 16:15:00']
];

$settings_data = $_SESSION['clinic_settings'] ?? [
    'clinic_name' => 'Medicare Health Clinic',
    'clinic_email' => 'contact@medicareclinic.com',
    'clinic_phone' => '+1 (555) 123-4567',
    'clinic_address' => '123 Health Street, Medical City, MC 10001',
    'opening_time' => '08:00',
    'closing_time' => '20:00',
    'appointment_duration' => 30,
    'updated_at' => date('Y-m-d H:i:s')
];

$today = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Clinic Management System</title>
    <style>
        /* Main container for side-by-side layout */
.vertical-tabs-container {
    display: flex;
    min-height: 100vh;
    width: 100%;
}

/* Left Side: Vertical Tabs */
.vertical-tabs {
    display: flex;
    flex-direction: column;
    width: 220px;
    background-color: #f8f9fa;
    border-right: 1px solid #dee2e6;
    min-height: 100vh;
    position: sticky;
    top: 0;
}

.vertical-tab {
    padding: 14px 20px;
    text-align: left;
    border: none;
    background: none;
    cursor: pointer;
    border-right: 3px solid transparent;
    transition: all 0.3s ease;
    color: #495057;
    font-size: 15px;
    font-weight: 500;
}

.vertical-tab:hover {
    background-color: #e9ecef;
    color: #007bff;
    border-right: 3px solid #007bff;
}

.vertical-tab.active {
    background-color: #e9ecef;
    border-right: 3px solid #007bff;
    font-weight: 600;
    color: #007bff;
}

/* Right Side: Content Area */
.tab-content-area {
    flex: 1;
    padding: 25px;
    background-color: #ffffff;
    min-height: 100vh;
    overflow-x: auto;
}

/* Hide all tab content initially */
.tab-content {
    display: none;
}

/* Show active tab content */
.tab-content.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Quick Actions */
.quick-actions {
    margin-bottom: 30px;
    background-color: #81e1f0;
}

/* Dashboard grid layout */
.data-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 25px;
}

/* Responsive adjustments */
@media (max-width: 1024px) {
    .vertical-tabs-container {
        flex-direction: column;
    }
    
    .vertical-tabs {
        width: 100%;
        min-height: auto;
        flex-direction: row;
        overflow-x: auto;
        position: static;
    }
    
    .vertical-tab {
        border-right: none;
        border-bottom: 3px solid transparent;
        white-space: nowrap;
    }
    
    .vertical-tab:hover {
        border-right: none;
        border-bottom: 3px solid #007bff;
    }
    
    .vertical-tab.active {
        border-right: none;
        border-bottom: 3px solid #007bff;
    }
    
    .data-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .tab-content-area {
        padding: 15px;
    }
    
    .data-grid {
        gap: 15px;
    }
}
      .vertical-tabs-container {
    display: flex;
}

.vertical-tabs {
    display: flex;
    flex-direction: column;
    width: 200px;
    background-color: #f8f9fa;
    border-right: 1px solid #dee2e6;
}

.vertical-tab {
    padding: 12px 15px;
    text-align: left;
    border: none;
    background: none;
    cursor: pointer;
    border-right: 3px solid transparent;
    transition: all 0.3s ease;
    color: #333;
}

/* Hover Effect - Text Color Change */
.vertical-tab:hover {
    background-color: #e9ecef;
    color: #007bff; /* Text color changes on hover */
}

/* Active Tab */
.vertical-tab.active {
    background-color: #e9ecef;
    border-right: 3px solid #007bff;
    font-weight: bold;
    color: #007bff; /* Active tab text color */
}

/* Optional: Add icon support */
.vertical-tab::before {
    content: "▶";
    margin-right: 8px;
    font-size: 10px;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.vertical-tab:hover::before {
    opacity: 0.5;
}

.vertical-tab.active::before {
    opacity: 1;
}      :root {
            --primary: #2c3e50;
            --primary-light: #34495e;
            --secondary: #3498db;
            --secondary-light: #5dade2;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #17a2b8;
            --dark: #2c3e50;
            --light: #ecf0f1;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        /* Container */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header */
        .header {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .admin-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .admin-avatar {
            width: 60px;
            height: 60px;
            background: var(--primary);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }

        .admin-details h1 {
            color: var(--primary);
            font-size: 24px;
            margin-bottom: 5px;
        }

        .admin-details p {
            color: #666;
            font-size: 14px;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            display: flex;
            align-items: center;
            gap: 20px;
            transition: all 0.3s;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .stat-card:nth-child(1) .stat-icon { background: var(--primary); }
        .stat-card:nth-child(2) .stat-icon { background: var(--secondary); }
        .stat-card:nth-child(3) .stat-icon { background: var(--success); }
        .stat-card:nth-child(4) .stat-icon { background: var(--warning); }
        .stat-card:nth-child(5) .stat-icon { background: var(--info); }
        .stat-card:nth-child(6) .stat-icon { background: var(--danger); }

        .stat-content h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .stat-content .number {
            font-size: 32px;
            font-weight: 700;
            color: var(--dark);
        }

       .quick-actions {
    padding: 20px;
    background-color: #648e94;
    border-radius: 10px;
    margin: 20px 0;
}

.section-title {
    color: #2c3e50;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-title i {
    color: #3498db;
}

.actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 15px;
}

.action-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20px 15px;
    background-color: white;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-align: center;
    min-height: 100px;
}

.action-btn i {
    font-size: 24px;
    color: #3498db;
    margin-bottom: 10px;
    transition: all 0.3s ease;
}

.action-btn span {
    font-weight: 500;
    color: #2c3e50;
    transition: all 0.3s ease;
}

/* Hover Effect - Elevation */
.action-btn:hover {
    background-color: #3498db;
    border-color: #3498db;
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
}

.action-btn:hover i,
.action-btn:hover span {
    color: white;
}
        /* Content Sections */
        .content-section {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
            overflow: hidden;
        }

        .section-header {
            padding: 20px;
            background: var(--light);
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .section-content {
            padding: 20px;
        }

        /* Tables */
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            color: var(--dark);
            font-weight: 600;
            font-size: 14px;
            border-bottom: 2px solid #e9ecef;
        }

        .data-table td {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            font-size: 14px;
        }

        .data-table tr:hover {
            background: #f8f9fa;
        }

        /* Badges */
        .badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
        }

        .badge-active { background: #d4edda; color: #155724; }
        .badge-inactive { background: #f8d7da; color: #721c24; }
        .badge-pending { background: #fff3cd; color: #856404; }
        .badge-confirmed { background: #cce5ff; color: #004085; }
        .badge-completed { background: #d4edda; color: #155724; }
        .badge-cancelled { background: #f8d7da; color: #721c24; }
        .badge-admin { background: #dc3545; color: white; }
        .badge-doctor { background: #007bff; color: white; }
        .badge-staff { background: #28a745; color: white; }
        .badge-patient { background: #6c757d; color: white; }

        /* Buttons */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-sm { padding: 6px 12px; font-size: 12px; }

        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-light); }

        .btn-success { background: var(--success); color: white; }
        .btn-success:hover { background: #219653; }

        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: #c0392b; }

        .btn-warning { background: var(--warning); color: white; }
        .btn-warning:hover { background: #e67e22; }

        .btn-info { background: var(--info); color: white; }
        .btn-info:hover { background: #138496; }

        /* Forms */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--dark);
            font-weight: 500;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(44, 62, 80, 0.1);
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            width: 100%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .modal-header {
            padding: 20px;
            background: var(--primary);
            color: white;
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-body {
            padding: 20px;
        }

        .close-modal {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .close-modal:hover {
            background: rgba(255,255,255,0.2);
        }

        /* Form Layout */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        /* Message */
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            animation: slideIn 0.5s;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Tabs */
        .tabs {
            display: flex;
            border-bottom: 1px solid #e9ecef;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .tab {
            padding: 12px 24px;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            color: #666;
            font-weight: 500;
            font-size: 14px;
            transition: all 0.3s;
        }

        .tab:hover {
            color: var(--primary);
        }

        .tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .tab-content {
            display: none;
            animation: fadeIn 0.5s;
        }

        .tab-content.active {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Action Buttons Group */
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .actions-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .admin-info {
                flex-direction: column;
                text-align: center;
            }
        }

        @media (max-width: 480px) {
            .actions-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .tabs {
                flex-direction: column;
            }
            
            .tab {
                padding: 10px;
                border-bottom: none;
                border-left: 3px solid transparent;
            }
            
            .tab.active {
                border-left-color: var(--primary);
            }
        }

        /* Logout Button */
        .logout-btn {
            background: var(--danger);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .logout-btn:hover {
            background: #c62828;
        }

        /* Print Button */
        .print-btn {
            background: var(--info);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .print-btn:hover {
            background: #138496;
        }

        /* View Details Button */
        .view-btn {
            background: var(--info);
            color: white;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 12px;
            border: none;
            cursor: pointer;
        }

        /* Status Selector */
        .status-selector {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .status-option {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .status-option:hover {
            opacity: 0.8;
        }

        .status-option.active {
            font-weight: bold;
            transform: scale(1.05);
        }
        
@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)) !important;
        gap: 15px !important;
    }
    
    .stat-card {
        padding: 20px !important;
    }
    
    .stat-icon {
        width: 60px !important;
        height: 60px !important;
    }
    
    .number {
        font-size: 28px !important;
    }
    
    #message {
        padding: 12px 15px !important;
        font-size: 14px !important;
    }
}

@media (max-width: 480px) {
    .stats-grid {
        grid-template-columns: 1fr !important;
    }
    
    .stat-card {
        padding: 18px !important;
        gap: 15px !important;
    }
    
    .stat-icon {
        width: 50px !important;
        height: 50px !important;
    }
    
    .stat-icon img {
        width: 30px !important;
        height: 30px !important;
    }
    
    .number {
        font-size: 26px !important;
    }
}
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body><div class="container">
    <!-- Header -->
    <div class="header" style="display: flex; justify-content: space-between; align-items: center; padding: 20px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 10px; margin-bottom: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
        <div style="display: flex; align-items: center; gap: 20px;">
            <!-- Logo Image -->
            <!--div style="width: 60px; height: 60px; background: white; border-radius: 10px; padding: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                <img src="nurs.png" alt="Admin Dashboard Logo" 
                style="width: 100%; height: 100%; object-fit: contain; border-radius: 5px;">
            </div-->
            
            <!-- Admin Profile with Edit Options -->
            <div class="admin-info" style="display: flex; align-items: center; gap: 15px; position: relative;">
                <!-- Admin Avatar with Edit Icon -->
                <div style="position: relative;">
                    <div class="admin-avatar" style="width: 70px; height: 70px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; font-weight: bold; color: white; box-shadow: 0 3px 10px rgba(0,0,0,0.2);">
                        <?php echo strtoupper(substr($admin_name, 0, 1)); ?>
                    </div>
                    <!-- Edit Profile Icon -->
                    <button onclick="editProfile()" style="position: absolute; bottom: 0; right: 0; background: #4CAF50; color: white; border: 2px solid white; border-radius: 50%; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 14px;">
                        <i class="fas fa-edit"></i>
                    </button>
                </div>
                
                <!-- Admin Details with Update Options -->
                <div class="admin-details" style="position: relative;">
                    <h1 style="margin: 0; font-size: 24px; display: flex; align-items: center; gap: 10px;">
                        Welcome, <?php echo $admin_name; ?>
                        <span onclick="showAdminActions()" style="cursor: pointer; font-size: 16px; color: rgba(255,255,255,0.8);">
                            <i class="fas fa-caret-down"></i>
                        </span>
                    </h1>
                    <p style="margin: 5px 0; color: rgba(255,255,255,0.9);">Administrator Dashboard - Clinic Management System</p>
                    <small style="color: rgba(255,255,255,0.8);">
                        <i class="far fa-calendar-alt"></i> <?php echo date('F j, Y'); ?> | 
                        <i class="far fa-clock"></i> <?php echo date('h:i A'); ?>
                    </small>
                    
                    <!-- Profile Actions Dropdown -->
                    <div id="profileActions" style="display: none; position: absolute; top: 100%; left: 0; background: white; border-radius: 8px; padding: 10px 0; box-shadow: 0 5px 20px rgba(0,0,0,0.15); min-width: 200px; z-index: 1000;">
                        <div style="padding: 10px 15px; border-bottom: 4px solid #eee;">
                            <strong style="color: #333;">Profile Actions</strong>
                        </div>
                        <button onclick="changeProfileImage()" style="width: 100%; padding: 10px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-camera" style="color: #2196F3;"></i>
                            Change Photo
                        </button>
                        <button onclick="editProfileInfo()" style="width: 100%; padding: 10px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-user-edit" style="color: #FF9800;"></i>
                            Edit Profile
                        </button>
                        <button onclick="updateProfile()" style="width: 100%; padding: 10px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-sync-alt" style="color: #4CAF50;"></i>
                            Update Profile
                        </button>
                        <div style="padding: 10px 15px; border-top: 1px solid #eee; border-bottom: 1px solid #eee;">
                            <strong style="color: #333;">Account Settings</strong>
                        </div>
                        <button onclick="changePassword()" style="width: 100%; padding: 10px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-key" style="color: #9C27B0;"></i>
                            Change Password
                        </button>
                        <button onclick="deleteAccount()" style="width: 100%; padding: 10px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #e74c3c; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-trash-alt"></i>
                            Delete Account
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Right Side Actions -->
        <div style="display: flex; align-items: center; gap: 15px;">
            <!-- Notification Bell -->
            <div style="position: relative; cursor: pointer;" onclick="showNotifications()">
                <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-bell" style="font-size: 18px;"></i>
                </div>
                <span style="position: absolute; top: -5px; right: -5px; background: #e74c3c; color: white; font-size: 12px; padding: 2px 6px; border-radius: 50%; min-width: 20px; text-align: center;">3</span>
            </div>
            
            <!-- Print Button -->
            <button onclick="window.print()" style="background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 10px 20px; border-radius: 25px; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: all 0.3s; backdrop-filter: blur(5px);">
                <i class="fas fa-print"></i> Print
            </button>
            
            <!-- Logout Button -->
            <a href="../logout.php" style="background: rgba(231, 76, 60, 0.9); color: white; padding: 10px 25px; border-radius: 25px; text-decoration: none; display: flex; align-items: center; gap: 8px; transition: all 0.3s; border: none; cursor: pointer;">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
</div>

<!-- Profile Edit Modal (Inline Style) -->
<div id="profileModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 500px; width: 90%; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="margin: 0; color: #333;">Edit Profile</h2>
            <button onclick="closeProfileModal()" style="background: none; border: none; font-size: 20px; cursor: pointer; color: #999;">×</button>
        </div>
        
        <div style="text-align: center; margin-bottom: 25px;">
            <div style="width: 100px; height: 100px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 36px; font-weight: bold; color: white;">
                <?php echo strtoupper(substr($admin_name, 0, 1)); ?>
            </div>
            <input type="file" id="profileImageInput" accept="image/*" style="display: none;">
            <button onclick="document.getElementById('profileImageInput').click()" style="background: #2196F3; color: white; border: none; padding: 8px 20px; border-radius: 20px; cursor: pointer;">
                <i class="fas fa-upload"></i> Upload New Photo
            </button>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 15px;">
            <input type="text" placeholder="Full Name" value="<?php echo $admin_name; ?>" style="padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px;">
            <input type="email" placeholder="Email Address" style="padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px;">
            <input type="tel" placeholder="Phone Number" style="padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px;">
            <textarea placeholder="Bio/Description" rows="3" style="padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px; resize: vertical;"></textarea>
        </div>
        
        <div style="display: flex; gap: 10px; margin-top: 25px;">
            <button onclick="saveProfile()" style="flex: 1; background: #4CAF50; color: white; border: none; padding: 12px; border-radius: 8px; cursor: pointer; font-size: 16px;">
                <i class="fas fa-save"></i> Save Changes
            </button>
            <button onclick="closeProfileModal()" style="flex: 1; background: #f8f9fa; color: #333; border: 1px solid #ddd; padding: 12px; border-radius: 8px; cursor: pointer; font-size: 16px;">
                Cancel
            </button>
        </div>
    </div>
</div><!-- Quick Actions -->
<div style="margin: 30px 0; padding: 20px; background: #f8f9fa; border-radius: 12px;">
    <h2 style="color: #2c3e50; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; font-size: 22px; font-weight: 600;">
        <i class="fas fa-bolt" style="color: #f39c12;"></i> System Actions
    </h2>
    
    <!-- Row 1: 3 columns -->
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px;">
        <!-- Column 1 -->
        <button onclick="showModal('addUserModal')" 
                style="background: white; border: 2px solid #2196F3; border-radius: 12px; padding: 25px 20px; cursor: pointer; transition: all 0.3s ease; display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; box-shadow: 0 4px 12px rgba(33, 150, 243, 0.1);">
            <i class="fas fa-user-plus" style="font-size: 32px; color: #2196F3;"></i>
            <span style="font-weight: 600; color: #2c3e50; font-size: 16px;">Add User</span>
           <!-- Add User Button -->
<img src="admin.png" alt="Admin" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.1; position: absolute; top: 0; left: 0; z-index: 0; pointer-events: none;">
        </button>
        
        <!-- Column 2 -->
        <button onclick="showModal('addDoctorModal')" 
                style="background: white; border: 2px solid #4CAF50; border-radius: 12px; padding: 25px 20px; cursor: pointer; transition: all 0.3s ease; display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; box-shadow: 0 4px 12px rgba(76, 175, 80, 0.1);">
            <i class="fas fa-user-md" style="font-size: 32px; color: #4CAF50;"></i>
            <span style="font-weight: 600; color: #2c3e50; font-size: 16px;">Add Doctor</span>
        </button>
        
        <!-- Column 3 -->
        <button onclick="showTab('appointments')" 
                style="background: white; border: 2px solid #FF9800; border-radius: 12px; padding: 25px 20px; cursor: pointer; transition: all 0.3s ease; display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; box-shadow: 0 4px 12px rgba(255, 152, 0, 0.1);">
            <i class="fas fa-calendar-check" style="font-size: 32px; color: #FF9800;"></i>
            <span style="font-weight: 600; color: #2c3e50; font-size: 16px;">View Appointments</span>
        </button>
    </div>
    
    <!-- Row 2: 3 columns -->
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;">
        <!-- Column 1 -->
        <button onclick="showModal('generateReportModal')" 
                style="background: white; border: 2px solid #9C27B0; border-radius: 12px; padding: 25px 20px; cursor: pointer; transition: all 0.3s ease; display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; box-shadow: 0 4px 12px rgba(156, 39, 176, 0.1);">
            <i class="fas fa-file-download" style="font-size: 32px; color: #9C27B0;"></i>
            <span style="font-weight: 600; color: #2c3e50; font-size: 16px;">Generate Report</span>
        </button>
        
        <!-- Column 2 -->
        <button onclick="showTab('users')" 
                style="background: white; border: 2px solid #00BCD4; border-radius: 12px; padding: 25px 20px; cursor: pointer; transition: all 0.3s ease; display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; box-shadow: 0 4px 12px rgba(0, 188, 212, 0.1);">
            <i class="fas fa-users-cog" style="font-size: 32px; color: #00BCD4;"></i>
            <span style="font-weight: 600; color: #2c3e50; font-size: 16px;">Manage Users</span>
        </button>
        
        <!-- Column 3 -->
        <button onclick="showTab('doctors')" 
                style="background: white; border: 2px solid #3F51B5; border-radius: 12px; padding: 25px 20px; cursor: pointer; transition: all 0.3s ease; display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; box-shadow: 0 4px 12px rgba(63, 81, 181, 0.1);">
            <i class="fas fa-stethoscope" style="font-size: 32px; color: #3F51B5;"></i>
            <span style="font-weight: 600; color: #2c3e50; font-size: 16px;">Manage Doctors</span>
        </button>
    </div>
    
    <!-- Row 3: 2 buttons centered -->
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 20px;">
        <!-- Empty column -->
        <div></div>
        
        <!-- Middle column with 2 buttons side by side -->
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
            <button onclick="showTab('reports')" 
                    style="background: white; border: 2px solid #E91E63; border-radius: 12px; padding: 25px 20px; cursor: pointer; transition: all 0.3s ease; display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; box-shadow: 0 4px 12px rgba(233, 30, 99, 0.1);">
                <i class="fas fa-chart-bar" style="font-size: 32px; color: #E91E63;"></i>
                <span style="font-weight: 600; color: #2c3e50; font-size: 16px;">View Reports</span>
            </button>
            
            <button onclick="showTab('settings')" 
                    style="background: white; border: 2px solid #FFC107; border-radius: 12px; padding: 25px 20px; cursor: pointer; transition: all 0.3s ease; display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; box-shadow: 0 4px 12px rgba(255, 193, 7, 0.1);">
                <i class="fas fa-cogs" style="font-size: 32px; color: #FFC107;"></i>
                <span style="font-weight: 600; color: #2c3e50; font-size: 16px;">System Settings</span>
            </button>
        </div>
        
        <!-- Empty column -->
        <div></div>
    </div>
</div>

<!-- Hover Effects Script -->
<script>
// Add hover effects to all buttons
document.querySelectorAll('button[onclick]').forEach(button => {
    button.addEventListener('mouseenter', function() {
        const colors = {
            'addUserModal': '#2196F3',
            'addDoctorModal': '#4CAF50',
            'appointments': '#FF9800',
            'generateReportModal': '#9C27B0',
            'users': '#00BCD4',
            'doctors': '#3F51B5',
            'reports': '#E91E63',
            'settings': '#FFC107'
        };
        
        // Find which color to use based on onclick content
        let buttonColor = '#2196F3'; // default
        for (const [key, color] of Object.entries(colors)) {
            if (this.getAttribute('onclick').includes(key)) {
                buttonColor = color;
                break;
            }
        }
        
        this.style.transform = 'translateY(-5px)';
        this.style.boxShadow = `0 8px 25px rgba(${parseInt(buttonColor.slice(1,3), 16)}, ${parseInt(buttonColor.slice(3,5), 16)}, ${parseInt(buttonColor.slice(5,7), 16)}, 0.2)`;
        this.style.background = `linear-gradient(135deg, white, ${buttonColor}10)`;
        this.style.borderColor = buttonColor;
    });
    
    button.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = this.getAttribute('onclick').includes('addUserModal') ? 
            '0 4px 12px rgba(33, 150, 243, 0.1)' :
            this.getAttribute('onclick').includes('addDoctorModal') ? 
            '0 4px 12px rgba(76, 175, 80, 0.1)' :
            this.getAttribute('onclick').includes('appointments') ? 
            '0 4px 12px rgba(255, 152, 0, 0.1)' :
            this.getAttribute('onclick').includes('generateReportModal') ? 
            '0 4px 12px rgba(156, 39, 176, 0.1)' :
            this.getAttribute('onclick').includes('users') ? 
            '0 4px 12px rgba(0, 188, 212, 0.1)' :
            this.getAttribute('onclick').includes('doctors') ? 
            '0 4px 12px rgba(63, 81, 181, 0.1)' :
            this.getAttribute('onclick').includes('reports') ? 
            '0 4px 12px rgba(233, 30, 99, 0.1)' :
            '0 4px 12px rgba(255, 193, 7, 0.1)';
        this.style.background = 'white';
    });
});
</script>

<!-- Responsive Design Inline -->
<div style="display: none;">
    <style>
    @media (max-width: 1024px) {
        .quick-actions > div[style*="grid-template-columns: repeat(3, 1fr)"] {
            grid-template-columns: repeat(2, 1fr) !important;
        }
        
        .quick-actions button {
            padding: 20px 15px !important;
        }
        
        .quick-actions i {
            font-size: 28px !important;
        }
    }
    
    @media (max-width: 768px) {
        .quick-actions > div[style*="grid-template-columns: repeat(3, 1fr)"] {
            grid-template-columns: 1fr !important;
        }
        
        .quick-actions > div[style*="grid-template-columns: repeat(2, 1fr)"] {
            grid-template-columns: 1fr !important;
        }
        
        .quick-actions button {
            padding: 18px 15px !important;
        }
        
        .quick-actions i {
            font-size: 26px !important;
        }
        
        .quick-actions span {
            font-size: 15px !important;
        }
    }
    </style>
</div>

  <div class="vertical-tabs-container">
    <!-- Left Side: Vertical Tabs -->
    <div class="vertical-tabs" id="mainTabs">
        <div class="vertical-tab active" onclick="showTab('dashboard')">Dashboard</div>
        <div class="vertical-tab" onclick="showTab('users')">Users</div>
        <div class="vertical-tab" onclick="showTab('doctors')">Doctors</div>
        <div class="vertical-tab" onclick="showTab('appointments')">Appointments</div>
        <div class="vertical-tab" onclick="showTab('reports')">Reports</div>
        <div class="vertical-tab" onclick="showTab('settings')">Settings</div>
    </div>
    
    <!-- Right Side: Tab Content Area -->
    <div id="tabContent" class="tab-content-area">
        <!-- Dashboard Tab -->
        <div id="dashboard" class="tab-content active">
            <div class="quick-actions">
                <h2 class="section-title"><i class="fas fa-bolt"></i> display Actions</h2>
                <div class="actions-grid">
                    <button class="action-btn" onclick="showModal('addUserModal')">
                        <i class="fas fa-user-plus"></i>
                        <span>Add User</span>
                    </button>
                    
                    <button class="action-btn" onclick="showModal('addDoctorModal')">
                        <i class="fas fa-user-md"></i>
                        <span>Add Doctor</span>
                    </button>
                    
                    <button class="action-btn" onclick="showTab('appointments')">
                        <i class="fas fa-calendar-check"></i>
                        <span>View Appointments</span>
                    </button>
                    
                    <button class="action-btn" onclick="showModal('generateReportModal')">
                        <i class="fas fa-file-download"></i>
                        <span>Generate Report</span>
                    </button>
                    
                    <button class="action-btn" onclick="showTab('users')">
                        <i class="fas fa-users-cog"></i>
                        <span>Manage Users</span>
                    </button>
                    
                    <button class="action-btn" onclick="showTab('doctors')">
                        <i class="fas fa-stethoscope"></i>
                        <span>Manage Doctors</span>
                    </button>
                    
                    <button class="action-btn" onclick="showTab('reports')">
                        <i class="fas fa-chart-bar"></i>
                        <span>View Reports</span>
                    </button>
                    
                    <button class="action-btn" onclick="showTab('settings')">
                        <i class="fas fa-cogs"></i>
                        <span>System Settings</span>
                    </button>
                </div>
            </div>

            <div class="data-grid">
                <!-- Recent Appointments -->
                <div class="content-section">
                    <div class="section-header">
                        <h3><i class="fas fa-calendar-day"></i> Today's Appointments</h3>
                        <button class="btn btn-primary btn-sm" onclick="showTab('appointments')">View All</button>
                    </div>
                    <div class="section-content">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <th>Patient</th>
                                    <th>Doctor</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($appointments_data as $appointment): ?>
                                <tr>
                                    <td><?php echo $appointment['time']; ?></td>
                                    <td><?php echo $appointment['patient_name']; ?></td>
                                    <td><?php echo $appointment['doctor_name']; ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $appointment['status']; ?>">
                                            <?php echo ucfirst($appointment['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn btn-primary btn-sm" onclick="viewDetails('appointment', <?php echo $appointment['id']; ?>)">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-success btn-sm" onclick="updateAppointmentStatus(<?php echo $appointment['id']; ?>, 'confirmed')">
                                                Confirm
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Active Doctors -->
                <div class="content-section">
                    <div class="section-header">
                        <h3><i class="fas fa-user-md"></i> Active Doctors</h3>
                        <button class="btn btn-primary btn-sm" onclick="showTab('doctors')">View All</button>
                    </div>
                    <div class="section-content">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Doctor</th>
                                    <th>Specialization</th>
                                    <th>Experience</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach(array_slice($doctors_data, 0, 5) as $doctor): ?>
                                <tr>
                                    <td><?php echo $doctor['name']; ?></td>
                                    <td><?php echo $doctor['specialization']; ?></td>
                                    <td><?php echo $doctor['experience']; ?> years</td>
                                    <td>
                                        <span class="badge badge-<?php echo $doctor['status']; ?>">
                                            <?php echo ucfirst($doctor['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Users Tab -->
        <div id="users" class="tab-content">
            <div class="content-section">
                <div class="section-header">
                    <h3><i class="fas fa-users"></i> Manage Users</h3>
                    <button class="btn btn-success" onclick="showModal('addUserModal')">
                        <i class="fas fa-user-plus"></i> Add User
                    </button>
                </div>
                <div class="section-content">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($users_data as $user): ?>
                            <tr>
                                <td>USR-<?php echo $user['id']; ?></td>
                                <td><?php echo $user['name']; ?></td>
                                <td><?php echo $user['email']; ?></td>
                                <td><span class="badge badge-<?php echo $user['role']; ?>"><?php echo ucfirst($user['role']); ?></span></td>
                                <td>
                                    <span class="badge badge-<?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span>
                                </td>
                                <td><?php echo $user['created_at']; ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-primary btn-sm" onclick="viewDetails('user', <?php echo $user['id']; ?>)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-info btn-sm" onclick="editUser(<?php echo $user['id']; ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <div class="btn-group">
                                            <button class="btn btn-warning btn-sm dropdown-toggle" type="button" data-toggle="dropdown">
                                                <i class="fas fa-exchange-alt"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <button class="dropdown-item" onclick="updateUserStatus(<?php echo $user['id']; ?>, 'active')">Active</button>
                                                <button class="dropdown-item" onclick="updateUserStatus(<?php echo $user['id']; ?>, 'inactive')">Inactive</button>
                                            </div>
                                        </div>
                                        <button class="btn btn-danger btn-sm" onclick="deleteUser(<?php echo $user['id']; ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Doctors Tab -->
        <div id="doctors" class="tab-content">
            <div class="content-section">
                <div class="section-header">
                    <h3><i class="fas fa-user-md"></i> Manage Doctors</h3>
                    <button class="btn btn-success" onclick="showModal('addDoctorModal')">
                        <i class="fas fa-user-md"></i> Add Doctor
                    </button>
                </div>
                <div class="section-content">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Specialization</th>
                                <th>Experience</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($doctors_data as $doctor): ?>
                            <tr>
                                <td>DR-<?php echo $doctor['id']; ?></td>
                                <td><?php echo $doctor['name']; ?></td>
                                <td><?php echo $doctor['specialization']; ?></td>
                                <td><?php echo $doctor['experience']; ?> years</td>
                                <td><?php echo $doctor['phone']; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $doctor['status']; ?>"><?php echo ucfirst($doctor['status']); ?></span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-primary btn-sm" onclick="viewDetails('doctor', <?php echo $doctor['id']; ?>)">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        <button class="btn btn-info btn-sm" onclick="editDoctor(<?php echo $doctor['id']; ?>)">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <div class="status-selector">
                                            <span class="badge badge-active status-option <?php echo $doctor['status'] == 'active' ? 'active' : ''; ?>" 
                                                  onclick="updateDoctorStatus(<?php echo $doctor['id']; ?>, 'active')">Active</span>
                                            <span class="badge badge-inactive status-option <?php echo $doctor['status'] == 'inactive' ? 'active' : ''; ?>" 
                                                  onclick="updateDoctorStatus(<?php echo $doctor['id']; ?>, 'inactive')">Inactive</span>
                                        </div>
                                        <button class="btn btn-danger btn-sm" onclick="deleteDoctor(<?php echo $doctor['id']; ?>)">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Appointments Tab -->
        <div id="appointments" class="tab-content">
            <div class="content-section">
                <div class="section-header">
                    <h3><i class="fas fa-calendar-check"></i> Manage Appointments</h3>
                    <div style="display: flex; gap: 10px;">
                        <input type="date" id="filterDate" value="<?php echo $today; ?>" class="form-control" style="width: 150px;">
                        <select id="filterStatus" class="form-control" style="width: 150px;">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                        <button class="btn btn-primary" onclick="filterAppointments()">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                    </div>
                </div>
                <div class="section-content">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Patient</th>
                                <th>Doctor</th>
                                <th>Date & Time</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($appointments_data as $appointment): ?>
                            <tr>
                                <td>APT-<?php echo $appointment['id']; ?></td>
                                <td><?php echo $appointment['patient_name']; ?></td>
                                <td><?php echo $appointment['doctor_name']; ?></td>
                                <td>
                                    <?php echo date('M d, Y', strtotime($appointment['date'])); ?><br>
                                    <small><?php echo $appointment['time']; ?></small>
                                </td>
                                <td><?php echo $appointment['reason']; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $appointment['status']; ?>">
                                        <?php echo ucfirst($appointment['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-primary btn-sm" onclick="viewDetails('appointment', <?php echo $appointment['id']; ?>)">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        <button class="btn btn-info btn-sm" onclick="editAppointment(<?php echo $appointment['id']; ?>)">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <div class="status-selector">
                                            <span class="badge badge-pending status-option <?php echo $appointment['status'] == 'pending' ? 'active' : ''; ?>" 
                                                  onclick="updateAppointmentStatus(<?php echo $appointment['id']; ?>, 'pending')">Pending</span>
                                            <span class="badge badge-confirmed status-option <?php echo $appointment['status'] == 'confirmed' ? 'active' : ''; ?>" 
                                                  onclick="updateAppointmentStatus(<?php echo $appointment['id']; ?>, 'confirmed')">Confirm</span>
                                            <span class="badge badge-completed status-option <?php echo $appointment['status'] == 'completed' ? 'active' : ''; ?>" 
                                                  onclick="updateAppointmentStatus(<?php echo $appointment['id']; ?>, 'completed')">Complete</span>
                                            <span class="badge badge-cancelled status-option <?php echo $appointment['status'] == 'cancelled' ? 'active' : ''; ?>" 
                                                  onclick="updateAppointmentStatus(<?php echo $appointment['id']; ?>, 'cancelled')">Cancel</span>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Reports Tab -->
        <div id="reports" class="tab-content">
            <div class="content-section">
                <div class="section-header">
                    <h3><i class="fas fa-chart-bar"></i> Reports & Analytics</h3>
                    <button class="btn btn-success" onclick="showModal('generateReportModal')">
                        <i class="fas fa-plus"></i> Generate Report
                    </button>
                </div>
                <div class="section-content">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Report ID</th>
                                <th>Title</th>
                                <th>Type</th>
                                <th>Generated By</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($reports_data as $report): ?>
                            <tr>
                                <td>REP-<?php echo $report['id']; ?></td>
                                <td><?php echo $report['title']; ?></td>
                                <td><span class="badge" style="background: #6c757d; color: white;"><?php echo ucfirst($report['type']); ?></span></td>
                                <td><?php echo $report['generated_by']; ?></td>
                                <td><?php echo date('M d, Y H:i', strtotime($report['generated_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-primary btn-sm" onclick="viewReport(<?php echo $report['id']; ?>)">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        <button class="btn btn-success btn-sm" onclick="downloadReport(<?php echo $report['id']; ?>)">
                                            <i class="fas fa-download"></i> Download
                                        </button>
                                        <button class="btn btn-info btn-sm" onclick="printReport(<?php echo $report['id']; ?>)">
                                            <i class="fas fa-print"></i> Print
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Settings Tab -->
        <div id="settings" class="tab-content">
            <div class="content-section">
                <div class="section-header">
                    <h3><i class="fas fa-cogs"></i> System Settings</h3>
                    <button class="btn btn-primary" onclick="saveSettings()">
                        <i class="fas fa-save"></i> Save All Settings
                    </button>
                </div>
                <div class="section-content">
                    <form method="POST" id="settingsForm">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Clinic Name *</label>
                                <input type="text" name="clinic_name" class="form-control" value="<?php echo $settings_data['clinic_name']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Clinic Email *</label>
                                <input type="email" name="clinic_email" class="form-control" value="<?php echo $settings_data['clinic_email']; ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Clinic Phone *</label>
                                <input type="text" name="clinic_phone" class="form-control" value="<?php echo $settings_data['clinic_phone']; ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Appointment Duration (minutes)</label>
                                <input type="number" name="appointment_duration" class="form-control" value="<?php echo $settings_data['appointment_duration']; ?>" min="15" max="120">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Opening Time</label>
                                <input type="time" name="opening_time" class="form-control" value="<?php echo $settings_data['opening_time']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Closing Time</label>
                                <input type="time" name="closing_time" class="form-control" value="<?php echo $settings_data['closing_time']; ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Clinic Address *</label>
                            <textarea name="clinic_address" class="form-control" rows="3" required><?php echo $settings_data['clinic_address']; ?></textarea>
                        </div>
                        
                        <div style="text-align: center; margin-top: 30px;">
                            <button type="submit" name="update_settings" class="btn btn-success" style="padding: 12px 40px;">
                                <i class="fas fa-save"></i> Save Settings
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modals -->

<!-- Add User Modal -->
<div id="addUserModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-user-plus"></i> Add New User</h3>
            <button class="close-modal" onclick="closeModal('addUserModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter full name" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Email Address *</label>
                        <input type="email" name="email" class="form-control" placeholder="user@example.com" required>
                    </div>
                    <div class="form-group">
                        <label>Password *</label>
                        <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Role *</label>
                    <select name="role" class="form-control" required>
                        <option value="">Select Role</option>
                        <option value="admin">Administrator</option>
                        <option value="doctor">Doctor</option>
                        <option value="staff">Staff</option>
                        <option value="patient">Patient</option>
                    </select>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="button" class="btn" onclick="closeModal('addUserModal')">Cancel</button>
                    <button type="submit" name="add_user" class="btn btn-success">
                        <i class="fas fa-user-plus"></i> Add User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Doctor Modal -->
<div id="addDoctorModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-user-md"></i> Add New Doctor</h3>
            <button class="close-modal" onclick="closeModal('addDoctorModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>Doctor Name *</label>
                    <input type="text" name="doctor_name" class="form-control" placeholder="Dr. First Last" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Specialization *</label>
                        <input type="text" name="specialization" class="form-control" placeholder="e.g., Cardiology" required>
                    </div>
                    <div class="form-group">
                        <label>Experience (Years) *</label>
                        <input type="number" name="experience" class="form-control" min="0" max="50" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Phone Number *</label>
                        <input type="text" name="phone" class="form-control" placeholder="+1 234 567 8900" required>
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email" class="form-control" placeholder="doctor@clinic.com">
                    </div>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="button" class="btn" onclick="closeModal('addDoctorModal')">Cancel</button>
                    <button type="submit" name="add_doctor" class="btn btn-success">
                        <i class="fas fa-user-md"></i> Add Doctor
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Generate Report Modal -->
<div id="generateReportModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-file-download"></i> Generate Report</h3>
            <button class="close-modal" onclick="closeModal('generateReportModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>Report Type *</label>
                    <select name="report_type" class="form-control" required>
                        <option value="">Select Report Type</option>
                        <option value="financial">Financial Report</option>
                        <option value="clinical">Clinical Report</option>
                        <option value="staff">Staff Performance</option>
                        <option value="patient">Patient Statistics</option>
                        <option value="appointment">Appointment Analysis</option>
                        <option value="inventory">Inventory Report</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Start Date *</label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo date('Y-m-01'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>End Date *</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo $today; ?>" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Report Format</label>
                    <select class="form-control">
                        <option value="pdf">PDF Document</option>
                        <option value="excel">Excel Spreadsheet</option>
                        <option value="csv">CSV File</option>
                        <option value="print">Printable Format</option>
                    </select>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="button" class="btn" onclick="closeModal('generateReportModal')">Cancel</button>
                    <button type="submit" name="generate_report" class="btn btn-success">
                        <i class="fas fa-download"></i> Generate Report
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Details Modal -->
<div id="viewDetailsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="viewModalTitle"></h3>
            <button class="close-modal" onclick="closeModal('viewDetailsModal')">&times;</button>
        </div>
        <div class="modal-body" id="viewModalContent">
            <!-- Content will be loaded here -->
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="editModalTitle"></h3>
            <button class="close-modal" onclick="closeModal('editModal')">&times;</button>
        </div>
        <div class="modal-body" id="editModalContent">
            <!-- Edit form will be loaded here -->
        </div>
    </div>
</div>

<script>
    
<!-- Required JavaScript Functions -->

// Function to hide message
function hideMessage() {
    const messageElement = document.getElementById('message');
    if (messageElement) {
        messageElement.style.display = 'none';
    }
}

// Function to show tab (from your existing code)
function showTab(tabName) {
    // Hide all tab content
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.vertical-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab content
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
    
    // Add active class to clicked tab
    const clickedTab = document.querySelector(`.vertical-tab[onclick*="${tabName}"]`);
    if (clickedTab) {
        clickedTab.classList.add('active');
    }
    
    // Scroll to top of content area
    document.querySelector('.tab-content-area').scrollTop = 0;
}

// Function to show modal
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

// Function to close modal
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Hover effects for stat cards
document.querySelectorAll('.stat-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-5px)';
        this.style.boxShadow = '0 10px 25px rgba(0,0,0,0.12)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = '0 3px 15px rgba(0,0,0,0.08)';
    });
    
    // Touch devices support
    card.addEventListener('touchstart', function() {
        this.style.transform = 'translateY(-3px)';
        this.style.boxShadow = '0 8px 20px rgba(0,0,0,0.1)';
    });
    
    card.addEventListener('touchend', function() {
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = '0 3px 15px rgba(0,0,0,0.08)';
    });
});

// Auto-hide message after 5 seconds
<?php if ($message): ?>
setTimeout(function() {
    hideMessage();
}, 5000);
<?php endif; ?>

// Close message on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        hideMessage();
    }
});

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-backdrop')) {
        closeModal(e.target.id);
    }
});


    function showTab(tabName) {
    // Hide all tab content
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.vertical-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab content
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
    
    // Add active class to clicked tab
    const clickedTab = document.querySelector(`.vertical-tab[onclick*="${tabName}"]`);
    if (clickedTab) {
        clickedTab.classList.add('active');
    }
}
// Tab Navigation
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName).classList.add('active');
    
    // Highlight active tab
    document.querySelectorAll('.tab').forEach(tab => {
        if (tab.textContent.trim().toLowerCase() === tabName.toLowerCase() || 
            tab.onclick.toString().includes(tabName)) {
            tab.classList.add('active');
        }
    });
}

// Modal Functions
function showModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

// Auto-hide message after 5 seconds
setTimeout(() => {
    const message = document.getElementById('message');
    if (message) {
        message.style.display = 'none';
    }
}, 5000);

// View Details Function
function viewDetails(type, id) {
    const title = document.getElementById('viewModalTitle');
    const content = document.getElementById('viewModalContent');
    
    let details = '';
    let modalTitle = '';
    
    switch(type) {
        case 'user':
            modalTitle = 'User Details';
            details = `
                <div style="margin-bottom: 20px;">
                    <h4 style="color: var(--primary); margin-bottom: 15px;">User Information</h4>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div><strong>User ID:</strong> USR-${id}</div>
                        <div><strong>Status:</strong> <span class="badge badge-active">Active</span></div>
                        <div><strong>Name:</strong> Sample User ${id}</div>
                        <div><strong>Email:</strong> user${id}@example.com</div>
                        <div><strong>Role:</strong> <span class="badge badge-patient">Patient</span></div>
                        <div><strong>Created:</strong> ${new Date().toLocaleDateString()}</div>
                    </div>
                </div>
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h5 style="color: var(--dark); margin-bottom: 10px;">Recent Activity</h5>
                    <ul style="list-style: none; padding: 0;">
                        <li style="padding: 8px 0; border-bottom: 1px solid #ddd;">Last Login: Today at 10:30 AM</li>
                        <li style="padding: 8px 0; border-bottom: 1px solid #ddd;">Appointments: 5 total</li>
                        <li style="padding: 8px 0;">Last Appointment: Yesterday</li>
                    </ul>
                </div>
            `;
            break;
            
        case 'doctor':
            modalTitle = 'Doctor Details';
            details = `
                <div style="margin-bottom: 20px;">
                    <h4 style="color: var(--primary); margin-bottom: 15px;">Doctor Information</h4>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div><strong>Doctor ID:</strong> DR-${id}</div>
                        <div><strong>Status:</strong> <span class="badge badge-active">Active</span></div>
                        <div><strong>Name:</strong> Dr. Sample Doctor ${id}</div>
                        <div><strong>Specialization:</strong> Cardiology</div>
                        <div><strong>Experience:</strong> ${5 + id} years</div>
                        <div><strong>Phone:</strong> +1 234 567 89${id}0</div>
                        <div><strong>Email:</strong> doctor${id}@clinic.com</div>
                        <div><strong>Schedule:</strong> Mon-Fri, 9AM-5PM</div>
                    </div>
                </div>
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                    <h5 style="color: var(--dark); margin-bottom: 10px;">Performance Statistics</h5>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; text-align: center;">
                        <div style="padding: 10px; background: white; border-radius: 8px;">
                            <div style="font-size: 24px; font-weight: bold; color: var(--primary);">${20 + id}</div>
                            <div style="font-size: 12px; color: #666;">Today's Patients</div>
                        </div>
                        <div style="padding: 10px; background: white; border-radius: 8px;">
                            <div style="font-size: 24px; font-weight: bold; color: var(--success);">${150 + id*10}</div>
                            <div style="font-size: 12px; color: #666;">Monthly Patients</div>
                        </div>
                        <div style="padding: 10px; background: white; border-radius: 8px;">
                            <div style="font-size: 24px; font-weight: bold; color: var(--info);">98%</div>
                            <div style="font-size: 12px; color: #666;">Satisfaction</div>
                        </div>
                    </div>
                </div>
            `;
            break;
            
        case 'appointment':
            modalTitle = 'Appointment Details';
            details = `
                <div style="margin-bottom: 20px;">
                    <h4 style="color: var(--primary); margin-bottom: 15px;">Appointment Information</h4>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div><strong>Appointment ID:</strong> APT-${id}</div>
                        <div><strong>Status:</strong> <span class="badge badge-confirmed">Confirmed</span></div>
                        <div><strong>Patient:</strong> Patient ${id}</div>
                        <div><strong>Doctor:</strong> Dr. Doctor ${id}</div>
                        <div><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>
                        <div><strong>Time:</strong> ${9 + id}:00 AM</div>
                        <div><strong>Reason:</strong> Regular Checkup</div>
                        <div><strong>Duration:</strong> 30 minutes</div>
                    </div>
                </div>
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                    <h5 style="color: var(--dark); margin-bottom: 10px;">Notes</h5>
                    <p style="margin: 0; color: #666;">Patient coming in for regular health checkup. No special requirements noted.</p>
                </div>
            `;
            break;
    }
    
    title.textContent = modalTitle;
    content.innerHTML = details;
    showModal('viewDetailsModal');
}

// Edit Functions
function editUser(userId) {
    const title = document.getElementById('editModalTitle');
    const content = document.getElementById('editModalContent');
    
    title.textContent = 'Edit User';
    content.innerHTML = `
        <form onsubmit="saveEdit('user', ${userId}); return false;">
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" id="editUserName" class="form-control" value="User ${userId}" required>
            </div>
            
            <div class="form-group">
                <label>Email Address *</label>
                <input type="email" id="editUserEmail" class="form-control" value="user${userId}@example.com" required>
            </div>
            
            <div class="form-group">
                <label>Role *</label>
                <select id="editUserRole" class="form-control" required>
                    <option value="patient">Patient</option>
                    <option value="doctor">Doctor</option>
                    <option value="staff">Staff</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Status *</label>
                <select id="editUserStatus" class="form-control" required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <button type="button" class="btn" onclick="closeModal('editModal')">Cancel</button>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </div>
        </form>
    `;
    
    showModal('editModal');
}

function editDoctor(doctorId) {
    const title = document.getElementById('editModalTitle');
    const content = document.getElementById('editModalContent');
    
    title.textContent = 'Edit Doctor';
    content.innerHTML = `
        <form onsubmit="saveEdit('doctor', ${doctorId}); return false;">
            <div class="form-group">
                <label>Doctor Name *</label>
                <input type="text" id="editDoctorName" class="form-control" value="Dr. Doctor ${doctorId}" required>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Specialization *</label>
                    <input type="text" id="editDoctorSpecialization" class="form-control" value="Cardiology" required>
                </div>
                <div class="form-group">
                    <label>Experience (Years) *</label>
                    <input type="number" id="editDoctorExperience" class="form-control" value="${5 + doctorId}" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Phone Number *</label>
                    <input type="text" id="editDoctorPhone" class="form-control" value="+1 234 567 89${doctorId}0" required>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" id="editDoctorEmail" class="form-control" value="doctor${doctorId}@clinic.com">
                </div>
            </div>
            
            <div class="form-group">
                <label>Status *</label>
                <select id="editDoctorStatus" class="form-control" required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <button type="button" class="btn" onclick="closeModal('editModal')">Cancel</button>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </div>
        </form>
    `;
    
    showModal('editModal');
}

function editAppointment(appointmentId) {
    const title = document.getElementById('editModalTitle');
    const content = document.getElementById('editModalContent');
    
    title.textContent = 'Edit Appointment';
    content.innerHTML = `
        <form onsubmit="saveEdit('appointment', ${appointmentId}); return false;">
            <div class="form-row">
                <div class="form-group">
                    <label>Patient *</label>
                    <select id="editAppointmentPatient" class="form-control" required>
                        <option value="patient1">Patient 1</option>
                        <option value="patient2">Patient 2</option>
                        <option value="patient3">Patient 3</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Doctor *</label>
                    <select id="editAppointmentDoctor" class="form-control" required>
                        <option value="doctor1">Dr. Doctor 1</option>
                        <option value="doctor2">Dr. Doctor 2</option>
                        <option value="doctor3">Dr. Doctor 3</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Date *</label>
                    <input type="date" id="editAppointmentDate" class="form-control" value="${new Date().toISOString().split('T')[0]}" required>
                </div>
                <div class="form-group">
                    <label>Time *</label>
                    <input type="time" id="editAppointmentTime" class="form-control" value="09:00" required>
                </div>
            </div>
            
            <div class="form-group">
                <label>Reason *</label>
                <textarea id="editAppointmentReason" class="form-control" rows="3" required>Regular Checkup</textarea>
            </div>
            
            <div class="form-group">
                <label>Status *</label>
                <select id="editAppointmentStatus" class="form-control" required>
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <button type="button" class="btn" onclick="closeModal('editModal')">Cancel</button>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save"></i> Save Changes
                </button>
            </div>
        </form>
    `;
    
    showModal('editModal');
}

// Save Edit Function
function saveEdit(type, id) {
    const notification = `${type.charAt(0).toUpperCase() + type.slice(1)} ${id} updated successfully!`;
    showNotification(notification, 'success');
    closeModal('editModal');
    // In real implementation, this would make an AJAX call to save changes
}

// Status Update Functions
function updateUserStatus(userId, status) {
    if (confirm(`Change user status to ${status}?`)) {
        window.location.href = `?update_status&id=${userId}&status=${status}`;
    }
}

function updateDoctorStatus(doctorId, status) {
    if (confirm(`Change doctor status to ${status}?`)) {
        window.location.href = `?update_doctor_status&id=${doctorId}&status=${status}`;
    }
}

function updateAppointmentStatus(appointmentId, status) {
    if (confirm(`Change appointment status to ${status}?`)) {
        window.location.href = `?update_appointment_status&id=${appointmentId}&status=${status}`;
    }
}

// Delete Functions
function deleteUser(userId) {
    if (confirm(`Are you sure you want to delete user ${userId}? This action cannot be undone.`)) {
        window.location.href = `?delete_user&id=${userId}`;
    }
}

function deleteDoctor(doctorId) {
    if (confirm(`Are you sure you want to delete doctor ${doctorId}? This action cannot be undone.`)) {
        window.location.href = `?delete_doctor&id=${doctorId}`;
    }
}

// Filter Appointments
function filterAppointments() {
    const date = document.getElementById('filterDate').value;
    const status = document.getElementById('filterStatus').value;
    
    // In real implementation, this would filter the appointments table
    showNotification(`Filtering appointments for ${date} with status: ${status || 'All'}`, 'info');
}

// Save Settings
function saveSettings() {
    document.getElementById('settingsForm').submit();
}

// View Report
function viewReport(reportId) {
    showNotification(`Opening report ${reportId}...`, 'info');
    // In real implementation, this would open the report
}

function downloadReport(reportId) {
    showNotification(`Downloading report ${reportId}...`, 'success');
    // In real implementation, this would download the report
}

function printReport(reportId) {
    window.print();
}

// Notification System
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `message ${type}`;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '1001';
    notification.style.minWidth = '300px';
    notification.innerHTML = `
        <div>
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
            ${message}
        </div>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 3000);
}

// Initialize with dashboard
document.addEventListener('DOMContentLoaded', function() {
    showTab('dashboard');
    
    // Initialize date inputs
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        if (!input.value) {
            input.value = '<?php echo $today; ?>';
        }
    });
    
    // Initialize time inputs
    const timeInputs = document.querySelectorAll('input[type="time"]');
    timeInputs.forEach(input => {
        if (!input.value) {
            const now = new Date();
            input.value = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
        }
    });
});
// Toggle profile actions dropdown
function showAdminActions() {
    const dropdown = document.getElementById('profileActions');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('profileActions');
    const target = event.target;
    
    if (!target.closest('.admin-details')) {
        dropdown.style.display = 'none';
    }
});

// Profile functions
function editProfile() {
    document.getElementById('profileModal').style.display = 'flex';
}

function closeProfileModal() {
    document.getElementById('profileModal').style.display = 'none';
}

function changeProfileImage() {
    document.getElementById('profileImageInput').click();
}

function editProfileInfo() {
    editProfile();
}

function updateProfile() {
    // Add update profile logic here
    alert('Profile updated successfully!');
    closeProfileModal();
}

function changePassword() {
    // Add change password logic here
    alert('Change password feature coming soon!');
}

function deleteAccount() {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
        // Add delete account logic here
        alert('Account deletion initiated. Please contact support for confirmation.');
    }
}

function saveProfile() {
    // Add save profile logic here
    alert('Profile saved successfully!');
    closeProfileModal();
}

function showNotifications() {
    // Add notifications logic here
    alert('You have 3 new notifications');
}
</script>

</body>
</html>