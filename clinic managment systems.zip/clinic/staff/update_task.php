<?php
session_start();
require "../db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit();
}

if (isset($_GET['task_id']) && isset($_GET['status'])) {
    $task_id = intval($_GET['task_id']);
    $status = $conn->real_escape_string($_GET['status']);
    
    $sql = "UPDATE staff_tasks SET status = '$status' WHERE id = $task_id";
    
    if ($conn->query($sql)) {
        header("Location: staff_dashboard.php?message=Task updated successfully&type=success");
    } else {
        header("Location: staff_dashboard.php?message=Error updating task&type=error");
    }
    exit();
}
?>