<?php
session_start();
require "../db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit();
}

if (isset($_GET['item_id']) && isset($_GET['quantity'])) {
    $item_id = intval($_GET['item_id']);
    $quantity = intval($_GET['quantity']);
    
    $sql = "UPDATE inventory SET quantity = quantity + $quantity WHERE id = $item_id";
    
    if ($conn->query($sql)) {
        header("Location: staff_dashboard.php?message=Item restocked successfully&type=success");
    } else {
        header("Location: staff_dashboard.php?message=Error restocking item&type=error");
    }
    exit();
}
?>