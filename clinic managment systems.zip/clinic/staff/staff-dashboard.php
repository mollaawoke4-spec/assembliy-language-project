<?php
session_start();
require "../db.php";

// Check if user is logged in and is staff
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit();
}

$staff_id = $_SESSION['user_id'];
$staff_name = $_SESSION['name'] ?? 'Staff Member';

// Handle form submissions
$message = "";
$message_type = "";

// Add Inventory Item
if (isset($_POST['add_inventory'])) {
    $message = "Inventory item added successfully!";
    $message_type = "success";
}

// Update Lab Test Result
if (isset($_POST['update_lab_test'])) {
    $message = "Lab test updated successfully!";
    $message_type = "success";
}

// Update Cleaning Status
if (isset($_POST['update_cleaning'])) {
    $message = "Cleaning status updated!";
    $message_type = "success";
}

// Add New Task
if (isset($_POST['add_task'])) {
    $message = "Task added successfully!";
    $message_type = "success";
}

// Order Supplies
if (isset($_POST['order_supplies'])) {
    $item_name = $_POST['item_name'] ?? '';
    $quantity = $_POST['quantity'] ?? 0;
    $supplier = $_POST['supplier'] ?? '';
    $urgency = $_POST['urgency'] ?? 'normal';
    
    $message = "Supply order placed for $quantity units of $item_name! Order ID: ORD-" . rand(1000, 9999);
    $message_type = "success";
}

// Schedule Maintenance
if (isset($_POST['schedule_maintenance'])) {
    $equipment = $_POST['equipment'] ?? '';
    $maintenance_type = $_POST['maintenance_type'] ?? '';
    $scheduled_date = $_POST['scheduled_date'] ?? '';
    $assigned_to = $_POST['assigned_to'] ?? '';
    
    $message = "Maintenance scheduled for $equipment on $scheduled_date!";
    $message_type = "success";
}

// Get statistics (with fallback data)
$stats = [
    'low_stock' => 5,
    'pending_tests' => 3,
    'today_cleaning' => 4,
    'pending_maintenance' => 2,
    'my_tasks' => 3,
    'pending_orders' => 2
];

// Try to get real data, fallback to sample data
try {
    $result = $conn->query("SELECT COUNT(*) as count FROM inventory WHERE quantity <= min_quantity");
    if ($result) $stats['low_stock'] = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

try {
    $result = $conn->query("SELECT COUNT(*) as count FROM lab_tests WHERE status = 'pending'");
    if ($result) $stats['pending_tests'] = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

try {
    $today = date('Y-m-d');
    $result = $conn->query("SELECT COUNT(*) as count FROM cleaning_schedule WHERE schedule_date = '$today' AND status = 'pending'");
    if ($result) $stats['today_cleaning'] = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

try {
    $result = $conn->query("SELECT COUNT(*) as count FROM equipment_maintenance WHERE status = 'pending'");
    if ($result) $stats['pending_maintenance'] = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

try {
    $result = $conn->query("SELECT COUNT(*) as count FROM staff_tasks WHERE assigned_to = '$staff_name' AND status = 'pending'");
    if ($result) $stats['my_tasks'] = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

// Sample data for tables
$low_stock_items = [
    ['id' => 1, 'item_name' => 'Paracetamol 500mg', 'category' => 'Medicine', 'quantity' => 15, 'unit' => 'Tablets', 'min_quantity' => 50, 'location' => 'Pharmacy Rack A'],
    ['id' => 2, 'item_name' => 'Surgical Masks', 'category' => 'PPE', 'quantity' => 200, 'unit' => 'Pieces', 'min_quantity' => 500, 'location' => 'Store Room 1'],
    ['id' => 3, 'item_name' => 'Disinfectant Spray', 'category' => 'Cleaning', 'quantity' => 5, 'unit' => 'Bottles', 'min_quantity' => 20, 'location' => 'Cleaning Storage'],
    ['id' => 4, 'item_name' => 'Syringes 5ml', 'category' => 'Medical Supplies', 'quantity' => 100, 'unit' => 'Pieces', 'min_quantity' => 300, 'location' => 'Lab Store']
];

$pending_tests = [
    ['test_id' => 'LAB-001', 'patient_name' => 'John Doe', 'test_type' => 'Blood Test', 'doctor_name' => 'Dr. Smith', 'test_date' => date('Y-m-d')],
    ['test_id' => 'LAB-002', 'patient_name' => 'Jane Smith', 'test_type' => 'Urine Analysis', 'doctor_name' => 'Dr. Johnson', 'test_date' => date('Y-m-d')]
];

$today_cleaning = [
    ['id' => 1, 'room_number' => '101', 'room_type' => 'Consultation', 'cleaning_type' => 'Daily', 'schedule_time' => '09:00', 'assigned_to' => 'Cleaning Staff 1', 'status' => 'pending'],
    ['id' => 2, 'room_number' => '205', 'room_type' => 'Operation', 'cleaning_type' => 'Disinfection', 'schedule_time' => '11:00', 'assigned_to' => 'Cleaning Staff 2', 'status' => 'in_progress'],
    ['id' => 3, 'room_number' => 'Lab-1', 'room_type' => 'Laboratory', 'cleaning_type' => 'Deep Clean', 'schedule_time' => '14:00', 'assigned_to' => 'Cleaning Staff 3', 'status' => 'pending']
];

$my_tasks = [
    ['id' => 1, 'title' => 'Restock Pharmacy', 'description' => 'Check and restock pharmacy items', 'priority' => 'high', 'due_date' => date('Y-m-d'), 'status' => 'pending'],
    ['id' => 2, 'title' => 'Update Inventory', 'description' => 'Update inventory records for this week', 'priority' => 'medium', 'due_date' => date('Y-m-d', strtotime('+2 days')), 'status' => 'in_progress'],
    ['id' => 3, 'title' => 'Equipment Check', 'description' => 'Monthly equipment maintenance check', 'priority' => 'low', 'due_date' => date('Y-m-d', strtotime('+1 week')), 'status' => 'pending']
];

$pending_orders = [
    ['order_id' => 'ORD-2023-001', 'item_name' => 'Gloves (Large)', 'quantity' => 1000, 'supplier' => 'MediSupply Co.', 'order_date' => date('Y-m-d', strtotime('-2 days')), 'status' => 'pending'],
    ['order_id' => 'ORD-2023-002', 'item_name' => 'Bandages', 'quantity' => 500, 'supplier' => 'HealthCare Supplies', 'order_date' => date('Y-m-d', strtotime('-1 day')), 'status' => 'processing']
];

$maintenance_schedule = [
    ['id' => 1, 'equipment' => 'X-Ray Machine', 'maintenance_type' => 'Preventive', 'scheduled_date' => date('Y-m-d', strtotime('+3 days')), 'assigned_to' => 'Tech Team A', 'status' => 'scheduled'],
    ['id' => 2, 'equipment' => 'Ultrasound Scanner', 'maintenance_type' => 'Routine Check', 'scheduled_date' => date('Y-m-d', strtotime('+1 week')), 'assigned_to' => 'Tech Team B', 'status' => 'pending']
];

// Get all staff for task assignment
$all_staff = ['John Smith', 'Sarah Johnson', 'Mike Wilson', 'Emma Davis', 'Robert Brown'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Staff Dashboard - Clinic Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<style>
/* Complete CSS for Responsive Dashboard */
:root {
    --primary: #2c3e50;
    --secondary: #3498db;
    --success: #27ae60;
    --warning: #f39c12;
    --danger: #e74c3c;
    --light: #ecf0f1;
    --dark: #2c3e50;
    --purple: #9b59b6;
    --teal: #1abc9c;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    background: #f5f7fa;
    color: #333;
    min-height: 100vh;
}

/* Header */
.header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--dark) 100%);
    color: white;
    padding: 25px;
    border-radius: 15px;
    margin-bottom: 30px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    text-align: center;
}

.header h1 {
    font-size: 28px;
    margin-bottom: 10px;
}

.header p {
    opacity: 0.9;
    font-size: 16px;
}

/* Message */
.message {
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 8px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    animation: fadeIn 0.5s;
}

.message.success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.message.error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    text-align: center;
    transition: all 0.3s;
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 5px;
    height: 100%;
}

.stat-card:nth-child(1)::before { background: var(--warning); }
.stat-card:nth-child(2)::before { background: var(--secondary); }
.stat-card:nth-child(3)::before { background: var(--teal); }
.stat-card:nth-child(4)::before { background: var(--danger); }
.stat-card:nth-child(5)::before { background: var(--purple); }
.stat-card:nth-child(6)::before { background: #3498db; }

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: white;
    margin: 0 auto 15px;
}

.stat-card:nth-child(1) .stat-icon { background: var(--warning); }
.stat-card:nth-child(2) .stat-icon { background: var(--secondary); }
.stat-card:nth-child(3) .stat-icon { background: var(--teal); }
.stat-card:nth-child(4) .stat-icon { background: var(--danger); }
.stat-card:nth-child(5) .stat-icon { background: var(--purple); }
.stat-card:nth-child(6) .stat-icon { background: #3498db; }

.stat-value {
    font-size: 36px;
    font-weight: 700;
    color: var(--dark);
    margin-bottom: 5px;
}

.stat-label {
    color: #7f8c8d;
    font-size: 14px;
    margin-bottom: 10px;
}

/* Quick Actions */
.quick-actions {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.section-title {
    color: var(--primary);
    font-size: 20px;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid var(--light);
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-title i {
    color: var(--secondary);
}

.actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 15px;
}

.action-btn {
    background: white;
    border: 2px solid var(--light);
    border-radius: 10px;
    padding: 20px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    text-decoration: none;
    color: inherit;
}

.action-btn:hover {
    border-color: var(--secondary);
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(52, 152, 219, 0.2);
}

.action-btn i {
    font-size: 24px;
    color: var(--secondary);
}

.action-btn span {
    color: var(--dark);
    font-weight: 500;
    font-size: 14px;
}

/* Data Sections */
.data-section {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.table-responsive {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

th {
    background: var(--light);
    padding: 15px;
    text-align: left;
    color: var(--dark);
    font-weight: 600;
    border-bottom: 2px solid #ddd;
}

td {
    padding: 15px;
    border-bottom: 1px solid #eee;
    vertical-align: middle;
}

tr:hover {
    background: #f8f9fa;
}

/* Badges */
.badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    display: inline-block;
}

.badge-pending { background: #fff3cd; color: #856404; }
.badge-in_progress { background: #cce5ff; color: #004085; }
.badge-completed { background: #d4edda; color: #155724; }
.badge-verified { background: #d1ecf1; color: #0c5460; }
.badge-scheduled { background: #d1ecf1; color: #0c5460; }
.badge-processing { background: #fff3cd; color: #856404; }
.badge-delivered { background: #d4edda; color: #155724; }
.badge-high { background: #f8d7da; color: #721c24; }
.badge-medium { background: #fff3cd; color: #856404; }
.badge-low { background: #d1ecf1; color: #0c5460; }

/* Buttons */
.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-sm { padding: 6px 12px; font-size: 12px; }

.btn-primary { background: var(--primary); color: white; }
.btn-primary:hover { background: #1a252f; }

.btn-success { background: var(--success); color: white; }
.btn-success:hover { background: #219653; }

.btn-danger { background: var(--danger); color: white; }
.btn-danger:hover { background: #c0392b; }

.btn-warning { background: var(--warning); color: white; }
.btn-warning:hover { background: #e67e22; }

.btn-purple { background: var(--purple); color: white; }
.btn-purple:hover { background: #8e44ad; }

/* Forms */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: var(--dark);
    font-weight: 500;
    font-size: 14px;
}

.form-control {
    width: 100%;
    padding: 12px 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s;
}

.form-control:focus {
    outline: none;
    border-color: var(--secondary);
    box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
}

textarea.form-control {
    min-height: 100px;
    resize: vertical;
}

/* Modal */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-content {
    background: white;
    border-radius: 15px;
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}

.modal-header {
    padding: 20px;
    background: var(--primary);
    color: white;
    border-radius: 15px 15px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-body {
    padding: 20px;
}

.close-modal {
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    cursor: pointer;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.3s;
}

.close-modal:hover {
    background: rgba(255,255,255,0.2);
}

/* Logout Button */
.logout-btn {
    display: block;
    width: 200px;
    margin: 30px auto 0;
    background: var(--danger);
    color: white;
    padding: 12px;
    border-radius: 8px;
    text-decoration: none;
    text-align: center;
    font-weight: 500;
    transition: all 0.3s;
}

.logout-btn:hover {
    background: #c0392b;
    transform: translateY(-2px);
}

/* Container */
.container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 20px;
}

/* Form Row */
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

@media (max-width: 768px) {
    .form-row {
        grid-template-columns: 1fr;
    }
    
    .header {
        padding: 20px;
    }
    
    .header h1 {
        font-size: 24px;
    }
    
    .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    }
    
    .actions-grid {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    }
    
    table {
        font-size: 14px;
    }
    
    th, td {
        padding: 10px;
    }
}

@media (max-width: 480px) {
    .header {
        padding: 15px;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .actions-grid {
        grid-template-columns: 1fr;
    }
    
    .stat-value {
        font-size: 28px;
    }
    
    .data-section {
        padding: 15px;
    }
}

/* Status Indicators */
.status-indicator {
    display: inline-block;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    margin-right: 8px;
}

.status-pending { background: #f39c12; }
.status-in_progress { background: #3498db; }
.status-completed { background: #27ae60; }
.status-scheduled { background: #9b59b6; }

/* Text Utilities */
.text-center { text-align: center; }
.text-right { text-align: right; }
.text-danger { color: var(--danger); }
.text-warning { color: var(--warning); }
.text-success { color: var(--success); }

.mb-20 { margin-bottom: 20px; }
.mt-20 { margin-top: 20px; }

/* Tooltip */
.tooltip {
    position: relative;
    display: inline-block;
    cursor: help;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 200px;
    background-color: var(--dark);
    color: white;
    text-align: center;
    border-radius: 6px;
    padding: 5px;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left: 50%;
    margin-left: -100px;
    opacity: 0;
    transition: opacity 0.3s;
    font-size: 12px;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
    opacity: 1;
}

/* Notification */
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    border-radius: 8px;
    background: white;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    display: none;
    z-index: 1001;
}

.notification.success {
    border-left: 4px solid var(--success);
}

.notification.error {
    border-left: 4px solid var(--danger);
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="container">
    <!-- Header -->
    <div class="header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px 30px; border-radius: 12px; margin-bottom: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); position: relative;">
        
        <!-- Profile Section with Actions -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 20px;">
            
            <!-- Left Side: Profile Info with Complete Management -->
            <div style="flex: 1; min-width: 300px;">
                <!-- Profile Picture with Complete Upload Management -->
                <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 15px;">
                    <div style="position: relative;">
                        <div id="staffProfileAvatar" 
                             style="width: 80px; height: 80px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: bold; color: white; box-shadow: 0 3px 10px rgba(0,0,0,0.2); cursor: pointer; overflow: hidden; position: relative;"
                             onmouseover="showAvatarOverlay()"
                             onmouseout="hideAvatarOverlay()"
                             onclick="openStaffEditProfile()">
                            <!-- Profile Image or Initial -->
                            <span id="staffAvatarInitial"><?php echo strtoupper(substr(htmlspecialchars($staff_name), 0, 1)); ?></span>
                            <img id="staffProfileImage" style="width: 100%; height: 100%; object-fit: cover; display: none;">
                            
                            <!-- Upload Overlay -->
                            <div id="avatarOverlay" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: none; align-items: center; justify-content: center; color: white; font-size: 14px; border-radius: 50%;">
                                <i class="fas fa-camera"></i> Change
                            </div>
                        </div>
                        
                        <!-- Upload Camera Icon with Quick Actions -->
                        <div style="position: absolute; bottom: -5px; right: -5px; background: white; color: #2196F3; border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); z-index: 10;"
                             onclick="showQuickImageActions()">
                            <i class="fas fa-ellipsis-v"></i>
                        </div>
                        
                        <!-- Quick Image Actions Dropdown -->
                        <div id="quickImageActions" style="display: none; position: absolute; bottom: 30px; right: -10px; background: white; border-radius: 8px; padding: 8px 0; box-shadow: 0 4px 15px rgba(0,0,0,0.15); min-width: 150px; z-index: 1000; border: 1px solid #e0e0e0;">
                            <div onclick="document.getElementById('staffImageUpload').click(); closeQuickActions()" 
                                 style="padding: 8px 15px; cursor: pointer; color: #333; display: flex; align-items: center; gap: 10px; font-size: 14px;">
                                <i class="fas fa-upload" style="color: #2196F3;"></i> Upload
                            </div>
                            <div onclick="removeProfileImage(); closeQuickActions()" 
                                 style="padding: 8px 15px; cursor: pointer; color: #333; display: flex; align-items: center; gap: 10px; font-size: 14px;">
                                <i class="fas fa-trash" style="color: #e74c3c;"></i> Remove
                            </div>
                            <div onclick="viewProfileImage(); closeQuickActions()" 
                                 style="padding: 8px 15px; cursor: pointer; color: #333; display: flex; align-items: center; gap: 10px; font-size: 14px;">
                                <i class="fas fa-eye" style="color: #4CAF50;"></i> View
                            </div>
                        </div>
                        
                        <!-- Hidden File Input -->
                        <input type="file" id="staffImageUpload" accept="image/*" style="display: none;" onchange="uploadStaffProfileImage(this)">
                        <input type="file" id="cameraCapture" accept="image/*" capture="environment" style="display: none;">
                    </div>
                    
                    <!-- Welcome Message with Complete Profile Controls -->
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 5px;">
                            <h1 style="margin: 0; font-size: 28px; display: flex; align-items: center; gap: 10px;">
                                Welcome <?php echo htmlspecialchars($staff_name); ?> 👨‍💼
                            </h1>
                            
                            <!-- Status Badge -->
                            <span id="profileStatus" style="background: rgba(255,255,255,0.15); color: white; padding: 4px 10px; border-radius: 20px; font-size: 12px; display: flex; align-items: center; gap: 5px;">
                                <i class="fas fa-circle" style="font-size: 8px; color: #4CAF50;"></i> Active
                            </span>
                        </div>
                        
                        <p style="margin: 8px 0 5px 0; color: rgba(255,255,255,0.9); font-size: 16px;">Staff Dashboard - Clinic Management System</p>
                        
                        <!-- Profile Quick Actions -->
                        <div style="display: flex; gap: 10px; margin-top: 10px; flex-wrap: wrap;">
                            <button onclick="openStaffEditProfile()" 
                                    style="background: rgba(255,255,255,0.15); color: white; border: 1px solid rgba(255,255,255,0.3); padding: 6px 15px; border-radius: 20px; cursor: pointer; font-size: 12px; display: flex; align-items: center; gap: 6px; transition: all 0.2s;">
                                <i class="fas fa-edit"></i> Edit Profile
                            </button>
                            <button onclick="quickUpdateProfile()" 
                                    style="background: rgba(255,255,255,0.15); color: white; border: 1px solid rgba(255,255,255,0.3); padding: 6px 15px; border-radius: 20px; cursor: pointer; font-size: 12px; display: flex; align-items: center; gap: 6px; transition: all 0.2s;">
                                <i class="fas fa-sync-alt"></i> Update
                            </button>
                            <button onclick="showChangePasswordModal()" 
                                    style="background: rgba(255,255,255,0.15); color: white; border: 1px solid rgba(255,255,255,0.3); padding: 6px 15px; border-radius: 20px; cursor: pointer; font-size: 12px; display: flex; align-items: center; gap: 6px; transition: all 0.2s;">
                                <i class="fas fa-key"></i> Password
                            </button>
                        </div>
                        
                        <!-- Last Update & Statistics -->
                        <div style="display: flex; align-items: center; gap: 15px; margin-top: 12px; font-size: 12px; color: rgba(255,255,255,0.7); flex-wrap: wrap;">
                            <span><i class="far fa-calendar-alt"></i> <?php echo date('F j, Y'); ?></span>
                            <span><i class="far fa-clock"></i> <?php echo date('H:i'); ?></span>
                            <span id="lastUpdateInfo" style="display: none;">
                                <i class="fas fa-history"></i> Updated: <span id="updateTime">Just now</span>
                            </span>
                            
                            <?php if ($stats['low_stock'] == 5 || $stats['pending_tests'] == 3): ?>
                            <span style="color: #ffdd57; background: rgba(255, 221, 87, 0.1); padding: 4px 10px; border-radius: 20px;">
                                <i class="fas fa-exclamation-triangle"></i> Using sample data
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Side: Action Buttons -->
            <div style="display: flex; flex-direction: column; gap: 12px; min-width: 200px;">
                <!-- Quick Actions -->
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <!-- Notification -->
                    <div style="position: relative; cursor: pointer; background: rgba(255,255,255,0.1); padding: 8px; border-radius: 8px; display: flex; align-items: center; gap: 8px;" 
                         onclick="showStaffNotifications()">
                        <i class="fas fa-bell" style="font-size: 18px;"></i>
                        <span id="staffNotificationCount" style="background: #e74c3c; color: white; font-size: 11px; padding: 2px 6px; border-radius: 50%; min-width: 18px; text-align: center; display: none;">0</span>
                    </div>
                    
                    <!-- Settings -->
                    <div style="cursor: pointer; background: rgba(255,255,255,0.1); padding: 8px; border-radius: 8px; display: flex; align-items: center; gap: 8px;" 
                         onclick="showSettingsMenu()">
                        <i class="fas fa-cog" style="font-size: 18px;"></i>
                    </div>
                    
                    <!-- Print -->
                    <button onclick="window.print()" style="background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 8px 15px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 14px;">
                        <i class="fas fa-print"></i> Print
                    </button>
                    
                    <!-- Back -->
                    <a href="staff-dashboard.php" style="background: rgba(255,255,255,0.1); color: white; padding: 8px 15px; border-radius: 8px; text-decoration: none; display: flex; align-items: center; gap: 8px; font-size: 14px; border: 1px solid rgba(255,255,255,0.3);">
                        <i class="fas fa-arrow-left"></i> Back
                    </a>
                    
                    <!-- Logout -->
                    <a href="../logout.php" style="background: rgba(231, 76, 60, 0.9); color: white; padding: 8px 20px; border-radius: 8px; text-decoration: none; display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 500;">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
                
                <!-- Quick Stats -->
                <div style="display: flex; gap: 15px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 8px; font-size: 12px;">
                    <div style="text-align: center; flex: 1;">
                        <div style="font-weight: bold; color: #ffdd57; font-size: 18px;"><?php echo $stats['low_stock'] ?? 0; ?></div>
                        <div style="color: rgba(255,255,255,0.7);">Low Stock</div>
                    </div>
                    <div style="text-align: center; flex: 1;">
                        <div style="font-weight: bold; color: #ffdd57; font-size: 18px;"><?php echo $stats['pending_tests'] ?? 0; ?></div>
                        <div style="color: rgba(255,255,255,0.7);">Pending Tests</div>
                    </div>
                    <div style="text-align: center; flex: 1;">
                        <div style="font-weight: bold; color: #ffdd57; font-size: 18px;" id="profileScore">85%</div>
                        <div style="color: rgba(255,255,255,0.7);">Profile Score</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ==================== PROFILE MANAGEMENT MODALS ==================== -->

<!-- Edit Profile Modal (Complete Edit) -->
<div id="editProfileModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 600px; width: 90%; max-height: 90vh; overflow-y: auto; box-shadow: 0 15px 50px rgba(0,0,0,0.2);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
            <h2 style="margin: 0; color: #333; font-size: 24px;">
                <i class="fas fa-user-edit" style="color: #2196F3; margin-right: 10px;"></i>
                Edit Profile Information
            </h2>
            <button onclick="closeEditProfileModal()" 
                    style="background: none; border: none; font-size: 28px; cursor: pointer; color: #999; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 50%; transition: background 0.2s;">&times;</button>
        </div>
        
        <!-- Profile Picture Section with Advanced Options -->
        <div style="text-align: center; margin-bottom: 25px; padding: 20px; background: #f8f9fa; border-radius: 10px;">
            <div id="modalProfileAvatar" 
                 style="width: 120px; height: 120px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 48px; font-weight: bold; color: white; overflow: hidden; position: relative; cursor: pointer;"
                 onclick="showImageUploadOptions()">
                <span id="modalAvatarInitial"><?php echo strtoupper(substr(htmlspecialchars($staff_name), 0, 1)); ?></span>
                <img id="modalProfileImage" style="width: 100%; height: 100%; object-fit: cover; display: none;">
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px;">
                <button onclick="document.getElementById('imageUpload').click()" 
                        style="background: #2196F3; color: white; border: none; padding: 10px 20px; border-radius: 25px; cursor: pointer; font-size: 14px; display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-upload"></i> Upload
                </button>
                <button onclick="document.getElementById('cameraInput').click()" 
                        style="background: #4CAF50; color: white; border: none; padding: 10px 20px; border-radius: 25px; cursor: pointer; font-size: 14px; display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-camera"></i> Camera
                </button>
                <button onclick="removeProfileImage()" 
                        style="background: #f8f9fa; color: #666; border: 1px solid #ddd; padding: 10px 20px; border-radius: 25px; cursor: pointer; font-size: 14px; display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
            
            <!-- Hidden Inputs -->
            <input type="file" id="imageUpload" accept="image/*" style="display: none;" onchange="handleImageUpload(this)">
            <input type="file" id="cameraInput" accept="image/*" capture="environment" style="display: none;" onchange="handleImageUpload(this)">
        </div>
        
        <!-- Edit Form -->
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <!-- Personal Information -->
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px;">
                <h3 style="margin: 0 0 15px 0; color: #333; font-size: 18px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-user" style="color: #2196F3;"></i> Personal Information
                </h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Full Name *</label>
                        <input type="text" id="editFullName" value="<?php echo htmlspecialchars($staff_name); ?>" 
                               style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Email *</label>
                        <input type="email" id="editEmail" placeholder="staff@clinic.com" 
                               style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Phone</label>
                        <input type="tel" id="editPhone" placeholder="+251 900 000 000" 
                               style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Date of Birth</label>
                        <input type="date" id="editDOB" 
                               style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                    </div>
                </div>
            </div>
            
            <!-- Professional Information -->
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px;">
                <h3 style="margin: 0 0 15px 0; color: #333; font-size: 18px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-briefcase" style="color: #4CAF50;"></i> Professional Information
                </h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Department *</label>
                        <select id="editDepartment" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                            <option value="">Select Department</option>
                            <option value="reception">Reception</option>
                            <option value="lab">Laboratory</option>
                            <option value="pharmacy">Pharmacy</option>
                            <option value="admin">Administration</option>
                            <option value="support">Support</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Position</label>
                        <input type="text" id="editPosition" placeholder="Staff Position" 
                               style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Employee ID</label>
                        <input type="text" id="editEmployeeID" placeholder="EMP-001" 
                               style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Join Date</label>
                        <input type="date" id="editJoinDate" 
                               style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                    </div>
                </div>
            </div>
            
            <!-- Bio & Address -->
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px;">
                <h3 style="margin: 0 0 15px 0; color: #333; font-size: 18px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-info-circle" style="color: #9C27B0;"></i> Additional Information
                </h3>
                <div style="display: flex; flex-direction: column; gap: 15px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Bio / Description</label>
                        <textarea id="editBio" placeholder="Describe your role and responsibilities..." rows="3" 
                                  style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; resize: vertical;"></textarea>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Address</label>
                        <textarea id="editAddress" placeholder="Your complete address..." rows="2" 
                                  style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; resize: vertical;"></textarea>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Action Buttons -->
        <div style="display: flex; gap: 15px; margin-top: 30px;">
            <button onclick="saveProfileChanges()" 
                    style="flex: 1; background: linear-gradient(135deg, #4CAF50, #45a049); color: white; border: none; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 10px;">
                <i class="fas fa-save"></i> Save Changes
            </button>
            <button onclick="updateProfileFromServer()" 
                    style="flex: 1; background: #2196F3; color: white; border: none; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 10px;">
                <i class="fas fa-sync-alt"></i> Update
            </button>
            <button onclick="closeEditProfileModal()" 
                    style="flex: 1; background: #f8f9fa; color: #666; border: 2px solid #e0e0e0; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: 600;">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div id="changePasswordModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 500px; width: 90%; box-shadow: 0 15px 50px rgba(0,0,0,0.2);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
            <h2 style="margin: 0; color: #333; font-size: 24px;">
                <i class="fas fa-key" style="color: #9C27B0; margin-right: 10px;"></i>
                Change Password
            </h2>
            <button onclick="closeChangePasswordModal()" 
                    style="background: none; border: none; font-size: 28px; cursor: pointer; color: #999;">&times;</button>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Current Password *</label>
                <input type="password" id="currentPassword" 
                       style="width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">New Password *</label>
                <input type="password" id="newPassword" 
                       style="width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
                <div style="font-size: 12px; color: #666; margin-top: 5px;">
                    <i class="fas fa-info-circle"></i> Minimum 8 characters with letters and numbers
                </div>
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Confirm New Password *</label>
                <input type="password" id="confirmPassword" 
                       style="width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px;">
            </div>
        </div>
        
        <div style="display: flex; gap: 15px; margin-top: 30px;">
            <button onclick="updatePassword()" 
                    style="flex: 1; background: #9C27B0; color: white; border: none; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: 600;">
                Update Password
            </button>
            <button onclick="closeChangePasswordModal()" 
                    style="flex: 1; background: #f8f9fa; color: #666; border: 2px solid #e0e0e0; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px;">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- Delete Account Modal -->
<div id="deleteAccountModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 500px; width: 90%; box-shadow: 0 15px 50px rgba(0,0,0,0.2);">
        <div style="text-align: center; margin-bottom: 25px;">
            <div style="width: 80px; height: 80px; background: #e74c3c; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 36px; margin: 0 auto 20px;">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h2 style="margin: 0; color: #e74c3c; font-size: 24px;">Delete Account</h2>
            <p style="color: #666; margin-top: 10px;">This action cannot be undone!</p>
        </div>
        
        <div style="background: #ffebee; padding: 20px; border-radius: 10px; margin-bottom: 25px;">
            <p style="color: #c62828; margin-bottom: 15px; font-weight: 600;">
                <i class="fas fa-exclamation-circle"></i> Warning: Deleting your account will:
            </p>
            <ul style="color: #666; padding-left: 20px; margin: 0;">
                <li>Permanently remove your profile and all data</li>
                <li>Delete your activity history and records</li>
                <li>Remove your access to the system immediately</li>
                <li>Require admin approval to restore (if possible)</li>
                <li>Cancel all your pending tasks and appointments</li>
            </ul>
        </div>
        
        <div>
            <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">Type "DELETE" to confirm</label>
            <input type="text" id="deleteConfirmation" placeholder="Type DELETE here" 
                   style="width: 100%; padding: 14px; border: 2px solid #e74c3c; border-radius: 8px; font-size: 16px;">
        </div>
        
        <div style="display: flex; gap: 15px; margin-top: 30px;">
            <button onclick="deleteAccount()" 
                    style="flex: 1; background: #e74c3c; color: white; border: none; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: 600;">
                Delete Account
            </button>
            <button onclick="closeDeleteAccountModal()" 
                    style="flex: 1; background: #f8f9fa; color: #666; border: 2px solid #e0e0e0; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px;">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- Settings Menu -->
<div id="settingsMenu" style="display: none; position: absolute; top: 100px; right: 30px; background: white; border-radius: 12px; padding: 15px 0; box-shadow: 0 10px 30px rgba(0,0,0,0.2); min-width: 250px; z-index: 1000; border: 1px solid #e0e0e0;">
    <div style="padding: 15px; border-bottom: 1px solid #eee;">
        <strong style="color: #333;">Account Settings</strong>
    </div>
    
    <div onclick="openStaffEditProfile(); closeSettingsMenu()" 
         style="padding: 12px 15px; cursor: pointer; color: #555; display: flex; align-items: center; gap: 12px;">
        <i class="fas fa-user-edit" style="color: #2196F3; width: 20px;"></i>
        <span>Edit Profile</span>
    </div>
    
    <div onclick="showChangePasswordModal(); closeSettingsMenu()" 
         style="padding: 12px 15px; cursor: pointer; color: #555; display: flex; align-items: center; gap: 12px;">
        <i class="fas fa-key" style="color: #9C27B0; width: 20px;"></i>
        <span>Change Password</span>
    </div>
    
    <div onclick="showPrivacySettings(); closeSettingsMenu()" 
         style="padding: 12px 15px; cursor: pointer; color: #555; display: flex; align-items: center; gap: 12px;">
        <i class="fas fa-shield-alt" style="color: #4CAF50; width: 20px;"></i>
        <span>Privacy Settings</span>
    </div>
    
    <div style="padding: 12px 15px; border-top: 1px solid #eee;">
        <strong style="color: #333;">System</strong>
    </div>
    
    <div onclick="exportProfileData(); closeSettingsMenu()" 
         style="padding: 12px 15px; cursor: pointer; color: #555; display: flex; align-items: center; gap: 12px;">
        <i class="fas fa-download" style="color: #FF9800; width: 20px;"></i>
        <span>Export Data</span>
    </div>
    
    <div onclick="showDeleteAccountModal(); closeSettingsMenu()" 
         style="padding: 12px 15px; cursor: pointer; color: #e74c3c; display: flex; align-items: center; gap: 12px;">
        <i class="fas fa-trash-alt" style="width: 20px;"></i>
        <span>Delete Account</span>
    </div>
</div>

<!-- ==================== JAVASCRIPT FOR COMPLETE PROFILE MANAGEMENT ==================== -->

<script>
// Initialize on page load
window.addEventListener('load', function() {
    initializeProfileManagement();
});

function initializeProfileManagement() {
    // Load saved data
    loadProfileData();
    loadProfileImage();
    updateProfileScore();
    
    // Initialize notification count
    checkNotifications();
    
    console.log('Profile Management System Initialized');
}

// ========== PROFILE DATA MANAGEMENT ==========

// Load profile data from localStorage
function loadProfileData() {
    const savedData = localStorage.getItem('staffProfileData');
    if (savedData) {
        try {
            const data = JSON.parse(savedData);
            
            // Set form values
            if (data.name) {
                document.getElementById('editFullName').value = data.name;
                updateWelcomeMessage(data.name);
            }
            if (data.email) document.getElementById('editEmail').value = data.email;
            if (data.phone) document.getElementById('editPhone').value = data.phone;
            if (data.department) document.getElementById('editDepartment').value = data.department;
            if (data.position) document.getElementById('editPosition').value = data.position;
            if (data.employeeID) document.getElementById('editEmployeeID').value = data.employeeID;
            if (data.dob) document.getElementById('editDOB').value = data.dob;
            if (data.joinDate) document.getElementById('editJoinDate').value = data.joinDate;
            if (data.bio) document.getElementById('editBio').value = data.bio;
            if (data.address) document.getElementById('editAddress').value = data.address;
            
            // Update last update info
            if (data.updatedAt) {
                const updateTime = new Date(data.updatedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                document.getElementById('updateTime').textContent = updateTime;
                document.getElementById('lastUpdateInfo').style.display = 'inline';
            }
            
        } catch (e) {
            console.error('Error loading profile data:', e);
        }
    }
}

// Save profile data
function saveProfileChanges() {
    // Collect form data
    const profileData = {
        name: document.getElementById('editFullName').value.trim(),
        email: document.getElementById('editEmail').value.trim(),
        phone: document.getElementById('editPhone').value.trim(),
        department: document.getElementById('editDepartment').value,
        position: document.getElementById('editPosition').value.trim(),
        employeeID: document.getElementById('editEmployeeID').value.trim(),
        dob: document.getElementById('editDOB').value,
        joinDate: document.getElementById('editJoinDate').value,
        bio: document.getElementById('editBio').value.trim(),
        address: document.getElementById('editAddress').value.trim(),
        updatedAt: new Date().toISOString()
    };
    
    // Validation
    if (!profileData.name || !profileData.email) {
        showMessage('Name and email are required', 'error');
        return;
    }
    
    if (!isValidEmail(profileData.email)) {
        showMessage('Please enter a valid email address', 'error');
        return;
    }
    
    // Update UI
    updateWelcomeMessage(profileData.name);
    updateProfileScore();
    
    // Save to localStorage
    localStorage.setItem('staffProfileData', JSON.stringify(profileData));
    
    // Show success message
    showMessage('Profile updated successfully!', 'success');
    
    // Update last update info
    const updateTime = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    document.getElementById('updateTime').textContent = updateTime;
    document.getElementById('lastUpdateInfo').style.display = 'inline';
    
    // Close modal
    closeEditProfileModal();
}

// Quick update function
function quickUpdateProfile() {
    // Simulate updating from server
    showMessage('Fetching latest profile data...', 'info');
    
    setTimeout(() => {
        // In real app, this would fetch from server
        const fakeUpdate = {
            name: document.getElementById('editFullName').value,
            lastLogin: new Date().toLocaleString()
        };
        
        localStorage.setItem('lastProfileUpdate', JSON.stringify(fakeUpdate));
        showMessage('Profile synced with server', 'success');
    }, 1000);
}

// Update from server (simulated)
function updateProfileFromServer() {
    showMessage('Connecting to server...', 'info');
    
    setTimeout(() => {
        // Simulate server response
        const serverData = {
            name: "Updated Name from Server",
            email: "updated@clinic.com",
            phone: "+251 911 222 333",
            department: "Administration",
            updatedAt: new Date().toISOString()
        };
        
        // Update form fields
        Object.keys(serverData).forEach(key => {
            const element = document.getElementById('edit' + key.charAt(0).toUpperCase() + key.slice(1));
            if (element) element.value = serverData[key];
        });
        
        showMessage('Profile data updated from server', 'success');
    }, 1500);
}

// ========== PROFILE IMAGE MANAGEMENT ==========

// Load saved profile image
function loadProfileImage() {
    const savedImage = localStorage.getItem('staffProfileImage');
    if (savedImage) {
        setProfileImage(savedImage);
    }
}

// Handle image upload
function handleImageUpload(input) {
    if (!input.files || !input.files[0]) return;
    
    const file = input.files[0];
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    
    // Validation
    if (!allowedTypes.includes(file.type)) {
        showMessage('Please upload JPG, PNG, GIF or WebP images only', 'error');
        return;
    }
    
    if (file.size > maxSize) {
        showMessage('Image size should be less than 5MB', 'error');
        return;
    }
    
    // Show loading
    showMessage('Uploading image...', 'info');
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        // Save image
        setProfileImage(e.target.result);
        localStorage.setItem('staffProfileImage', e.target.result);
        
        showMessage('Profile image uploaded successfully!', 'success');
        updateProfileScore();
    };
    
    reader.onerror = function() {
        showMessage('Failed to upload image. Please try again.', 'error');
    };
    
    reader.readAsDataURL(file);
}

// Set profile image to all avatars
function setProfileImage(imageSrc) {
    // Main header avatar
    const mainAvatar = document.getElementById('staffProfileAvatar');
    const mainInitial = document.getElementById('staffAvatarInitial');
    const mainImg = document.getElementById('staffProfileImage');
    
    if (mainAvatar) {
        if (mainInitial) mainInitial.style.display = 'none';
        if (mainImg) {
            mainImg.src = imageSrc;
            mainImg.style.display = 'block';
        }
    }
    
    // Modal avatar
    const modalAvatar = document.getElementById('modalProfileAvatar');
    const modalInitial = document.getElementById('modalAvatarInitial');
    const modalImg = document.getElementById('modalProfileImage');
    
    if (modalAvatar) {
        if (modalInitial) modalInitial.style.display = 'none';
        if (modalImg) {
            modalImg.src = imageSrc;
            modalImg.style.display = 'block';
        }
    }
}

// Remove profile image
function removeProfileImage() {
    if (!confirm('Remove profile image?')) return;
    
    // Remove from localStorage
    localStorage.removeItem('staffProfileImage');
    
    // Reset to initial
    const mainInitial = document.getElementById('staffAvatarInitial');
    const mainImg = document.getElementById('staffProfileImage');
    const modalInitial = document.getElementById('modalAvatarInitial');
    const modalImg = document.getElementById('modalProfileImage');
    
    if (mainInitial) {
        mainInitial.style.display = 'flex';
        if (mainImg) mainImg.style.display = 'none';
    }
    
    if (modalInitial) {
        modalInitial.style.display = 'flex';
        if (modalImg) modalImg.style.display = 'none';
    }
    
    showMessage('Profile image removed', 'info');
    updateProfileScore();
}

// View profile image in full screen
function viewProfileImage() {
    const imgSrc = localStorage.getItem('staffProfileImage');
    if (!imgSrc) {
        showMessage('No profile image to view', 'info');
        return;
    }
    
    // Create image viewer modal
    const viewer = document.createElement('div');
    viewer.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.9);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    `;
    
    viewer.innerHTML = `
        <div style="position: relative; max-width: 90%; max-height: 90%;">
            <img src="${imgSrc}" style="max-width: 100%; max-height: 100%; border-radius: 10px;">
            <button onclick="this.parentElement.parentElement.remove()" 
                    style="position: absolute; top: -15px; right: -15px; background: #e74c3c; color: white; border: none; border-radius: 50%; width: 30px; height: 30px; font-size: 20px; cursor: pointer;">
                ×
            </button>
        </div>
    `;
    
    viewer.onclick = function(e) {
        if (e.target === viewer) viewer.remove();
    };
    
    document.body.appendChild(viewer);
}

// ========== PASSWORD MANAGEMENT ==========

function updatePassword() {
    const current = document.getElementById('currentPassword').value;
    const newPass = document.getElementById('newPassword').value;
    const confirmPass = document.getElementById('confirmPassword').value;
    
    // Validation
    if (!current || !newPass || !confirmPass) {
        showMessage('Please fill all password fields', 'error');
        return;
    }
    
    if (newPass !== confirmPass) {
        showMessage('New passwords do not match', 'error');
        return;
    }
    
    if (newPass.length < 8) {
        showMessage('Password must be at least 8 characters', 'error');
        return;
    }
    
    if (!/(?=.*[a-zA-Z])(?=.*\d)/.test(newPass)) {
        showMessage('Password must contain letters and numbers', 'error');
        return;
    }
    
    // In real app, verify current password with server
    showMessage('Verifying current password...', 'info');
    
    setTimeout(() => {
        // Simulate server verification
        showMessage('Password updated successfully!', 'success');
        closeChangePasswordModal();
        
        // Clear fields
        document.getElementById('currentPassword').value = '';
        document.getElementById('newPassword').value = '';
        document.getElementById('confirmPassword').value = '';
        
        // Update profile score
        updateProfileScore();
    }, 1500);
}

// ========== ACCOUNT DELETION ==========

function deleteAccount() {
    const confirmation = document.getElementById('deleteConfirmation').value;
    
    if (confirmation !== 'DELETE') {
        showMessage('Please type "DELETE" to confirm', 'error');
        return;
    }
    
    if (!confirm('⚠️ FINAL WARNING: This will permanently delete your account. Continue?')) {
        return;
    }
    
    showMessage('Deleting account...', 'warning');
    
    // Simulate server deletion
    setTimeout(() => {
        // Clear all local data
        localStorage.clear();
        
        showMessage('Account deleted successfully. Redirecting...', 'success');
        
        // Redirect to logout
        setTimeout(() => {
            window.location.href = '../logout.php';
        }, 2000);
    }, 2000);
}

// ========== UTILITY FUNCTIONS ==========

// Update welcome message
function updateWelcomeMessage(name) {
    const welcomeElement = document.querySelector('h1');
    if (welcomeElement) {
        welcomeElement.innerHTML = `Welcome ${name} 👨‍💼`;
    }
}

// Update profile completion score
function updateProfileScore() {
    let score = 50; // Base score
    
    // Check profile completion
    const profileData = JSON.parse(localStorage.getItem('staffProfileData') || '{}');
    const hasImage = localStorage.getItem('staffProfileImage');
    
    if (profileData.name) score += 10;
    if (profileData.email) score += 10;
    if (profileData.phone) score += 5;
    if (profileData.department) score += 10;
    if (profileData.position) score += 5;
    if (hasImage) score += 10;
    
    // Update score display
    const scoreElement = document.getElementById('profileScore');
    if (scoreElement) {
        scoreElement.textContent = `${Math.min(score, 100)}%`;
        
        // Color based on score
        if (score >= 80) {
            scoreElement.style.color = '#4CAF50';
        } else if (score >= 60) {
            scoreElement.style.color = '#FF9800';
        } else {
            scoreElement.style.color = '#e74c3c';
        }
    }
}

// Check notifications
function checkNotifications() {
    // Simulate notifications
    const notifications = Math.floor(Math.random() * 5);
    const countElement = document.getElementById('staffNotificationCount');
    
    if (notifications > 0) {
        countElement.textContent = notifications;
        countElement.style.display = 'inline-block';
    }
}

// Show message
function showMessage(text, type) {
    const colors = {
        success: '#4CAF50',
        error: '#f44336',
        warning: '#ff9800',
        info: '#2196F3'
    };
    
    // Remove existing
    const oldMsg = document.getElementById('tempMessage');
    if (oldMsg) oldMsg.remove();
    
    // Create new
    const msg = document.createElement('div');
    msg.id = 'tempMessage';
    msg.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${colors[type]};
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        z-index: 10001;
        animation: slideIn 0.3s ease;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 400px;
    `;
    msg.innerHTML = `<i class="fas fa-${getMessageIcon(type)}"></i> ${text}`;
    document.body.appendChild(msg);
    
    // Auto remove
    setTimeout(() => msg.remove(), 3000);
}

function getMessageIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Email validation
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// ========== UI CONTROLS ==========

// Modal controls
function openStaffEditProfile() {
    document.getElementById('editProfileModal').style.display = 'flex';
}
function closeEditProfileModal() {
    document.getElementById('editProfileModal').style.display = 'none';
}
function showChangePasswordModal() {
    document.getElementById('changePasswordModal').style.display = 'flex';
}
function closeChangePasswordModal() {
    document.getElementById('changePasswordModal').style.display = 'none';
}
function showDeleteAccountModal() {
    document.getElementById('deleteAccountModal').style.display = 'flex';
}
function closeDeleteAccountModal() {
    document.getElementById('deleteAccountModal').style.display = 'none';
}

// Avatar overlay
function showAvatarOverlay() {
    const overlay = document.getElementById('avatarOverlay');
    if (overlay) overlay.style.display = 'flex';
}
function hideAvatarOverlay() {
    const overlay = document.getElementById('avatarOverlay');
    if (overlay) overlay.style.display = 'none';
}

// Quick image actions
function showQuickImageActions() {
    const actions = document.getElementById('quickImageActions');
    actions.style.display = 'block';
}
function closeQuickActions() {
    const actions = document.getElementById('quickImageActions');
    actions.style.display = 'none';
}

// Settings menu
function showSettingsMenu() {
    const menu = document.getElementById('settingsMenu');
    menu.style.display = 'block';
}
function closeSettingsMenu() {
    const menu = document.getElementById('settingsMenu');
    menu.style.display = 'none';
}

// Notifications
function showStaffNotifications() {
    showMessage('You have no new notifications', 'info');
}

// Export profile data
function exportProfileData() {
    const profileData = localStorage.getItem('staffProfileData');
    if (!profileData) {
        showMessage('No profile data to export', 'info');
        return;
    }
    
    const dataStr = JSON.stringify(JSON.parse(profileData), null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `staff-profile-${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    showMessage('Profile data exported successfully', 'success');
}

// Privacy settings
function showPrivacySettings() {
    showMessage('Privacy settings feature coming soon', 'info');
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    #editProfileModal > div,
    #changePasswordModal > div,
    #deleteAccountModal > div {
        animation: fadeIn 0.3s ease;
    }
    
    button:hover {
        transform: translateY(-2px);
        transition: transform 0.2s;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    #settingsMenu > div:hover,
    #quickImageActions > div:hover {
        background: #f8f9fa;
        transition: background 0.2s;
    }
    
    #staffProfileAvatar:hover {
        transform: scale(1.05);
        transition: transform 0.3s;
    }
`;
document.head.appendChild(style);

// Close modals on outside click
document.addEventListener('click', function(e) {
    // Close settings menu
    const settingsMenu = document.getElementById('settingsMenu');
    if (settingsMenu && !e.target.closest('#settingsMenu') && !e.target.closest('.fa-cog')) {
        settingsMenu.style.display = 'none';
    }
    
    // Close quick image actions
    const quickActions = document.getElementById('quickImageActions');
    if (quickActions && !e.target.closest('#quickImageActions') && !e.target.closest('.fa-ellipsis-v')) {
        quickActions.style.display = 'none';
    }
    
    // Close modals
    const editModal = document.getElementById('editProfileModal');
    if (editModal && e.target === editModal) closeEditProfileModal();
    
    const passModal = document.getElementById('changePasswordModal');
    if (passModal && e.target === passModal) closeChangePasswordModal();
    
    const deleteModal = document.getElementById('deleteAccountModal');
    if (deleteModal && e.target === deleteModal) closeDeleteAccountModal();
});
</script><!-- Message Display -->
<?php if ($message): ?>
<div class="message <?php echo $message_type; ?>" style="background: <?php echo $message_type === 'success' ? '#88d49a' : ($message_type === 'error' ? '#ddcd3e' : '#d1c18b'); ?>; color: <?php echo $message_type === 'success' ? '#155724' : ($message_type === 'error' ? '#721c24' : '#856404'); ?>; padding: 15px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; border: 1px solid <?php echo $message_type === 'success' ? '#c3e6cb' : ($message_type === 'error' ? '#f5c6cb' : '#ffeaa7'); ?>;">
    <span style="display: flex; align-items: center; gap: 10px;">
        <i class="fas fa-info-circle"></i> <?php echo $message; ?>
    </span>
    <button onclick="this.parentElement.style.display='none'" style="background: none; border: none; font-size: 20px; cursor: pointer; color: inherit;">&times;</button>
</div>
<?php endif; ?>

<!-- Stats Cards - 2 Rows x 3 Columns -->
<div class="stats-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px;">

    <!-- Row 1, Column 1 -->
    <div class="stat-card" onclick="showLowStock()" style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); cursor: pointer; transition: all 0.3s; border: 2px solid #e0e0e0; text-align: center;">
        <div class="stat-icon" style="width: 60px; height: 60px; background: linear-gradient(135deg, #e74c3c, #c0392b); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
            <i class="fas fa-boxes" style="font-size: 24px; color: white;"></i>
        </div>
        <div class="stat-value" style="font-size: 36px; font-weight: 700; color: #2c3e50; margin-bottom: 5px;"><?php echo $stats['low_stock']; ?></div>
        <div class="stat-label" style="font-size: 16px; color: #34495e; font-weight: 600; margin-bottom: 5px;">Low Stock Items</div>
        <p style="font-size: 12px; color: #7f8c8d; margin: 0;">Items need restocking</p>
    </div>

    <!-- Row 1, Column 2 -->
    <div class="stat-card" onclick="showPendingTests()" style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); cursor: pointer; transition: all 0.3s; border: 2px solid #e0e0e0; text-align: center;">
        <div class="stat-icon" style="width: 60px; height: 60px; background: linear-gradient(135deg, #3498db, #2980b9); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
            <i class="fas fa-flask" style="font-size: 24px; color: white;"></i>
        </div>
        <div class="stat-value" style="font-size: 36px; font-weight: 700; color: #2c3e50; margin-bottom: 5px;"><?php echo $stats['pending_tests']; ?></div>
        <div class="stat-label" style="font-size: 16px; color: #34495e; font-weight: 600; margin-bottom: 5px;">Pending Lab Tests</div>
        <p style="font-size: 12px; color: #7f8c8d; margin: 0;">Tests awaiting results</p>
    </div>

    <!-- Row 1, Column 3 -->
    <div class="stat-card" onclick="showCleaningTasks()" style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); cursor: pointer; transition: all 0.3s; border: 2px solid #e0e0e0; text-align: center;">
        <div class="stat-icon" style="width: 60px; height: 60px; background: linear-gradient(135deg, #2ecc71, #27ae60); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
            <i class="fas fa-broom" style="font-size: 24px; color: white;"></i>
        </div>
        <div class="stat-value" style="font-size: 36px; font-weight: 700; color: #2c3e50; margin-bottom: 5px;"><?php echo $stats['today_cleaning']; ?></div>
        <div class="stat-label" style="font-size: 16px; color: #34495e; font-weight: 600; margin-bottom: 5px;">Today's Cleaning</div>
        <p style="font-size: 12px; color: #7f8c8d; margin: 0;">Tasks pending</p>
    </div>

    <!-- Row 2, Column 1 -->
    <div class="stat-card" onclick="showMaintenance()" style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); cursor: pointer; transition: all 0.3s; border: 2px solid #e0e0e0; text-align: center;">
        <div class="stat-icon" style="width: 60px; height: 60px; background: linear-gradient(135deg, #f39c12, #e67e22); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
            <i class="fas fa-tools" style="font-size: 24px; color: white;"></i>
        </div>
        <div class="stat-value" style="font-size: 36px; font-weight: 700; color: #2c3e50; margin-bottom: 5px;"><?php echo $stats['pending_maintenance']; ?></div>
        <div class="stat-label" style="font-size: 16px; color: #34495e; font-weight: 600; margin-bottom: 5px;">Maintenance</div>
        <p style="font-size: 12px; color: #7f8c8d; margin: 0;">Pending tasks</p>
    </div>

    <!-- Row 2, Column 2 -->
    <div class="stat-card" onclick="showMyTasks()" style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); cursor: pointer; transition: all 0.3s; border: 2px solid #e0e0e0; text-align: center;">
        <div class="stat-icon" style="width: 60px; height: 60px; background: linear-gradient(135deg, #9b59b6, #8e44ad); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
            <i class="fas fa-tasks" style="font-size: 24px; color: white;"></i>
        </div>
        <div class="stat-value" style="font-size: 36px; font-weight: 700; color: #2c3e50; margin-bottom: 5px;"><?php echo $stats['my_tasks']; ?></div>
        <div class="stat-label" style="font-size: 16px; color: #34495e; font-weight: 600; margin-bottom: 5px;">My Tasks</div>
        <p style="font-size: 12px; color: #7f8c8d; margin: 0;">Assigned to me</p>
    </div>

    <!-- Row 2, Column 3 -->
    <div class="stat-card" onclick="showPendingOrders()" style="background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); cursor: pointer; transition: all 0.3s; border: 2px solid #e0e0e0; text-align: center;">
        <div class="stat-icon" style="width: 60px; height: 60px; background: linear-gradient(135deg, #1abc9c, #16a085); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
            <i class="fas fa-truck-loading" style="font-size: 24px; color: white;"></i>
        </div>
        <div class="stat-value" style="font-size: 36px; font-weight: 700; color: #2c3e50; margin-bottom: 5px;"><?php echo count($pending_orders); ?></div>
        <div class="stat-label" style="font-size: 16px; color: #34495e; font-weight: 600; margin-bottom: 5px;">Pending Orders</div>
        <p style="font-size: 12px; color: #7f8c8d; margin: 0;">Supply orders</p>
    </div>

</div>

<!-- Add hover effects and responsive design -->
<style>
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}

@media (max-width: 1200px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr) !important;
    }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr !important;
    }
}
</style>

<!-- JavaScript for card click functions -->
<script>
function showLowStock() {
    alert('Showing Low Stock Items');
    // In real implementation: window.location.href = 'low-stock.php';
}

function showPendingTests() {
    alert('Showing Pending Lab Tests');
    // In real implementation: window.location.href = 'pending-tests.php';
}

function showCleaningTasks() {
    alert('Showing Today\'s Cleaning Tasks');
    // In real implementation: window.location.href = 'cleaning-tasks.php';
}

function showMaintenance() {
    alert('Showing Maintenance Tasks');
    // In real implementation: window.location.href = 'maintenance.php';
}

function showMyTasks() {
    alert('Showing My Assigned Tasks');
    // In real implementation: window.location.href = 'my-tasks.php';
}

function showPendingOrders() {
    alert('Showing Pending Supply Orders');
    // In real implementation: window.location.href = 'pending-orders.php';
}
</script>
 <!-- Quick Actions -->
<!--div class="quick-actions" style="text-align:left;">
    <h2 class="section-title">
        <i class="fas fa-bolt"></i> system Actions
    </h2>

    <div class="actions-grid"
         style="
            display:flex;
            flex-direction:column;   /* VERTICAL */
            align-items:flex-start;  /* LEFT */
            gap:12px;
         ">

        <button class="action-btn"
                style="display:flex;align-items:center;gap:10px;text-align:left;"
                onclick="openModal('inventoryModal')">
            <i class="fas fa-plus-circle"></i>
            <span>Add Inventory Item</span>
        </button>

        <button class="action-btn"
                style="display:flex;align-items:center;gap:10px;text-align:left;"
                onclick="openModal('labModal')">
            <i class="fas fa-file-medical"></i>
            <span>Update Lab Test</span>
        </button>

        <button class="action-btn"
                style="display:flex;align-items:center;gap:10px;text-align:left;"
                onclick="openModal('cleaningModal')">
            <i class="fas fa-calendar-plus"></i>
            <span>Add Cleaning Task</span>
        </button>

        <button class="action-btn"
                style="display:flex;align-items:center;gap:10px;text-align:left;"
                onclick="openModal('taskModal')">
            <i class="fas fa-tasks"></i>
            <span>Add New Task</span>
        </button>

        <button class="action-btn"
                style="display:flex;align-items:center;gap:10px;text-align:left;"
                onclick="openModal('supplyModal')">
            <i class="fas fa-truck-loading"></i>
            <span>Order Supplies</span>
        </button>

        <button class="action-btn"
                style="display:flex;align-items:center;gap:10px;text-align:left;"
                onclick="openModal('maintenanceModal')">
            <i class="fas fa-tools"></i>
            <span>Schedule Maintenance</span>
        </button>

        <button class="action-btn"
                style="display:flex;align-items:center;gap:10px;text-align:left;"
                onclick="openModal('reportModal')">
            <i class="fas fa-chart-bar"></i>
            <span>Generate Report</span>
        </button>

        <button class="action-btn"
                style="display:flex;align-items:center;gap:10px;text-align:left;"
                onclick="quickRestock()">
            <i class="fas fa-box"></i>
            <span>syst Restock</span>
        </button>

    </div>
</div-->
<!-- DASHBOARD WRAPPER -->
<div style="display:grid; grid-template-columns:260px 1fr; gap:30px; align-items:start;">

    <!-- ================= LEFT SIDE : QUICK ACTIONS ================= -->
    <div style="background-color: #538f83;" class="quick-actions" style="text-align:left;">
        <h2 class="section-title">
            <i class="fas fa-bolt"></i> system Actions
        </h2>

        <div class="actions-grid"
             style="display:flex; flex-direction:column; align-items:flex-start; gap:12px;">

            <button class="action-btn" style="display:flex;align-items:center;gap:10px;" onclick="openModal('inventoryModal')">
                <i class="fas fa-plus-circle"></i><span>Add Inventory Item</span>
            </button>

            <button class="action-btn" style="display:flex;align-items:center;gap:10px;" onclick="openModal('labModal')">
                <i class="fas fa-file-medical"></i><span>Update Lab Test</span>
            </button>

            <button class="action-btn" style="display:flex;align-items:center;gap:10px;" onclick="openModal('cleaningModal')">
                <i class="fas fa-calendar-plus"></i><span>Add Cleaning Task</span>
            </button>

            <button class="action-btn" style="display:flex;align-items:center;gap:10px;" onclick="openModal('taskModal')">
                <i class="fas fa-tasks"></i><span>Add New Task</span>
            </button>

            <button class="action-btn" style="display:flex;align-items:center;gap:10px;" onclick="openModal('supplyModal')">
                <i class="fas fa-truck-loading"></i><span>Order Supplies</span>
            </button>

            <button class="action-btn" style="display:flex;align-items:center;gap:10px;" onclick="openModal('maintenanceModal')">
                <i class="fas fa-tools"></i><span>Schedule Maintenance</span>
            </button>

            <button class="action-btn" style="display:flex;align-items:center;gap:10px;" onclick="openModal('reportModal')">
                <i class="fas fa-chart-bar"></i><span>Generate Report</span>
            </button>

            <button class="action-btn" style="display:flex;align-items:center;gap:10px;" onclick="quickRestock()">
                <i class="fas fa-box"></i><span>syst Restock</span>
            </button>

        </div>
    </div>

    <!-- ================= RIGHT SIDE : MAIN CONTENT ================= -->
    <div>

        <!-- Main Content Grid -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:30px; margin-bottom:30px;">

            <!-- LEFT COLUMN -->
            <div>
                <!-- Low Stock Items -->
                <div class="data-section">
                    <h2 class="section-title">
                        <i class="fas fa-exclamation-triangle"></i> Low Stock Items
                    </h2>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Item Name</th>
                                    <th>Current Qty</th>
                                    <th>Min Qty</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($low_stock_items as $item): ?>
                                <tr>
                                    <td>
                                        <strong><?= $item['item_name'] ?></strong><br>
                                        <small style="color:#666;">
                                            <?= $item['category'] ?> | <?= $item['location'] ?>
                                        </small>
                                    </td>
                                    <td class="text-danger">
                                        <?= $item['quantity'] ?> <?= $item['unit'] ?>
                                    </td>
                                    <td><?= $item['min_quantity'] ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-success"
                                                onclick="restockItem('<?= $item['item_name'] ?>')">
                                            <i class="fas fa-plus"></i> Restock
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- My Tasks -->
                <div class="data-section">
                    <h2 class="section-title">
                        <i class="fas fa-tasks"></i> My Tasks
                    </h2>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Priority</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($my_tasks as $task): ?>
                                <tr>
                                    <td>
                                        <strong><?= $task['title'] ?></strong><br>
                                        <small style="color:#666;">
                                            <?= substr($task['description'],0,40) ?>...
                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?= $task['priority'] ?>">
                                            <?= $task['priority'] ?>
                                        </span>
                                    </td>
                                    <td><?= $task['due_date'] ?></td>
                                    <td>
                                        <span class="badge badge-<?= $task['status'] ?>">
                                            <?= $task['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- RIGHT COLUMN -->
            <div>
                <!-- Pending Orders -->
                <div class="data-section">
                    <h2 class="section-title">
                        <i class="fas fa-truck-loading"></i> Pending Supply Orders
                    </h2>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Item</th>
                                    <th>Qty</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($pending_orders as $order): ?>
                                <tr>
                                    <td><strong><?= $order['order_id'] ?></strong></td>
                                    <td><?= $order['item_name'] ?></td>
                                    <td><?= $order['quantity'] ?></td>
                                    <td>
                                        <span class="badge badge-<?= $order['status'] ?>">
                                            <?= $order['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Maintenance Schedule -->
                <div class="data-section">
                    <h2 class="section-title">
                        <i class="fas fa-tools"></i> Maintenance Schedule
                    </h2>

                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Equipment</th>
                                    <th>Type</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($maintenance_schedule as $m): ?>
                                <tr>
                                    <td><?= $m['equipment'] ?></td>
                                    <td><?= $m['maintenance_type'] ?></td>
                                    <td><?= $m['scheduled_date'] ?></td>
                                    <td>
                                        <span class="badge badge-<?= $m['status'] ?>">
                                            <?= $m['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

       
    </div>

</div>


<script>
// Modal functions
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

// Restock item
function restockItem(itemName) {
    const quantity = prompt(`How many units of "${itemName}" would you like to add?`, "50");
    if (quantity && !isNaN(quantity) && quantity > 0) {
        showNotification(`Restocked ${quantity} units of ${itemName} successfully!`, 'success');
    }
}

// Bulk restock
function bulkRestock() {
    showNotification('Bulk restock initiated! Orders placed for all selected items.', 'success');
    closeModal('quickRestockModal');
}

// Quick restock function
function quickRestock() {
    openModal('quickRestockModal');
}

// Generate report
function generateReport() {
    showNotification('Report generated successfully! Download will start shortly.', 'success');
    closeModal('reportModal');
}

// Show sections
function showLowStock() {
    document.querySelector('[data-section="low-stock"]')?.scrollIntoView({behavior: 'smooth'});
}

function showPendingTests() {
    alert('Showing pending lab tests...');
}

function showCleaningTasks() {
    alert('Showing cleaning tasks...');
}

function showMaintenance() {
    document.querySelector('[data-section="maintenance"]')?.scrollIntoView({behavior: 'smooth'});
}

function showMyTasks() {
    document.querySelector('[data-section="my-tasks"]')?.scrollIntoView({behavior: 'smooth'});
}

function showPendingOrders() {
    document.querySelector('[data-section="pending-orders"]')?.scrollIntoView({behavior: 'smooth'});
}

// Notification system
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    notification.style.display = 'block';
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Auto-close messages after 5 seconds
setTimeout(() => {
    const messages = document.querySelectorAll('.message');
    messages.forEach(msg => {
        msg.style.display = 'none';
    });
}, 5000);

// Add smooth scrolling to sections
document.addEventListener('DOMContentLoaded', function() {
    // Animate stat cards on load
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Set minimum dates
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        if (!input.value) {
            input.min = new Date().toISOString().split('T')[0];
        }
    });
    
    // Set current time for time inputs
    const timeInputs = document.querySelectorAll('input[type="time"]');
    timeInputs.forEach(input => {
        if (!input.value) {
            const now = new Date();
            input.value = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
        }
    });
});

// Print function
function printReport() {
    window.print();
}

// Export to Excel function
function exportToExcel() {
    showNotification('Exporting to Excel...', 'success');
}

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    const tooltips = document.querySelectorAll('.tooltip');
    tooltips.forEach(tooltip => {
        tooltip.addEventListener('mouseenter', function() {
            const tooltipText = this.querySelector('.tooltiptext');
            if (tooltipText) {
                tooltipText.style.visibility = 'visible';
                tooltipText.style.opacity = '1';
            }
        });
        
        tooltip.addEventListener('mouseleave', function() {
            const tooltipText = this.querySelector('.tooltiptext');
            if (tooltipText) {
                tooltipText.style.visibility = 'hidden';
                tooltipText.style.opacity = '0';
            }
        });
    });
});
</script>

</body>
</html>