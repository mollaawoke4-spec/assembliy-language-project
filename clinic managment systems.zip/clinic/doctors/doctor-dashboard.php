<?php
session_start();
require "../db.php";

// Check if user is logged in and is doctor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: ../login.php");
    exit();
}

// Get doctor info
$doctor_name = $_SESSION['name'] ?? 'Doctor';
$doctor_id = $_SESSION['user_id'];

// Handle form submissions with fallback data
$message = '';
$message_type = '';
$success_data = [];

// Add Medical Record
if (isset($_POST['add_medical_record'])) {
    $patient_name = $_POST['patient_name'] ?? '';
    $visit_date = $_POST['visit_date'] ?? date('Y-m-d');
    $symptoms = $_POST['symptoms'] ?? '';
    $diagnosis = $_POST['diagnosis'] ?? '';
    $treatment = $_POST['treatment'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    // Save to session for demo
    if (!isset($_SESSION['medical_records'])) {
        $_SESSION['medical_records'] = [];
    }
    
    $record_id = 'MR-' . rand(1000, 9999);
    $_SESSION['medical_records'][] = [
        'id' => $record_id,
        'patient_name' => $patient_name,
        'visit_date' => $visit_date,
        'symptoms' => $symptoms,
        'diagnosis' => $diagnosis,
        'treatment' => $treatment,
        'notes' => $notes,
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $message = "Medical record added successfully! Record ID: $record_id";
    $message_type = "success";
    $success_data = ['record_id' => $record_id];
}

// Add Prescription
if (isset($_POST['add_prescription'])) {
    $patient_name = $_POST['patient_name'] ?? '';
    $medication = $_POST['medication'] ?? '';
    $dosage = $_POST['dosage'] ?? '';
    $frequency = $_POST['frequency'] ?? '';
    $duration = $_POST['duration'] ?? '';
    $instructions = $_POST['instructions'] ?? '';
    
    if (!isset($_SESSION['prescriptions'])) {
        $_SESSION['prescriptions'] = [];
    }
    
    $prescription_id = 'RX-' . rand(1000, 9999);
    $_SESSION['prescriptions'][] = [
        'id' => $prescription_id,
        'patient_name' => $patient_name,
        'medication' => $medication,
        'dosage' => $dosage,
        'frequency' => $frequency,
        'duration' => $duration,
        'instructions' => $instructions,
        'status' => 'active',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $message = "Prescription added successfully! Prescription ID: $prescription_id";
    $message_type = "success";
}

// Request Lab Test
if (isset($_POST['request_lab_test'])) {
    $patient_name = $_POST['patient_name'] ?? '';
    $test_type = $_POST['test_type'] ?? '';
    $test_date = $_POST['test_date'] ?? date('Y-m-d');
    $notes = $_POST['notes'] ?? '';
    
    if (!isset($_SESSION['lab_tests'])) {
        $_SESSION['lab_tests'] = [];
    }
    
    $test_id = 'LAB-' . rand(1000, 9999);
    $_SESSION['lab_tests'][] = [
        'id' => $test_id,
        'patient_name' => $patient_name,
        'test_type' => $test_type,
        'test_date' => $test_date,
        'notes' => $notes,
        'status' => 'pending',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $message = "Lab test requested successfully! Test ID: $test_id";
    $message_type = "success";
}

// Record Vitals
if (isset($_POST['record_vitals'])) {
    $patient_name = $_POST['patient_name'] ?? '';
    $blood_pressure = $_POST['blood_pressure'] ?? '';
    $heart_rate = $_POST['heart_rate'] ?? '';
    $temperature = $_POST['temperature'] ?? '';
    $weight = $_POST['weight'] ?? '';
    $height = $_POST['height'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    if (!isset($_SESSION['patient_vitals'])) {
        $_SESSION['patient_vitals'] = [];
    }
    
    $vital_id = 'VIT-' . rand(1000, 9999);
    $_SESSION['patient_vitals'][] = [
        'id' => $vital_id,
        'patient_name' => $patient_name,
        'blood_pressure' => $blood_pressure,
        'heart_rate' => $heart_rate,
        'temperature' => $temperature,
        'weight' => $weight,
        'height' => $height,
        'notes' => $notes,
        'recorded_at' => date('Y-m-d H:i:s')
    ];
    
    $message = "Patient vitals recorded successfully!";
    $message_type = "success";
}

// Sample data for demonstration
$today_appointments = 8;
$total_patients = 42;
$pending_tests = 5;
$active_prescriptions = 12;
$medical_records_count = 28;
$upcoming_appointments = 15;

// Try to get real data if available
try {
    $result = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE doctor_id = '$doctor_id' AND DATE(appointment_date) = CURDATE()");
    if ($result) $today_appointments = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

try {
    $result = $conn->query("SELECT COUNT(DISTINCT patient_id) as count FROM medical_records WHERE doctor_id = '$doctor_id'");
    if ($result) $total_patients = $result->fetch_assoc()['count'];
} catch (Exception $e) {}

// Sample data arrays
$appointments_data = [
    ['id' => 1, 'patient_name' => 'John Doe', 'time' => '09:00 AM', 'reason' => 'General Checkup', 'status' => 'confirmed'],
    ['id' => 2, 'patient_name' => 'Jane Smith', 'time' => '10:30 AM', 'reason' => 'Follow-up', 'status' => 'confirmed'],
    ['id' => 3, 'patient_name' => 'Robert Johnson', 'time' => '11:45 AM', 'reason' => 'Blood Pressure', 'status' => 'pending'],
    ['id' => 4, 'patient_name' => 'Sarah Wilson', 'time' => '02:15 PM', 'reason' => 'Diabetes Management', 'status' => 'confirmed'],
    ['id' => 5, 'patient_name' => 'Michael Brown', 'time' => '03:30 PM', 'reason' => 'Annual Physical', 'status' => 'confirmed']
];

$patients_data = [
    ['id' => 1, 'name' => 'John Doe', 'age' => 45, 'last_visit' => '2024-01-15', 'condition' => 'Hypertension'],
    ['id' => 2, 'name' => 'Jane Smith', 'age' => 38, 'last_visit' => '2024-01-10', 'condition' => 'Diabetes'],
    ['id' => 3, 'name' => 'Robert Johnson', 'age' => 52, 'last_visit' => '2024-01-05', 'condition' => 'Asthma'],
    ['id' => 4, 'name' => 'Sarah Wilson', 'age' => 29, 'last_visit' => '2023-12-20', 'condition' => 'Migraine'],
    ['id' => 5, 'name' => 'Michael Brown', 'age' => 61, 'last_visit' => '2023-12-15', 'condition' => 'Arthritis']
];

$prescriptions_data = $_SESSION['prescriptions'] ?? [
    ['id' => 'RX-001', 'patient_name' => 'John Doe', 'medication' => 'Lisinopril', 'dosage' => '10mg', 'frequency' => 'Once daily', 'status' => 'active'],
    ['id' => 'RX-002', 'patient_name' => 'Jane Smith', 'medication' => 'Metformin', 'dosage' => '500mg', 'frequency' => 'Twice daily', 'status' => 'active'],
    ['id' => 'RX-003', 'patient_name' => 'Robert Johnson', 'medication' => 'Albuterol', 'dosage' => '2 puffs', 'frequency' => 'As needed', 'status' => 'active']
];

$lab_tests_data = $_SESSION['lab_tests'] ?? [
    ['id' => 'LAB-001', 'patient_name' => 'John Doe', 'test_type' => 'Complete Blood Count', 'test_date' => date('Y-m-d'), 'status' => 'pending'],
    ['id' => 'LAB-002', 'patient_name' => 'Jane Smith', 'test_type' => 'Blood Sugar Test', 'test_date' => date('Y-m-d'), 'status' => 'pending']
];

$medical_records_data = $_SESSION['medical_records'] ?? [
    ['id' => 'MR-001', 'patient_name' => 'John Doe', 'visit_date' => '2024-01-15', 'diagnosis' => 'Hypertension Stage 1', 'treatment' => 'Lifestyle modification'],
    ['id' => 'MR-002', 'patient_name' => 'Jane Smith', 'visit_date' => '2024-01-10', 'diagnosis' => 'Type 2 Diabetes', 'treatment' => 'Metformin 500mg']
];

$vitals_data = $_SESSION['patient_vitals'] ?? [
    ['id' => 'VIT-001', 'patient_name' => 'John Doe', 'blood_pressure' => '120/80', 'heart_rate' => 72, 'temperature' => 36.6, 'recorded_at' => '2024-01-15']
];

$today = date('Y-m-d');
$current_time = date('H:i');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard - Clinic Management System</title>
    <style>
        :root {
            --primary: #1976d2;
            --primary-light: #e3f2fd;
            --secondary: #388e3c;
            --secondary-light: #e8f5e9;
            --danger: #d32f2f;
            --warning: #f57c00;
            --info: #0288d1;
            --success: #388e3c;
            --dark: #2c3e50;
            --light: #f5f7fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--dark) 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .doctor-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .doctor-avatar {
            width: 60px;
            height: 60px;
            background: white;
            color: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }

        .doctor-details h1 {
            font-size: 24px;
            margin-bottom: 5px;
        }

        .doctor-details p {
            opacity: 0.9;
            font-size: 14px;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            display: flex;
            align-items: center;
            gap: 20px;
            transition: all 0.3s;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .stat-card:nth-child(1) .stat-icon { background: var(--primary); }
        .stat-card:nth-child(2) .stat-icon { background: var(--secondary); }
        .stat-card:nth-child(3) .stat-icon { background: var(--warning); }
        .stat-card:nth-child(4) .stat-icon { background: var(--info); }
        .stat-card:nth-child(5) .stat-icon { background: var(--success); }
        .stat-card:nth-child(6) .stat-icon { background: var(--dark); }

        .stat-content h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .stat-content .number {
            font-size: 32px;
            font-weight: 700;
            color: var(--dark);
        }

        /* Quick Actions */
        .quick-actions {
            background:rgba(55, 187, 14, 0.08);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }

        .section-title {
            color: var(--dark);
            font-size: 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            color: var(--primary);
        }

        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }

        .action-btn {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: var(--dark);
        }

        .action-btn:hover {
            border-color: var(--primary);
            background: var(--primary-light);
            transform: translateY(-3px);
        }

        .action-btn i {
            font-size: 28px;
            color: var(--primary);
        }

        .action-btn span {
            font-weight: 500;
            font-size: 14px;
        }

        /* Data Sections */
        .data-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
            margin-bottom: 30px;
        }

        .data-section {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .section-header {
            padding: 20px;
            background: var(--light);
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .section-content {
            padding: 20px;
            max-height: 400px;
            overflow-y: auto;
        }

        /* Tables */
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            background: #f8f9fa;
            padding: 12px 15px;
            text-align: left;
            color: var(--dark);
            font-weight: 600;
            font-size: 14px;
            border-bottom: 2px solid #e9ecef;
        }

        .data-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e9ecef;
            font-size: 14px;
        }

        .data-table tr:hover {
            background: #f8f9fa;
        }

        /* Badges */
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
        }

        .badge-confirmed { background: #d4edda; color: #155724; }
        .badge-pending { background: #fff3cd; color: #856404; }
        .badge-active { background: #d1ecf1; color: #0c5460; }
        .badge-completed { background: #d4edda; color: #155724; }

        /* Forms */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--dark);
            font-weight: 500;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.1);
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        /* Buttons */
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: #1565c0;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #2e7d32;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #c62828;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            width: 100%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .modal-header {
            padding: 20px;
            background: var(--primary);
            color: white;
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-body {
            padding: 20px;
        }

        .close-modal {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .close-modal:hover {
            background: rgba(255,255,255,0.2);
        }

        /* Form Layout */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        /* Message */
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            animation: slideIn 0.5s;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Container */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Logout */
        .logout-btn {
            background: var(--danger);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .logout-btn:hover {
            background: #c62828;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .data-grid {
                grid-template-columns: 1fr;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .actions-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .doctor-info {
                flex-direction: column;
                text-align: center;
            }
        }

        @media (max-width: 480px) {
            .actions-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .section-content {
                padding: 10px;
            }
        }

        /* Patient Info Cards */
        .patient-card {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }

        .patient-card:hover {
            border-color: var(--primary);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        .patient-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .patient-name {
            font-weight: 600;
            color: var(--dark);
            font-size: 16px;
        }

        .patient-meta {
            display: flex;
            gap: 15px;
            color: #666;
            font-size: 13px;
            margin-bottom: 10px;
        }

        /* Appointment Cards */
        .appointment-card {
            background: white;
            border-left: 4px solid var(--primary);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .appointment-time {
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 8px;
        }

        .appointment-patient {
            font-weight: 500;
            color: var(--dark);
            margin-bottom: 5px;
        }

        .appointment-reason {
            color: #666;
            font-size: 13px;
        }

        /* Print Styles */
        @media print {
            .no-print {
                display: none !important;
            }
            
            .modal {
                position: static;
                display: block !important;
                background: white;
            }
            
            .modal-content {
                box-shadow: none;
                max-width: none;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="container">
    <!-- Header -->
    <div class="header" style="display: flex; justify-content: space-between; align-items: center; padding: 20px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 10px; margin-bottom: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
        <div style="display: flex; align-items: center; gap: 20px;">
            <!-- Doctor Profile with Image Upload -->
            <div style="position: relative;">
                <!-- Doctor Avatar with Image Upload -->
                <div id="doctorAvatar" style="width: 80px; height: 80px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: bold; color: white; cursor: pointer; box-shadow: 0 3px 10px rgba(0,0,0,0.2); overflow: hidden; position: relative;" 
                     onclick="document.getElementById('avatarUpload').click()"
                     onmouseover="this.querySelector('.avatar-overlay')?.style.opacity='1'"
                     onmouseout="this.querySelector('.avatar-overlay')?.style.opacity='0'">
                    <!-- Initial or Uploaded Image -->
                    <span id="avatarInitial">Dr. <?php echo strtoupper(substr($doctor_name, 0, 1)); ?></span>
                    
                    <!-- Upload Overlay -->
                    <div class="avatar-overlay" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; color: white; font-size: 14px; opacity: 0; transition: opacity 0.3s;">
                        <i class="fas fa-camera"></i> Change
                    </div>
                </div>
                
                <!-- Hidden File Input -->
                <input type="file" id="avatarUpload" accept="image/*" style="display: none;" onchange="uploadProfileImage(this)">
                
                <!-- Upload Progress -->
                <div id="uploadProgress" style="display: none; position: absolute; top: -5px; left: -5px; right: -5px; bottom: -5px; background: rgba(0,0,0,0.7); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px;">
                    <i class="fas fa-spinner fa-spin"></i>
                </div>
                
                <!-- Camera Icon -->
                <div style="position: absolute; bottom: 0; right: 0; background: #4CAF50; color: white; border: 2px solid white; border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.2);"
                     onclick="document.getElementById('avatarUpload').click()">
                    <i class="fas fa-camera"></i>
                </div>
            </div>
            
            <!-- Doctor Details with Actions -->
            <div style="position: relative;">
                <h1 style="margin: 0; font-size: 24px; display: flex; align-items: center; gap: 10px;">
                    Welcome, Dr. <?php echo $doctor_name; ?>
                    <span onclick="toggleActions()" style="cursor: pointer; font-size: 16px; color: rgba(209, 18, 200, 0.8); background: green; padding: 4px 8px; border-radius: 4px; margin-left: 10px;">
                        <i class="fas fa-caret-down"></i> Actions
                    </span>
                </h1>
                <p style="margin: 5px 0; color: rgba(255,255,255,0.9);">Doctor Dashboard - Clinic Management System</p>
                <small style="color: rgba(255,255,255,0.8); display: flex; align-items: center; gap: 15px;">
                    <span><i class="far fa-calendar-alt"></i> <?php echo date('F j, Y'); ?></span>
                    <span><i class="far fa-clock"></i> <?php echo date('h:i A'); ?></span>
                    <span id="lastUpdate" style="font-size: 11px; background: rgba(255,255,255,0.15); padding: 2px 8px; border-radius: 10px;"></span>
                </small>
                
                <!-- Actions Dropdown -->
                <div id="actionDropdown" style="display: none; position: absolute; top: 100%; left: 0; background: white; border-radius: 8px; padding: 10px 0; box-shadow: 0 5px 20px rgba(0,0,0,0.15); min-width: 200px; z-index: 1000; margin-top: 10px;">
                    <button onclick="editProfile()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
                        <i class="fas fa-user-edit" style="color: #FF9800; width: 20px;"></i>
                        Edit Profile
                    </button>
                    <button onclick="updateProfile()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
                        <i class="fas fa-sync-alt" style="color: #4CAF50; width: 20px;"></i>
                        Update Profile
                    </button>
                    <button onclick="changeProfileImage()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
                        <i class="fas fa-image" style="color: #2196F3; width: 20px;"></i>
                        Change Photo
                    </button>
                    <div style="border-top: 1px solid #eee; margin: 5px 0;"></div>
                    <button onclick="changePassword()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #555; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
                        <i class="fas fa-key" style="color: #9C27B0; width: 20px;"></i>
                        Change Password
                    </button>
                    <button onclick="deleteAccount()" style="width: 100%; padding: 12px 15px; border: none; background: none; text-align: left; cursor: pointer; color: #e74c3c; display: flex; align-items: center; gap: 10px; transition: all 0.2s;">
                        <i class="fas fa-trash-alt" style="width: 20px;"></i>
                        Delete Account
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Right Side Buttons -->
        <div style="display: flex; align-items: center; gap: 15px;">
            <button onclick="window.print()" style="background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 10px 20px; border-radius: 25px; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: all 0.3s;">
                <i class="fas fa-print"></i> Print
            </button>
            <a href="../logout.php" style="background: rgba(231, 76, 60, 0.9); color: white; padding: 10px 25px; border-radius: 25px; text-decoration: none; display: flex; align-items: center; gap: 8px; transition: all 0.3s;">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
</div>

<!-- Edit Profile Modal with Image Upload -->
<div id="editModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
            <h2 style="margin: 0; color: #333; font-size: 24px;">
                <i class="fas fa-user-md" style="color: #667eea; margin-right: 10px;"></i>
                Edit Doctor Profile
            </h2>
            <button onclick="closeModal()" style="background: none; border: none; font-size: 28px; cursor: pointer; color: #999; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 50%; transition: all 0.2s;">&times;</button>
        </div>
        
        <!-- Profile Image Section -->
        <div style="text-align: center; margin-bottom: 25px;">
            <div id="modalAvatar" style="width: 120px; height: 120px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 48px; font-weight: bold; color: white; overflow: hidden; position: relative; cursor: pointer;"
                 onclick="document.getElementById('modalImageUpload').click()">
                <!-- Image or Initial will be loaded here -->
                <span id="modalInitial">Dr. <?php echo strtoupper(substr($doctor_name, 0, 1)); ?></span>
            </div>
            
            <!-- Hidden File Input for Modal -->
            <input type="file" id="modalImageUpload" accept="image/*" style="display: none;" onchange="uploadModalImage(this)">
            
            <div style="display: flex; gap: 10px; justify-content: center;">
                <button onclick="document.getElementById('modalImageUpload').click()" 
                        style="background: #2196F3; color: white; border: none; padding: 8px 20px; border-radius: 20px; cursor: pointer; font-size: 14px;">
                    <i class="fas fa-upload"></i> Upload Photo
                </button>
                <button onclick="removeProfileImage()" 
                        style="background: #f8f9fa; color: #666; border: 1px solid #ddd; padding: 8px 20px; border-radius: 20px; cursor: pointer; font-size: 14px;">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
            <div style="font-size: 12px; color: #666; margin-top: 8px;">
                Max 5MB • JPG, PNG, GIF
            </div>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">DOCTOR NAME *</label>
                <input type="text" id="editName" value="Dr. <?php echo $doctor_name; ?>" style="width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 16px; transition: all 0.3s;" onfocus="this.style.borderColor='#667eea'; this.style.boxShadow='0 0 0 3px rgba(102,126,234,0.1)'" onblur="this.style.borderColor='#e0e0e0'; this.style.boxShadow='none'">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">EMAIL ADDRESS *</label>
                <input type="email" id="editEmail" placeholder="doctor@clinic.com" style="width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 16px; transition: all 0.3s;" onfocus="this.style.borderColor='#667eea'; this.style.boxShadow='0 0 0 3px rgba(102,126,234,0.1)'" onblur="this.style.borderColor='#e0e0e0'; this.style.boxShadow='none'">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">SPECIALIZATION</label>
                <input type="text" id="editSpecialization" placeholder="Cardiology, Neurology, etc." style="width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 16px; transition: all 0.3s;" onfocus="this.style.borderColor='#667eea'; this.style.boxShadow='0 0 0 3px rgba(102,126,234,0.1)'" onblur="this.style.borderColor='#e0e0e0'; this.style.boxShadow='none'">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">PHONE NUMBER</label>
                <input type="tel" id="editPhone" placeholder="+1 (555) 123-4567" style="width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 16px; transition: all 0.3s;" onfocus="this.style.borderColor='#667eea'; this.style.boxShadow='0 0 0 3px rgba(102,126,234,0.1)'" onblur="this.style.borderColor='#e0e0e0'; this.style.boxShadow='none'">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 8px; color: #555; font-weight: 600; font-size: 14px;">DOCTOR BIO</label>
                <textarea id="editBio" placeholder="Brief description about the doctor..." rows="4" style="width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 16px; resize: vertical; transition: all 0.3s;" onfocus="this.style.borderColor='#667eea'; this.style.boxShadow='0 0 0 3px rgba(102,126,234,0.1)'" onblur="this.style.borderColor='#e0e0e0'; this.style.boxShadow='none'"></textarea>
            </div>
        </div>
        
        <div style="display: flex; gap: 15px; margin-top: 30px;">
            <button onclick="saveProfile()" style="flex: 1; background: linear-gradient(135deg, #4CAF50, #45a049); color: white; border: none; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 10px; transition: all 0.3s;">
                <i class="fas fa-save"></i> Save Changes
            </button>
            <button onclick="closeModal()" style="flex: 1; background: #f8f9fa; color: #666; border: 2px solid #e0e0e0; padding: 16px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: 600; transition: all 0.3s;">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- JavaScript for Image Upload -->
<script>
// Load saved profile image on page load
window.addEventListener('load', function() {
    loadSavedImage();
});

// Toggle actions dropdown
function toggleActions() {
    const dropdown = document.getElementById('actionDropdown');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('actionDropdown');
    if (!event.target.closest('.doctor-details') && 
        !event.target.closest('#actionDropdown') && 
        !event.target.closest('span[onclick*="toggleActions"]')) {
        dropdown.style.display = 'none';
    }
});

// Change profile image from dropdown
function changeProfileImage() {
    document.getElementById('avatarUpload').click();
    toggleActions(); // Close dropdown
}

// Upload profile image from header
function uploadProfileImage(input) {
    if (!input.files || !input.files[0]) return;
    
    const file = input.files[0];
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    
    // Validate file
    if (!allowedTypes.includes(file.type)) {
        showMessage('Please upload JPG, PNG, GIF or WebP images only.', 'error');
        return;
    }
    
    if (file.size > maxSize) {
        showMessage('Image size should be less than 5MB.', 'error');
        return;
    }
    
    // Show upload progress
    const progress = document.getElementById('uploadProgress');
    progress.style.display = 'flex';
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        // Update avatar in header
        updateAvatar(e.target.result);
        
        // Update modal avatar
        const modalAvatar = document.getElementById('modalAvatar');
        if (modalAvatar) {
            modalAvatar.innerHTML = `<img src="${e.target.result}" alt="Profile" style="width: 100%; height: 100%; object-fit: cover;">`;
        }
        
        // Save to localStorage
        localStorage.setItem('doctorProfileImage', e.target.result);
        localStorage.setItem('profileImageUpdated', new Date().toISOString());
        
        // Hide progress
        progress.style.display = 'none';
        
        showMessage('Profile image updated successfully!', 'success');
    };
    
    reader.onerror = function() {
        progress.style.display = 'none';
        showMessage('Failed to upload image. Please try again.', 'error');
    };
    
    reader.readAsDataURL(file);
}

// Upload image from modal
function uploadModalImage(input) {
    uploadProfileImage(input); // Reuse same function
}

// Update avatar with image
function updateAvatar(imageSrc) {
    const avatar = document.getElementById('doctorAvatar');
    const initial = document.getElementById('avatarInitial');
    
    if (avatar && initial) {
        initial.style.display = 'none';
        
        // Check if image already exists
        let img = avatar.querySelector('img');
        if (img) {
            img.src = imageSrc;
        } else {
            img = document.createElement('img');
            img.src = imageSrc;
            img.alt = 'Profile';
            img.style.cssText = 'width: 100%; height: 100%; object-fit: cover; position: absolute; top: 0; left: 0;';
            avatar.appendChild(img);
        }
    }
}

// Load saved image from localStorage
function loadSavedImage() {
    const savedImage = localStorage.getItem('doctorProfileImage');
    if (savedImage) {
        updateAvatar(savedImage);
        
        // Update modal avatar too
        const modalAvatar = document.getElementById('modalAvatar');
        const modalInitial = document.getElementById('modalInitial');
        if (modalAvatar && modalInitial) {
            modalInitial.style.display = 'none';
            modalAvatar.innerHTML = `<img src="${savedImage}" alt="Profile" style="width: 100%; height: 100%; object-fit: cover;">`;
        }
    }
}

// Remove profile image
function removeProfileImage() {
    if (!confirm('Remove profile image?')) return;
    
    // Remove from localStorage
    localStorage.removeItem('doctorProfileImage');
    
    // Reset to initial
    const avatar = document.getElementById('doctorAvatar');
    const initial = document.getElementById('avatarInitial');
    const modalAvatar = document.getElementById('modalAvatar');
    const modalInitial = document.getElementById('modalInitial');
    
    if (avatar && initial) {
        avatar.innerHTML = `<span id="avatarInitial">Dr. <?php echo strtoupper(substr($doctor_name, 0, 1)); ?></span>
                           <div class="avatar-overlay" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; color: white; font-size: 14px; opacity: 0; transition: opacity 0.3s;">
                               <i class="fas fa-camera"></i> Change
                           </div>`;
    }
    
    if (modalAvatar && modalInitial) {
        modalInitial.style.display = 'block';
        modalAvatar.innerHTML = `<span id="modalInitial">Dr. <?php echo strtoupper(substr($doctor_name, 0, 1)); ?></span>`;
    }
    
    showMessage('Profile image removed.', 'info');
}

// Edit Profile Modal
function editProfile() {
    document.getElementById('editModal').style.display = 'flex';
    document.getElementById('actionDropdown').style.display = 'none';
}

function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Update Profile
function updateProfile() {
    editProfile();
}

// Save Profile Changes
function saveProfile() {
    const name = document.getElementById('editName').value;
    const email = document.getElementById('editEmail').value;
    
    if (!name || !email) {
        showMessage('Please fill in all required fields.', 'error');
        return;
    }
    
    // Update header
    document.querySelector('h1').innerHTML = `Welcome, ${name} <span onclick="toggleActions()" style="cursor: pointer; font-size: 16px; color: rgba(255,255,255,0.8); background: rgba(255,255,255,0.1); padding: 4px 8px; border-radius: 4px; margin-left: 10px;"><i class="fas fa-caret-down"></i> Actions</span>`;
    
    // Update last update time
    const now = new Date();
    const lastUpdate = document.getElementById('lastUpdate');
    lastUpdate.textContent = `Last updated: ${now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    
    // Save profile data
    const profileData = {
        name: name,
        email: document.getElementById('editEmail').value,
        phone: document.getElementById('editPhone').value,
        specialization: document.getElementById('editSpecialization').value,
        bio: document.getElementById('editBio').value,
        updatedAt: now.toISOString()
    };
    localStorage.setItem('doctorProfileData', JSON.stringify(profileData));
    
    showMessage('Profile updated successfully!', 'success');
    closeModal();
}

// Change Password
function changePassword() {
    const newPass = prompt('Enter new password:');
    if (newPass) {
        const confirmPass = prompt('Confirm new password:');
        if (newPass === confirmPass) {
            showMessage('Password changed successfully!', 'success');
        } else {
            showMessage('Passwords do not match!', 'error');
        }
    }
}

// Delete Account
function deleteAccount() {
    if (confirm('⚠️ WARNING: This will permanently delete your account!\n\nClick OK to proceed.')) {
        const confirmText = prompt('Type "DELETE" to confirm:');
        if (confirmText === 'DELETE') {
            // Clear all profile data
            localStorage.clear();
            showMessage('Account deletion request submitted.', 'warning');
        } else {
            showMessage('Deletion cancelled.', 'info');
        }
    }
}

// Show Message
function showMessage(text, type) {
    const colors = {
        success: '#4CAF50',
        error: '#f44336',
        warning: '#ff9800',
        info: '#2196F3'
    };
    
    // Remove existing message
    const oldMsg = document.getElementById('tempMessage');
    if (oldMsg) oldMsg.remove();
    
    // Create new message
    const msg = document.createElement('div');
    msg.id = 'tempMessage';
    msg.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${colors[type] || colors.info};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 10001;
        animation: slideIn 0.3s ease;
        font-weight: 500;
    `;
    msg.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}"></i> ${text}`;
    document.body.appendChild(msg);
    
    setTimeout(() => {
        if (msg.parentElement) msg.remove();
    }, 3000);
}

// Add CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    #actionDropdown button:hover {
        background: #f8f9fa;
        padding-left: 20px;
    }
    
    #editModal > div {
        animation: fadeIn 0.3s ease;
    }
    
    .fa-spin {
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);

// Close modal on outside click
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target.id === 'editModal') closeModal();
});
</script>
        <!-- Right Side Actions -->
        <!--div style="display: flex; align-items: center; gap: 15px;">
            <button onclick="window.print()" style="background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 10px 20px; border-radius: 25px; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: all 0.3s;">
                <i class="fas fa-print"></i> Print
            </button>
            <a href="../logout.php" style="background: rgba(231, 76, 60, 0.9); color: white; padding: 10px 25px; border-radius: 25px; text-decoration: none; display: flex; align-items: center; gap: 8px; transition: all 0.3s;">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
</div-->

<!-- Profile Edit Modal -->
<div id="profileModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: white; border-radius: 15px; padding: 30px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="margin: 0; color: #333;">Edit Doctor Profile</h2>
            <button onclick="closeProfileModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #999; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">×</button>
        </div>
        
        <div style="text-align: center; margin-bottom: 25px;">
            <div id="modalAvatar" style="width: 100px; height: 100px; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 36px; font-weight: bold; color: white; overflow: hidden; position: relative;">
                Dr. <?php echo strtoupper(substr($doctor_name, 0, 1)); ?>
            </div>
            <input type="file" id="modalImageInput" accept="image/*" style="display: none;" onchange="previewModalImage(this)">
            <button onclick="document.getElementById('modalImageInput').click()" style="background: #2196F3; color: white; border: none; padding: 8px 20px; border-radius: 20px; cursor: pointer; margin-bottom: 10px;">
                <i class="fas fa-upload"></i> Upload Photo
            </button>
            <div style="font-size: 12px; color: #666; margin-top: 5px;">Max 5MB • JPG, PNG, GIF</div>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 15px;">
            <div>
                <label style="display: block; margin-bottom: 5px; color: #555; font-weight: 500;">Full Name *</label>
                <input type="text" id="doctorName" value="Dr. <?php echo $doctor_name; ?>" style="width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 5px; color: #555; font-weight: 500;">Email Address *</label>
                <input type="email" id="doctorEmail" placeholder="doctor@clinic.com" style="width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 5px; color: #555; font-weight: 500;">Phone Number</label>
                <input type="tel" id="doctorPhone" placeholder="+1 (555) 123-4567" style="width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 5px; color: #555; font-weight: 500;">Specialization</label>
                <input type="text" id="doctorSpecialization" placeholder="Cardiology, Neurology, etc." style="width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px;">
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 5px; color: #555; font-weight: 500;">Bio/Description</label>
                <textarea id="doctorBio" placeholder="Brief description about the doctor..." rows="3" style="width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px; resize: vertical;"></textarea>
            </div>
        </div>
        
        <div style="display: flex; gap: 10px; margin-top: 25px;">
            <button onclick="saveProfileChanges()" style="flex: 1; background: #4CAF50; color: white; border: none; padding: 12px; border-radius: 8px; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                <i class="fas fa-save"></i> Save Changes
            </button>
            <button onclick="closeProfileModal()" style="flex: 1; background: #f8f9fa; color: #333; border: 1px solid #ddd; padding: 12px; border-radius: 8px; cursor: pointer; font-size: 16px;">
                Cancel
            </button>
        </div>
    </div>
</div>

<!-- JavaScript Functions -->
<script>
// Toggle profile actions dropdown
function toggleProfileActions() {
    const dropdown = document.getElementById('profileActions');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('profileActions');
    if (!event.target.closest('.doctor-details') && !event.target.closest('#profileActions')) {
        dropdown.style.display = 'none';
    }
});

// Image upload functions
function openImageUpload() {
    document.getElementById('profileImageInput').click();
}

function uploadProfileImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const avatar = document.getElementById('doctorAvatar');
            avatar.innerHTML = `<img src="${e.target.result}" alt="Profile" style="width: 100%; height: 100%; object-fit: cover;">`;
            
            // Show success message
            showMessage('Profile image updated successfully!', 'success');
            
            // Save to localStorage for demo
            localStorage.setItem('doctorProfileImage', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}

// Load saved image on page load
window.addEventListener('load', function() {
    const savedImage = localStorage.getItem('doctorProfileImage');
    if (savedImage) {
        const avatar = document.getElementById('doctorAvatar');
        avatar.innerHTML = `<img src="${savedImage}" alt="Profile" style="width: 100%; height: 100%; object-fit: cover;">`;
    }
});

// Profile modal functions
function editProfile() {
    document.getElementById('profileModal').style.display = 'flex';
    toggleProfileActions(); // Close dropdown
}

function closeProfileModal() {
    document.getElementById('profileModal').style.display = 'none';
}

function previewModalImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const modalAvatar = document.getElementById('modalAvatar');
            modalAvatar.innerHTML = `<img src="${e.target.result}" alt="Profile" style="width: 100%; height: 100%; object-fit: cover;">`;
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function saveProfileChanges() {
    const name = document.getElementById('doctorName').value;
    const email = document.getElementById('doctorEmail').value;
    const phone = document.getElementById('doctorPhone').value;
    const specialization = document.getElementById('doctorSpecialization').value;
    const bio = document.getElementById('doctorBio').value;
    
    // Update header name
    document.querySelector('h1').innerHTML = `Welcome, ${name} <span onclick="toggleProfileActions()" style="cursor: pointer; font-size: 16px; color: rgba(255,255,255,0.8);"><i class="fas fa-caret-down"></i></span>`;
    
    // Save to localStorage for demo
    const profileData = {
        name: name,
        email: email,
        phone: phone,
        specialization: specialization,
        bio: bio,
        updatedAt: new Date().toISOString()
    };
    localStorage.setItem('doctorProfileData', JSON.stringify(profileData));
    
    // Show success message
    showMessage('Profile updated successfully!', 'success');
    closeProfileModal();
}

// Load saved profile data on page load
window.addEventListener('load', function() {
    const savedData = localStorage.getItem('doctorProfileData');
    if (savedData) {
        const data = JSON.parse(savedData);
        document.getElementById('doctorName').value = data.name || '';
        document.getElementById('doctorEmail').value = data.email || '';
        document.getElementById('doctorPhone').value = data.phone || '';
        document.getElementById('doctorSpecialization').value = data.specialization || '';
        document.getElementById('doctorBio').value = data.bio || '';
    }
});

// Account functions
function updateProfile() {
    editProfile(); // Open edit modal
}

function changePassword() {
    const newPassword = prompt('Enter new password:');
    if (newPassword) {
        const confirmPassword = prompt('Confirm new password:');
        if (newPassword === confirmPassword) {
            showMessage('Password changed successfully!', 'success');
        } else {
            showMessage('Passwords do not match!', 'error');
        }
    }
}

function deleteAccount() {
    if (confirm('⚠️ WARNING: This will permanently delete your account!\nAll your data will be lost.\n\nType "DELETE" to confirm:')) {
        const confirmation = prompt('Please type "DELETE" to confirm account deletion:');
        if (confirmation === 'DELETE') {
            // Simulate account deletion
            showMessage('Account deletion request submitted. Admin will review within 24 hours.', 'warning');
            // In real app, this would make an API call
        } else {
            showMessage('Account deletion cancelled.', 'info');
        }
    }
}

// Utility function to show messages
function showMessage(message, type) {
    // Remove existing message
    const existingMessage = document.getElementById('actionMessage');
    if (existingMessage) existingMessage.remove();
    
    // Create new message
    const messageDiv = document.createElement('div');
    messageDiv.id = 'actionMessage';
    messageDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10001;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease;
    `;
    
    if (type === 'success') {
        messageDiv.style.background = '#4CAF50';
    } else if (type === 'error') {
        messageDiv.style.background = '#f44336';
    } else if (type === 'warning') {
        messageDiv.style.background = '#ff9800';
    } else {
        messageDiv.style.background = '#2196F3';
    }
    
    messageDiv.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
        <button onclick="this.parentElement.remove()" style="background: none; border: none; color: white; margin-left: 10px; cursor: pointer;">×</button>
    `;
    
    document.body.appendChild(messageDiv);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (messageDiv.parentElement) {
            messageDiv.remove();
        }
    }, 5000);
}

// Close modal when clicking outside
document.getElementById('profileModal').addEventListener('click', function(e) {
    if (e.target.id === 'profileModal') {
        closeProfileModal();
    }
});

// Add CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    #profileModal > div {
        animation: fadeIn 0.3s ease;
    }
`;
document.head.appendChild(style);






</script>

    <!-- Message Display -->
    <?php if ($message): ?>
    <div class="message <?php echo $message_type; ?>" id="message">
        <div>
            <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo $message; ?>
            <?php if (!empty($success_data['record_id'])): ?>
            <br><small>Record ID: <?php echo $success_data['record_id']; ?></small>
            <?php endif; ?>
        </div>
        <button onclick="document.getElementById('message').style.display='none'">&times;</button>
    </div>
    <?php endif; ?><!-- Stats Overview -->
<div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px; margin: 30px 0;">
    
    <!-- Today's Appointments with Notification -->
    <div class="stat-card" onclick="showAppointments()" 
         style="background: white; border-radius: 15px; padding: 25px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.08); transition: all 0.3s ease; border: 2px solid #e3f2fd; position: relative; overflow: hidden;"
         onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 10px 25px rgba(33, 150, 243, 0.15)'; this.style.borderColor='#2196F3'"
         onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.08)'; this.style.borderColor='#e3f2fd'">
        
        <!-- Notification Badge -->
        <div class="notification-badge" id="appointmentNotification" 
             style="position: absolute; top: 15px; right: 15px; background: #f44336; color: white; font-size: 12px; font-weight: bold; padding: 4px 10px; border-radius: 20px; display: none; animation: pulse 2s infinite;">
            <i class="fas fa-bell"></i> <span id="appointmentBadgeCount">0</span> new
        </div>
        
        <div style="display: flex; align-items: center; gap: 20px;">
            <div style="width: 70px; height: 70px; border-radius: 15px; background: linear-gradient(135deg, #2196F3, #21CBF3); display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-calendar-check" style="font-size: 32px; color: white;"></i>
            </div>
            <div style="flex: 1;">
                <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #6c757d; font-weight: 500;">Today's Appointments</h3>
                <div class="number" style="font-size: 36px; font-weight: 700; color: #2196F3;"><?php echo $today_appointments; ?></div>
                <div style="font-size: 14px; color: #28a745; margin-top: 5px; display: flex; align-items: center; gap: 5px;">
                    <i class="fas fa-clock"></i> Next: 
                    <span id="nextAppointmentTime" style="font-weight: 600;"><?php echo !empty($next_appointment_time) ? $next_appointment_time : 'No upcoming'; ?></span>
                </div>
            </div>
        </div>
        
        <!-- Appointment Notification Modal -->
        <div id="appointmentAlert" style="display: none; position: absolute; bottom: -60px; left: 0; right: 0; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 8px; padding: 10px; margin: 10px; z-index: 10; animation: slideUp 0.3s ease;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-exclamation-triangle" style="color: #ff9800;"></i>
                <span style="font-size: 13px; color: #856404;">You have pending appointments!</span>
                <button onclick="viewPendingAppointments()" style="margin-left: auto; background: #ff9800; color: white; border: none; padding: 4px 12px; border-radius: 4px; font-size: 12px; cursor: pointer;">View</button>
            </div>
        </div>
    </div>
    
    <!-- My Patients with Notification -->
    <div class="stat-card" onclick="showPatients()" 
         style="background: white; border-radius: 15px; padding: 25px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.08); transition: all 0.3s ease; border: 2px solid #e8f5e9; position: relative;"
         onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 10px 25px rgba(76, 175, 80, 0.15)'; this.style.borderColor='#4CAF50'"
         onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.08)'; this.style.borderColor='#e8f5e9'">
        
        <!-- Urgent Patient Badge -->
        <div class="notification-badge" id="patientNotification" 
             style="position: absolute; top: 15px; right: 15px; background: #ff5722; color: white; font-size: 12px; font-weight: bold; padding: 4px 10px; border-radius: 20px; display: none;">
            <i class="fas fa-user-md"></i> <span id="urgentPatientCount">0</span> urgent
        </div>
        
        <div style="display: flex; align-items: center; gap: 20px;">
            <div style="width: 70px; height: 70px; border-radius: 15px; background: linear-gradient(135deg, #4CAF50, #8BC34A); display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-user-injured" style="font-size: 32px; color: white;"></i>
            </div>
            <div style="flex: 1;">
                <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #6c757d; font-weight: 500;">My Patients</h3>
                <div class="number" style="font-size: 36px; font-weight: 700; color: #4CAF50;"><?php echo $total_patients; ?></div>
                <div style="font-size: 14px; color: #2196F3; margin-top: 5px; display: flex; align-items: center; gap: 5px;">
                    <i class="fas fa-user-clock"></i>
                    <span id="waitingPatients" style="font-weight: 600;"><?php echo !empty($waiting_patients) ? $waiting_patients . ' waiting' : '0 waiting'; ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Active Prescriptions with Notification -->
    <div class="stat-card" onclick="showPrescriptions()" 
         style="background: white; border-radius: 15px; padding: 25px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.08); transition: all 0.3s ease; border: 2px solid #fff3e0; position: relative;"
         onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 10px 25px rgba(255, 152, 0, 0.15)'; this.style.borderColor='#FF9800'"
         onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.08)'; this.style.borderColor='#fff3e0'">
        
        <!-- Expiring Prescriptions Badge -->
        <div class="notification-badge" id="prescriptionNotification" 
             style="position: absolute; top: 15px; right: 15px; background: #ff9800; color: white; font-size: 12px; font-weight: bold; padding: 4px 10px; border-radius: 20px; display: none;">
            <i class="fas fa-exclamation-circle"></i> <span id="expiringCount">0</span> expiring
        </div>
        
        <div style="display: flex; align-items: center; gap: 20px;">
            <div style="width: 70px; height: 70px; border-radius: 15px; background: linear-gradient(135deg, #FF9800, #FFB74D); display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-prescription" style="font-size: 32px; color: white;"></i>
            </div>
            <div style="flex: 1;">
                <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #6c757d; font-weight: 500;">Active Prescriptions</h3>
                <div class="number" style="font-size: 36px; font-weight: 700; color: #FF9800;"><?php echo $active_prescriptions; ?></div>
                <div style="font-size: 14px; color: #e74c3c; margin-top: 5px; display: flex; align-items: center; gap: 5px;">
                    <i class="fas fa-hourglass-end"></i>
                    <span id="expiringToday" style="font-weight: 600;"><?php echo !empty($expiring_today) ? $expiring_today . ' expiring today' : 'All valid'; ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Pending Lab Tests with Notification -->
    <div class="stat-card" onclick="showLabTests()" 
         style="background: white; border-radius: 15px; padding: 25px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.08); transition: all 0.3s ease; border: 2px solid #f3e5f5; position: relative;"
         onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 10px 25px rgba(156, 39, 176, 0.15)'; this.style.borderColor='#9C27B0'"
         onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.08)'; this.style.borderColor='#f3e5f5'">
        
        <!-- Lab Results Ready Badge -->
        <div class="notification-badge" id="labTestNotification" 
             style="position: absolute; top: 15px; right: 15px; background: #9C27B0; color: white; font-size: 12px; font-weight: bold; padding: 4px 10px; border-radius: 20px; display: none;">
            <i class="fas fa-vial"></i> <span id="resultsReadyCount">0</span> ready
        </div>
        
        <div style="display: flex; align-items: center; gap: 20px;">
            <div style="width: 70px; height: 70px; border-radius: 15px; background: linear-gradient(135deg, #9C27B0, #BA68C8); display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-flask" style="font-size: 32px; color: white;"></i>
            </div>
            <div style="flex: 1;">
                <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #6c757d; font-weight: 500;">Pending Lab Tests</h3>
                <div class="number" style="font-size: 36px; font-weight: 700; color: #9C27B0;"><?php echo $pending_tests; ?></div>
                <div style="font-size: 14px; color: #2196F3; margin-top: 5px; display: flex; align-items: center; gap: 5px;">
                    <i class="fas fa-hourglass-half"></i>
                    <span id="testStatus" style="font-weight: 600;"><?php echo !empty($tests_in_progress) ? $tests_in_progress . ' in progress' : 'All pending'; ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Medical Records with Notification -->
    <div class="stat-card" onclick="showMedicalRecords()" 
         style="background: white; border-radius: 15px; padding: 25px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.08); transition: all 0.3s ease; border: 2px solid #e0f7fa; position: relative;"
         onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 10px 25px rgba(0, 188, 212, 0.15)'; this.style.borderColor='#00BCD4'"
         onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.08)'; this.style.borderColor='#e0f7fa'">
        
        <!-- New Records Badge -->
        <div class="notification-badge" id="medicalRecordNotification" 
             style="position: absolute; top: 15px; right: 15px; background: #00BCD4; color: white; font-size: 12px; font-weight: bold; padding: 4px 10px; border-radius: 20px; display: none;">
            <i class="fas fa-file-medical-alt"></i> <span id="newRecordsCount">0</span> new
        </div>
        
        <div style="display: flex; align-items: center; gap: 20px;">
            <div style="width: 70px; height: 70px; border-radius: 15px; background: linear-gradient(135deg, #00BCD4, #4DD0E1); display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-file-medical" style="font-size: 32px; color: white;"></i>
            </div>
            <div style="flex: 1;">
                <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #6c757d; font-weight: 500;">Medical Records</h3>
                <div class="number" style="font-size: 36px; font-weight: 700; color: #00BCD4;"><?php echo $medical_records_count; ?></div>
                <div style="font-size: 14px; color: #4CAF50; margin-top: 5px; display: flex; align-items: center; gap: 5px;">
                    <i class="fas fa-calendar-plus"></i>
                    <span id="recentRecords" style="font-weight: 600;"><?php echo !empty($recent_records) ? $recent_records . ' this week' : 'Updated recently'; ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Patient Vitals with Notification -->
    <div class="stat-card" onclick="showVitals()" 
         style="background: white; border-radius: 15px; padding: 25px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.08); transition: all 0.3s ease; border: 2px solid #fce4ec; position: relative;"
         onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 10px 25px rgba(233, 30, 99, 0.15)'; this.style.borderColor='#E91E63'"
         onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(0,0,0,0.08)'; this.style.borderColor='#fce4ec'">
        
        <!-- Critical Vitals Badge -->
        <div class="notification-badge" id="vitalsNotification" 
             style="position: absolute; top: 15px; right: 15px; background: #E91E63; color: white; font-size: 12px; font-weight: bold; padding: 4px 10px; border-radius: 20px; display: none; animation: criticalPulse 1s infinite;">
            <i class="fas fa-heartbeat"></i> <span id="criticalVitalsCount">0</span> critical
        </div>
        
        <div style="display: flex; align-items: center; gap: 20px;">
            <div style="width: 70px; height: 70px; border-radius: 15px; background: linear-gradient(135deg, #E91E63, #F06292); display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-heartbeat" style="font-size: 32px; color: white;"></i>
            </div>
            <div style="flex: 1;">
                <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #6c757d; font-weight: 500;">Patient Vitals</h3>
                <div class="number" style="font-size: 36px; font-weight: 700; color: #E91E63;"><?php echo count($vitals_data); ?></div>
                <div style="font-size: 14px; color: #f44336; margin-top: 5px; display: flex; align-items: center; gap: 5px;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span id="abnormalVitals" style="font-weight: 600;"><?php echo !empty($abnormal_vitals) ? $abnormal_vitals . ' abnormal' : 'All normal'; ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for Functional Notifications -->
<script>
// Notification System - Inline JavaScript
(function() {
    'use strict';
    
    // Notification Configuration
    const NotificationConfig = {
        types: ['appointments', 'patients', 'prescriptions', 'labTests', 'medicalRecords', 'vitals'],
        colors: {
            appointments: '#2196F3',
            patients: '#4CAF50',
            prescriptions: '#FF9800',
            labTests: '#9C27B0',
            medicalRecords: '#00BCD4',
            vitals: '#E91E63'
        },
        icons: {
            appointments: 'calendar-check',
            patients: 'user-injured',
            prescriptions: 'prescription',
            labTests: 'flask',
            medicalRecords: 'file-medical',
            vitals: 'heartbeat'
        },
        pollingInterval: 30000, // 30 seconds
        soundEnabled: true
    };
    
    // State Management
    let notifications = {
        appointments: { count: 0, lastChecked: null },
        patients: { count: 0, lastChecked: null },
        prescriptions: { count: 0, lastChecked: null },
        labTests: { count: 0, lastChecked: null },
        medicalRecords: { count: 0, lastChecked: null },
        vitals: { count: 0, lastChecked: null }
    };
    
    // DOM Elements Cache
    let elements = {};
    
    // Initialize Notification System
    function initNotificationSystem() {
        console.log('Initializing Notification System...');
        
        // Cache DOM elements
        cacheElements();
        
        // Load saved state
        loadNotifications();
        
        // Setup event listeners
        setupEventListeners();
        
        // Setup notification sound
        setupNotificationSound();
        
        // Start polling for new notifications
        startNotificationPolling();
        
        // Show initial notifications
        setTimeout(() => {
            simulateInitialNotifications();
            showAppointmentAlert();
        }, 1000);
        
        // Setup responsive behavior
        setupResponsiveBehavior();
        
        console.log('Notification System initialized successfully');
    }
    
    // Cache DOM elements
    function cacheElements() {
        NotificationConfig.types.forEach(type => {
            const badgeId = `${type}Notification`;
            const countId = type === 'appointments' ? 'appointmentBadgeCount' : 
                           type === 'patients' ? 'urgentPatientCount' :
                           type === 'prescriptions' ? 'expiringCount' :
                           type === 'labTests' ? 'resultsReadyCount' :
                           type === 'medicalRecords' ? 'newRecordsCount' :
                           type === 'vitals' ? 'criticalVitalsCount' : `${type}Count`;
            
            elements[type] = {
                badge: document.getElementById(badgeId),
                count: document.getElementById(countId),
                card: document.querySelector(`.stat-card[onclick*="${getCardFunction(type)}"]`)
            };
        });
        
        elements.appointmentAlert = document.getElementById('appointmentAlert');
        elements.statsGrid = document.querySelector('.stats-grid');
    }
    
    // Get card function name from type
    function getCardFunction(type) {
        const map = {
            appointments: 'showAppointments',
            patients: 'showPatients',
            prescriptions: 'showPrescriptions',
            labTests: 'showLabTests',
            medicalRecords: 'showMedicalRecords',
            vitals: 'showVitals'
        };
        return map[type] || 'show' + type.charAt(0).toUpperCase() + type.slice(1);
    }
    
    // Load notifications from localStorage
    function loadNotifications() {
        try {
            const saved = localStorage.getItem('doctorNotifications');
            if (saved) {
                const parsed = JSON.parse(saved);
                notifications = { ...notifications, ...parsed };
                updateAllBadges();
            }
        } catch (e) {
            console.error('Error loading notifications:', e);
        }
    }
    
    // Save notifications to localStorage
    function saveNotifications() {
        try {
            localStorage.setItem('doctorNotifications', JSON.stringify(notifications));
        } catch (e) {
            console.error('Error saving notifications:', e);
        }
    }
    
    // Setup event listeners
    function setupEventListeners() {
        // Card click handlers
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('click', function(e) {
                if (!e.target.closest('.notification-badge')) {
                    markCardAsRead(this);
                }
            });
            
            // Touch device support
            card.addEventListener('touchstart', function() {
                this.style.transform = 'translateY(-3px)';
            });
            
            card.addEventListener('touchend', function() {
                this.style.transform = 'translateY(0)';
            });
        });
        
        // Notification badge click handlers
        document.querySelectorAll('.notification-badge').forEach(badge => {
            badge.addEventListener('click', function(e) {
                e.stopPropagation();
                const type = this.id.replace('Notification', '');
                showToast(`Viewing ${type} notifications`, type);
            });
        });
        
        // Window resize for responsive behavior
        window.addEventListener('resize', debounce(handleResize, 250));
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Alt + Number to navigate to cards
            if (e.altKey && e.key >= '1' && e.key <= '6') {
                const index = parseInt(e.key) - 1;
                const cards = document.querySelectorAll('.stat-card');
                if (cards[index]) {
                    cards[index].click();
                }
            }
            
            // Escape to clear all notifications
            if (e.key === 'Escape') {
                if (confirm('Clear all notifications?')) {
                    clearAllNotifications();
                }
            }
        });
    }
    
    // Setup responsive behavior
    function setupResponsiveBehavior() {
        const grid = elements.statsGrid;
        if (!grid) return;
        
        // Initial responsive setup
        handleResize();
        
        // Add responsive classes
        if (window.innerWidth <= 768) {
            grid.style.gridTemplateColumns = 'repeat(auto-fit, minmax(250px, 1fr))';
            grid.style.gap = '15px';
        }
    }
    
    // Handle window resize
    function handleResize() {
        const width = window.innerWidth;
        const badges = document.querySelectorAll('.notification-badge');
        
        if (width <= 768) {
            // Mobile adjustments
            badges.forEach(badge => {
                badge.style.fontSize = '10px';
                badge.style.padding = '3px 8px';
            });
            
            // Adjust card padding
            document.querySelectorAll('.stat-card').forEach(card => {
                card.style.padding = '20px 15px';
            });
        } else if (width <= 1024) {
            // Tablet adjustments
            badges.forEach(badge => {
                badge.style.fontSize = '11px';
                badge.style.padding = '4px 9px';
            });
        } else {
            // Desktop - reset to default
            badges.forEach(badge => {
                badge.style.fontSize = '12px';
                badge.style.padding = '4px 10px';
            });
        }
    }
    
    // Debounce function for resize events
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Update all notification badges
    function updateAllBadges() {
        NotificationConfig.types.forEach(type => {
            updateBadge(type);
        });
    }
    
    // Update specific badge
    function updateBadge(type) {
        const data = elements[type];
        if (!data || !data.badge || !data.count) return;
        
        const count = notifications[type].count;
        
        if (count > 0) {
            // Show badge
            data.badge.style.display = 'flex';
            data.count.textContent = count;
            
            // Add appropriate animation
            if (type === 'vitals' && count > 0) {
                data.badge.style.animation = 'criticalPulse 1s infinite';
            } else if (type === 'appointments' && count > 0) {
                data.badge.style.animation = 'pulse 2s infinite';
            } else {
                data.badge.style.animation = 'pulse 3s infinite';
            }
            
            // Add hover effect to card
            if (data.card) {
                data.card.style.borderWidth = '3px';
                data.card.style.boxShadow = `0 0 20px ${NotificationConfig.colors[type]}40`;
            }
        } else {
            // Hide badge
            data.badge.style.display = 'none';
            
            // Remove hover effect from card
            if (data.card) {
                data.card.style.borderWidth = '2px';
                data.card.style.boxShadow = '0 4px 15px rgba(0,0,0,0.08)';
            }
        }
    }
    
    // Add new notification
    function addNotification(type, count = 1, message = '') {
        if (!notifications[type]) return;
        
        // Store old count for animation
        const oldCount = notifications[type].count;
        
        // Update count
        notifications[type].count += count;
        notifications[type].lastChecked = null;
        
        // Update badge
        updateBadge(type);
        
        // Save to storage
        saveNotifications();
        
        // Show toast if message provided
        if (message) {
            showToast(message, type);
        }
        
        // Play sound if new notification
        if (oldCount === 0 && count > 0 && NotificationConfig.soundEnabled) {
            playNotificationSound();
        }
        
        // Log for debugging
        console.log(`Notification added: ${type} (${count}) - Total: ${notifications[type].count}`);
    }
    
    // Mark card as read
    function markCardAsRead(cardElement) {
        const type = getCardTypeFromElement(cardElement);
        if (!type || !notifications[type]) return;
        
        // Only mark as read if there were notifications
        if (notifications[type].count > 0) {
            notifications[type].count = 0;
            notifications[type].lastChecked = new Date().toISOString();
            
            updateBadge(type);
            saveNotifications();
            
            showToast(`${type.charAt(0).toUpperCase() + type.slice(1)} marked as read`, 'success');
        }
    }
    
    // Get card type from element
    function getCardTypeFromElement(element) {
        const onclick = element.getAttribute('onclick') || '';
        const text = element.textContent || '';
        
        if (onclick.includes('Appointments') || text.includes('Appointments')) return 'appointments';
        if (onclick.includes('Patients') || text.includes('Patients')) return 'patients';
        if (onclick.includes('Prescriptions') || text.includes('Prescriptions')) return 'prescriptions';
        if (onclick.includes('Lab') || text.includes('Lab')) return 'labTests';
        if (onclick.includes('Medical') || text.includes('Medical')) return 'medicalRecords';
        if (onclick.includes('Vitals') || text.includes('Vitals')) return 'vitals';
        
        return null;
    }
    
    // Show toast notification
    function showToast(message, type = 'info') {
        // Remove existing toast
        const existingToast = document.getElementById('notificationToast');
        if (existingToast) {
            existingToast.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (existingToast.parentElement) {
                    existingToast.remove();
                }
            }, 300);
        }
        
        // Create new toast
        const toast = document.createElement('div');
        toast.id = 'notificationToast';
        
        const color = NotificationConfig.colors[type] || 
                     (type === 'success' ? '#4CAF50' : 
                      type === 'error' ? '#f44336' : 
                      type === 'warning' ? '#FF9800' : '#2196F3');
        
        const icon = NotificationConfig.icons[type] || 
                    (type === 'success' ? 'check-circle' : 
                     type === 'error' ? 'exclamation-circle' : 
                     type === 'warning' ? 'exclamation-triangle' : 'bell');
        
        toast.style.cssText = `
            position: fixed;
            top: ${window.innerWidth <= 768 ? '70px' : '80px'};
            right: 20px;
            background: ${color};
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
            z-index: 10001;
            animation: slideInRight 0.3s ease;
            max-width: ${window.innerWidth <= 768 ? '280px' : '350px'};
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: ${window.innerWidth <= 768 ? '14px' : '16px'};
        `;
        
        toast.innerHTML = `
            <i class="fas fa-${icon}" style="font-size: ${window.innerWidth <= 768 ? '16px' : '18px'}"></i>
            <span style="flex: 1;">${message}</span>
            <button onclick="this.parentElement.remove()" 
                    style="background: none; border: none; color: white; margin-left: 10px; cursor: pointer; font-size: 20px; padding: 0 5px; opacity: 0.8;">
                ×
            </button>
        `;
        
        document.body.appendChild(toast);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => {
                    if (toast.parentElement) toast.remove();
                }, 300);
            }
        }, 5000);
    }
    
    // Setup notification sound
    function setupNotificationSound() {
        if (!NotificationConfig.soundEnabled) return;
        
        // Create audio context for notification sound
        try {
            window.AudioContext = window.AudioContext || window.webkitAudioContext;
        } catch (e) {
            console.log('Web Audio API not supported');
            NotificationConfig.soundEnabled = false;
        }
    }
    
    // Play notification sound
    function playNotificationSound() {
        if (!NotificationConfig.soundEnabled) return;
        
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);
        } catch (e) {
            console.log('Could not play notification sound');
        }
    }
    
    // Start polling for notifications
    function startNotificationPolling() {
        // Check immediately
        checkForNewNotifications();
        
        // Then check every interval
        setInterval(checkForNewNotifications, NotificationConfig.pollingInterval);
    }
    
    // Check for new notifications (simulated)
    function checkForNewNotifications() {
        const now = new Date();
        const hour = now.getHours();
        const minute = now.getMinutes();
        
        // Simulate morning appointments (8 AM - 12 PM)
        if (hour >= 8 && hour < 12 && minute % 15 === 0) {
            if (Math.random() > 0.7) {
                addNotification('appointments', 1, 'New appointment scheduled');
            }
        }
        
        // Simulate afternoon lab results (2 PM - 5 PM)
        if (hour >= 14 && hour < 17 && minute % 20 === 0) {
            if (Math.random() > 0.8) {
                addNotification('labTests', 1, 'Lab test results ready');
            }
        }
        
        // Simulate patient updates throughout the day
        if (minute % 30 === 0) {
            if (Math.random() > 0.9) {
                addNotification('patients', 1, 'New patient registered');
            }
        }
        
        // Simulate critical vitals (random)
        if (Math.random() > 0.95) {
            addNotification('vitals', 1, 'Critical vitals alert');
        }
        
        // Simulate expiring prescriptions (once per hour)
        if (minute === 0) {
            if (Math.random() > 0.8) {
                addNotification('prescriptions', Math.floor(Math.random() * 3) + 1, 'Prescriptions expiring soon');
            }
        }
    }
    
    // Show appointment alert
    function showAppointmentAlert() {
        if (!elements.appointmentAlert || notifications.appointments.count === 0) return;
        
        elements.appointmentAlert.style.display = 'block';
        
        // Auto hide after 10 seconds
        setTimeout(() => {
            if (elements.appointmentAlert) {
                elements.appointmentAlert.style.display = 'none';
            }
        }, 10000);
    }
    
    // View pending appointments
    function viewPendingAppointments() {
        if (elements.appointmentAlert) {
            elements.appointmentAlert.style.display = 'none';
        }
        
        showToast('Opening pending appointments...', 'appointments');
        markCardAsRead(elements.appointments.card);
        
        // Simulate navigation to appointments
        setTimeout(() => {
            // In real app: window.location.href = '#appointments';
            console.log('Navigating to appointments...');
        }, 500);
    }
    
    // Clear all notifications
    function clearAllNotifications() {
        NotificationConfig.types.forEach(type => {
            notifications[type].count = 0;
            notifications[type].lastChecked = new Date().toISOString();
            updateBadge(type);
        });
        
        saveNotifications();
        showToast('All notifications cleared', 'success');
    }
    
    // Simulate initial notifications for demo
    function simulateInitialNotifications() {
        // Add some initial notifications
        setTimeout(() => addNotification('appointments', 2, '2 new appointments today'), 500);
        setTimeout(() => addNotification('patients', 1, '1 urgent patient waiting'), 1000);
        setTimeout(() => addNotification('vitals', 1, '1 critical vital reading'), 1500);
        setTimeout(() => addNotification('prescriptions', 1, '1 prescription expiring'), 2000);
        
        // Welcome message
        setTimeout(() => {
            showToast('Welcome back, Doctor! Notifications are active.', 'info');
        }, 2500);
    }
    
    // Add CSS animations dynamically
    function addNotificationStyles() {
        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.05); }
                100% { transform: scale(1); }
            }
            
            @keyframes criticalPulse {
                0% { 
                    transform: scale(1); 
                    box-shadow: 0 0 0 0 rgba(233, 30, 99, 0.7);
                }
                70% { 
                    transform: scale(1.1); 
                    box-shadow: 0 0 0 10px rgba(233, 30, 99, 0);
                }
                100% { 
                    transform: scale(1); 
                    box-shadow: 0 0 0 0 rgba(233, 30, 99, 0);
                }
            }
            
            @keyframes slideInRight {
                from { 
                    transform: translateX(100%); 
                    opacity: 0; 
                }
                to { 
                    transform: translateX(0); 
                    opacity: 1; 
                }
            }
            
            @keyframes slideOutRight {
                from { 
                    transform: translateX(0); 
                    opacity: 1; 
                }
                to { 
                    transform: translateX(100%); 
                    opacity: 0; 
                }
            }
            
            @keyframes slideUp {
                from { 
                    transform: translateY(10px); 
                    opacity: 0; 
                }
                to { 
                    transform: translateY(0); 
                    opacity: 1; 
                }
            }
            
            .notification-badge {
                cursor: pointer;
                user-select: none;
                transition: all 0.2s ease;
            }
            
            .notification-badge:hover {
                transform: scale(1.1);
            }
            
            .stat-card {
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }
            
            @media (max-width: 768px) {
                .stats-grid {
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)) !important;
                    gap: 15px !important;
                }
                
                .stat-card {
                    padding: 20px 15px !important;
                }
                
                .stat-icon {
                    width: 60px !important;
                    height: 60px !important;
                }
                
                .number {
                    font-size: 32px !important;
                }
            }
            
            @media (max-width: 480px) {
                .stats-grid {
                    grid-template-columns: 1fr !important;
                }
                
                .stat-card {
                    padding: 18px !important;
                }
                
                .notification-badge {
                    font-size: 10px !important;
                    padding: 2px 8px !important;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Public API
    window.NotificationSystem = {
        init: initNotificationSystem,
        addNotification: addNotification,
        clearAll: clearAllNotifications,
        viewPendingAppointments: viewPendingAppointments,
        showToast: showToast,
        getCount: (type) => notifications[type]?.count || 0
    };
    
    // Card click functions (public)
    window.showAppointments = function() {
        showToast('Loading appointments dashboard...', 'appointments');
        window.NotificationSystem.viewPendingAppointments();
    };
    
    window.showPatients = function() {
        showToast('Opening patients list...', 'patients');
        const card = document.querySelector('.stat-card[onclick*="showPatients"]');
        if (card) markCardAsRead(card);
    };
    
    window.showPrescriptions = function() {
        showToast('Loading prescriptions...', 'prescriptions');
        const card = document.querySelector('.stat-card[onclick*="showPrescriptions"]');
        if (card) markCardAsRead(card);
    };
    
    window.showLabTests = function() {
        showToast('Opening lab tests...', 'labTests');
        const card = document.querySelector('.stat-card[onclick*="showLabTests"]');
        if (card) markCardAsRead(card);
    };
    
    window.showMedicalRecords = function() {
        showToast('Accessing medical records...', 'medicalRecords');
        const card = document.querySelector('.stat-card[onclick*="showMedicalRecords"]');
        if (card) markCardAsRead(card);
    };
    
    window.showVitals = function() {
        showToast('Viewing patient vitals...', 'vitals');
        const card = document.querySelector('.stat-card[onclick*="showVitals"]');
        if (card) markCardAsRead(card);
    };
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            addNotificationStyles();
            window.NotificationSystem.init();
        });
    } else {
        addNotificationStyles();
        window.NotificationSystem.init();
    }
    
})();
</script>
    <!-- Quick Actions -->
    <div class="quick-actions">
        <h2 class="section-title"><i class="fas fa-bolt"></i> system roles</h2>
        <div class="actions-grid">
            <button class="action-btn" onclick="showModal('appointmentsModal')">
                <i class="fas fa-calendar-check"></i>
                <span>My Appointments</span>
            </button>
            
            <button class="action-btn" onclick="showModal('patientsModal')">
                <i class="fas fa-user-injured"></i>
                <span>My Patients</span>
            </button>
            
            <button class="action-btn" onclick="showModal('addPrescriptionModal')">
                <i class="fas fa-prescription"></i>
                <span>Add Prescription</span>
            </button>
            
            <button class="action-btn" onclick="showModal('addMedicalRecordModal')">
                <i class="fas fa-file-medical"></i>
                <span>Add Medical Record</span>
            </button>
            
            <button class="action-btn" onclick="showModal('requestLabTestModal')">
                <i class="fas fa-flask"></i>
                <span>Request Lab Test</span>
            </button>
            
            <button class="action-btn" onclick="showModal('recordVitalsModal')">
                <i class="fas fa-heartbeat"></i>
                <span>Record Vitals</span>
            </button>
            
            <button class="action-btn" onclick="showModal('reportsModal')">
                <i class="fas fa-chart-bar"></i>
                <span>Reports</span>
            </button>
            
            <button class="action-btn" onclick="showModal('medicalRecordsModal')">
                <i class="fas fa-history"></i>
                <span>Medical Records</span>
            </button>
        </div>
    </div>

    <!-- Main Content Grid -->
    <div class="data-grid">
        <!-- Today's Appointments -->
        <div class="data-section">
            <div class="section-header">
                <h3><i class="fas fa-calendar-day"></i> Today's Appointments</h3>
                <button class="btn btn-primary btn-sm" onclick="showModal('appointmentsModal')">View All</button>
            </div>
            <div class="section-content">
                <?php foreach($appointments_data as $appointment): ?>
                <div class="appointment-card">
                    <div class="appointment-time">
                        <?php echo $appointment['time']; ?>
                        <span class="badge badge-<?php echo $appointment['status']; ?>" style="float: right;">
                            <?php echo $appointment['status']; ?>
                        </span>
                    </div>
                    <div class="appointment-patient">
                        <?php echo $appointment['patient_name']; ?>
                    </div>
                    <div class="appointment-reason">
                        <?php echo $appointment['reason']; ?>
                    </div>
                    <div style="margin-top: 10px; display: flex; gap: 10px;">
                        <button class="btn btn-success btn-sm" onclick="startConsultation('<?php echo $appointment['patient_name']; ?>')">
                            <i class="fas fa-play"></i> Start
                        </button>
                        <button class="btn btn-primary btn-sm" onclick="viewPatient('<?php echo $appointment['patient_name']; ?>')">
                            <i class="fas fa-eye"></i> View
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Recent Patients -->
        <div class="data-section">
            <div class="section-header">
                <h3><i class="fas fa-user-injured"></i> Recent Patients</h3>
                <button class="btn btn-primary btn-sm" onclick="showModal('patientsModal')">View All</button>
            </div>
            <div class="section-content">
                <?php foreach($patients_data as $patient): ?>
                <div class="patient-card">
                    <div class="patient-header">
                        <div class="patient-name"><?php echo $patient['name']; ?></div>
                        <span style="color: #666; font-size: 13px;">Age: <?php echo $patient['age']; ?></span>
                    </div>
                    <div class="patient-meta">
                        <span><i class="far fa-calendar"></i> Last Visit: <?php echo $patient['last_visit']; ?></span>
                        <span><i class="fas fa-stethoscope"></i> <?php echo $patient['condition']; ?></span>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button class="btn btn-primary btn-sm" onclick="viewPatient('<?php echo $patient['name']; ?>')">
                            <i class="fas fa-eye"></i> Profile
                        </button>
                        <button class="btn btn-success btn-sm" onclick="startConsultation('<?php echo $patient['name']; ?>')">
                            <i class="fas fa-stethoscope"></i> Consult
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Active Prescriptions -->
        <div class="data-section">
            <div class="section-header">
                <h3><i class="fas fa-prescription"></i> Active Prescriptions</h3>
                <button class="btn btn-primary btn-sm" onclick="showModal('prescriptionsModal')">View All</button>
            </div>
            <div class="section-content">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Patient</th>
                            <th>Medication</th>
                            <th>Dosage</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($prescriptions_data as $prescription): ?>
                        <tr>
                            <td><?php echo $prescription['patient_name']; ?></td>
                            <td><?php echo $prescription['medication']; ?></td>
                            <td><?php echo $prescription['dosage']; ?></td>
                            <td><span class="badge badge-active">Active</span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pending Lab Tests -->
        <div class="data-section">
            <div class="section-header">
                <h3><i class="fas fa-flask"></i> Pending Lab Tests</h3>
                <button class="btn btn-primary btn-sm" onclick="showModal('labTestsModal')">View All</button>
            </div>
            <div class="section-content">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Patient</th>
                            <th>Test Type</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($lab_tests_data as $test): ?>
                        <tr>
                            <td><?php echo $test['patient_name']; ?></td>
                            <td><?php echo $test['test_type']; ?></td>
                            <td><?php echo $test['test_date']; ?></td>
                            <td><span class="badge badge-pending">Pending</span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modals -->

<!-- Appointments Modal -->
<div id="appointmentsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-calendar-check"></i> My Appointments</h3>
            <button class="close-modal" onclick="closeModal('appointmentsModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div style="margin-bottom: 20px;">
                <input type="date" id="appointmentDate" value="<?php echo $today; ?>" class="form-control">
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Patient</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($appointments_data as $appointment): ?>
                    <tr>
                        <td><?php echo $appointment['time']; ?></td>
                        <td><?php echo $appointment['patient_name']; ?></td>
                        <td><?php echo $appointment['reason']; ?></td>
                        <td><span class="badge badge-<?php echo $appointment['status']; ?>"><?php echo $appointment['status']; ?></span></td>
                        <td>
                            <button class="btn btn-success btn-sm" onclick="startConsultation('<?php echo $appointment['patient_name']; ?>')">
                                <i class="fas fa-play"></i> Start
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Patients Modal -->
<div id="patientsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-user-injured"></i> My Patients</h3>
            <button class="close-modal" onclick="closeModal('patientsModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div style="margin-bottom: 20px;">
                <input type="text" id="patientSearch" placeholder="Search patients..." class="form-control">
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Patient</th>
                        <th>Age</th>
                        <th>Last Visit</th>
                        <th>Condition</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($patients_data as $patient): ?>
                    <tr>
                        <td><?php echo $patient['name']; ?></td>
                        <td><?php echo $patient['age']; ?></td>
                        <td><?php echo $patient['last_visit']; ?></td>
                        <td><?php echo $patient['condition']; ?></td>
                        <td>
                            <button class="btn btn-primary btn-sm" onclick="viewPatient('<?php echo $patient['name']; ?>')">
                                <i class="fas fa-eye"></i> View
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Prescription Modal -->
<div id="addPrescriptionModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-prescription"></i> Add Prescription</h3>
            <button class="close-modal" onclick="closeModal('addPrescriptionModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>Patient Name *</label>
                    <select name="patient_name" class="form-control" required>
                        <option value="">Select Patient</option>
                        <?php foreach($patients_data as $patient): ?>
                        <option value="<?php echo $patient['name']; ?>"><?php echo $patient['name']; ?> (Age: <?php echo $patient['age']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Medication Name *</label>
                        <input type="text" name="medication" class="form-control" placeholder="e.g., Amoxicillin" required>
                    </div>
                    <div class="form-group">
                        <label>Dosage *</label>
                        <input type="text" name="dosage" class="form-control" placeholder="e.g., 500mg" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Frequency *</label>
                        <select name="frequency" class="form-control" required>
                            <option value="">Select Frequency</option>
                            <option value="Once daily">Once daily</option>
                            <option value="Twice daily">Twice daily</option>
                            <option value="Three times daily">Three times daily</option>
                            <option value="Every 6 hours">Every 6 hours</option>
                            <option value="Every 8 hours">Every 8 hours</option>
                            <option value="As needed">As needed</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Duration *</label>
                        <input type="text" name="duration" class="form-control" placeholder="e.g., 7 days" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Instructions</label>
                    <textarea name="instructions" class="form-control" rows="3" placeholder="e.g., Take after meals"></textarea>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="button" class="btn" onclick="closeModal('addPrescriptionModal')">Cancel</button>
                    <button type="submit" name="add_prescription" class="btn btn-success">
                        <i class="fas fa-save"></i> Save Prescription
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Medical Record Modal -->
<div id="addMedicalRecordModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-file-medical"></i> Add Medical Record</h3>
            <button class="close-modal" onclick="closeModal('addMedicalRecordModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>Patient Name *</label>
                    <select name="patient_name" class="form-control" required>
                        <option value="">Select Patient</option>
                        <?php foreach($patients_data as $patient): ?>
                        <option value="<?php echo $patient['name']; ?>"><?php echo $patient['name']; ?> (<?php echo $patient['condition']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Visit Date *</label>
                    <input type="date" name="visit_date" value="<?php echo $today; ?>" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Symptoms *</label>
                    <textarea name="symptoms" class="form-control" rows="3" placeholder="Describe patient symptoms..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Diagnosis *</label>
                    <textarea name="diagnosis" class="form-control" rows="3" placeholder="Enter diagnosis..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Treatment *</label>
                    <textarea name="treatment" class="form-control" rows="3" placeholder="Describe treatment plan..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label>Additional Notes</label>
                    <textarea name="notes" class="form-control" rows="2" placeholder="Additional notes..."></textarea>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="button" class="btn" onclick="closeModal('addMedicalRecordModal')">Cancel</button>
                    <button type="submit" name="add_medical_record" class="btn btn-success">
                        <i class="fas fa-save"></i> Save Medical Record
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Request Lab Test Modal -->
<div id="requestLabTestModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-flask"></i> Request Lab Test</h3>
            <button class="close-modal" onclick="closeModal('requestLabTestModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>Patient Name *</label>
                    <select name="patient_name" class="form-control" required>
                        <option value="">Select Patient</option>
                        <?php foreach($patients_data as $patient): ?>
                        <option value="<?php echo $patient['name']; ?>"><?php echo $patient['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Test Type *</label>
                        <select name="test_type" class="form-control" required>
                            <option value="">Select Test</option>
                            <option value="Complete Blood Count (CBC)">Complete Blood Count (CBC)</option>
                            <option value="Blood Sugar Test">Blood Sugar Test</option>
                            <option value="Lipid Profile">Lipid Profile</option>
                            <option value="Liver Function Test">Liver Function Test</option>
                            <option value="Kidney Function Test">Kidney Function Test</option>
                            <option value="Thyroid Test">Thyroid Test</option>
                            <option value="Urine Analysis">Urine Analysis</option>
                            <option value="X-Ray">X-Ray</option>
                            <option value="Ultrasound">Ultrasound</option>
                            <option value="ECG">ECG</option>
                            <option value="MRI Scan">MRI Scan</option>
                            <option value="CT Scan">CT Scan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Test Date *</label>
                        <input type="date" name="test_date" value="<?php echo $today; ?>" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Notes/Special Instructions</label>
                    <textarea name="notes" class="form-control" rows="3" placeholder="Special instructions for the lab..."></textarea>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="button" class="btn" onclick="closeModal('requestLabTestModal')">Cancel</button>
                    <button type="submit" name="request_lab_test" class="btn btn-success">
                        <i class="fas fa-paper-plane"></i> Request Lab Test
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Record Vitals Modal -->
<div id="recordVitalsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-heartbeat"></i> Record Patient Vitals</h3>
            <button class="close-modal" onclick="closeModal('recordVitalsModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label>Patient Name *</label>
                    <select name="patient_name" class="form-control" required>
                        <option value="">Select Patient</option>
                        <?php foreach($patients_data as $patient): ?>
                        <option value="<?php echo $patient['name']; ?>"><?php echo $patient['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Blood Pressure</label>
                        <input type="text" name="blood_pressure" class="form-control" placeholder="e.g., 120/80">
                    </div>
                    <div class="form-group">
                        <label>Heart Rate (bpm)</label>
                        <input type="number" name="heart_rate" class="form-control" placeholder="e.g., 72" min="40" max="200">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Temperature (°C)</label>
                        <input type="number" step="0.1" name="temperature" class="form-control" placeholder="e.g., 36.6" min="35" max="42">
                    </div>
                    <div class="form-group">
                        <label>Weight (kg)</label>
                        <input type="number" step="0.1" name="weight" class="form-control" placeholder="e.g., 70.5" min="20" max="200">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Height (cm)</label>
                        <input type="number" step="0.1" name="height" class="form-control" placeholder="e.g., 175" min="50" max="250">
                    </div>
                    <div class="form-group">
                        <label>BMI</label>
                        <input type="text" id="bmiResult" class="form-control" readonly placeholder="Will calculate automatically">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Notes</label>
                    <textarea name="notes" class="form-control" rows="2" placeholder="Additional notes..."></textarea>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <button type="button" class="btn" onclick="closeModal('recordVitalsModal')">Cancel</button>
                    <button type="submit" name="record_vitals" class="btn btn-success">
                        <i class="fas fa-save"></i> Record Vitals
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reports Modal -->
<div id="reportsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-chart-bar"></i> Generate Reports</h3>
            <button class="close-modal" onclick="closeModal('reportsModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div style="margin-bottom: 30px;">
                <h4 style="color: var(--dark); margin-bottom: 15px;">Select Report Type</h4>
                <div class="form-row">
                    <div class="form-group">
                        <select id="reportType" class="form-control">
                            <option value="">Select Report Type</option>
                            <option value="patient_summary">Patient Summary Report</option>
                            <option value="appointment_stats">Appointment Statistics</option>
                            <option value="prescription_report">Prescription Report</option>
                            <option value="diagnosis_report">Diagnosis Report</option>
                            <option value="revenue_report">Revenue Report</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Start Date</label>
                        <input type="date" id="reportStart" class="form-control" value="<?php echo date('Y-m-01'); ?>">
                    </div>
                    <div class="form-group">
                        <label>End Date</label>
                        <input type="date" id="reportEnd" class="form-control" value="<?php echo $today; ?>">
                    </div>
                </div>
                
                <div style="text-align: center; margin-top: 20px;">
                    <button class="btn btn-primary" onclick="generateReport()">
                        <i class="fas fa-download"></i> Generate Report
                    </button>
                    <button class="btn btn-success" onclick="printReport()" style="margin-left: 10px;">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
            
            <div id="reportResults" style="display: none;">
                <h4 style="color: var(--dark); margin-bottom: 15px;">Report Results</h4>
                <div id="reportContent" style="background: #f8f9fa; padding: 15px; border-radius: 8px; border: 1px solid #ddd;">
                    <!-- Report content will appear here -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Medical Records Modal -->
<div id="medicalRecordsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-history"></i> Medical Records</h3>
            <button class="close-modal" onclick="closeModal('medicalRecordsModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div style="margin-bottom: 20px;">
                <input type="text" id="recordSearch" placeholder="Search records..." class="form-control">
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Patient</th>
                        <th>Diagnosis</th>
                        <th>Treatment</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($medical_records_data as $record): ?>
                    <tr>
                        <td><?php echo $record['visit_date']; ?></td>
                        <td><?php echo $record['patient_name']; ?></td>
                        <td><?php echo substr($record['diagnosis'], 0, 30) . '...'; ?></td>
                        <td><?php echo substr($record['treatment'], 0, 30) . '...'; ?></td>
                        <td>
                            <button class="btn btn-primary btn-sm" onclick="viewRecord('<?php echo $record['id']; ?>')">
                                <i class="fas fa-eye"></i> View
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- View Record Modal -->
<div id="viewRecordModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-file-medical-alt"></i> Medical Record Details</h3>
            <button class="close-modal" onclick="closeModal('viewRecordModal')">&times;</button>
        </div>
        <div class="modal-body" id="recordDetails">
            <!-- Record details will be loaded here -->
        </div>
    </div>
</div>

<script>
// Modal Functions
function showModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

// Auto-hide message after 5 seconds
setTimeout(() => {
    const message = document.getElementById('message');
    if (message) {
        message.style.display = 'none';
    }
}, 5000);

// Doctor Functions
function startConsultation(patientName) {
    if (confirm(`Start consultation with ${patientName}?`)) {
        showNotification(`Consultation started with ${patientName}`, 'success');
        // In real implementation, this would redirect to consultation page
        console.log(`Consultation started with: ${patientName}`);
    }
}

function viewPatient(patientName) {
    showNotification(`Viewing profile of ${patientName}`, 'info');
    // In real implementation, this would show patient details
    alert(`Patient: ${patientName}\n\nThis would show detailed patient information, history, and records.`);
}

function viewRecord(recordId) {
    const recordDetails = document.getElementById('recordDetails');
    recordDetails.innerHTML = `
        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
            <h4 style="color: var(--primary); margin-bottom: 10px;">Medical Record Details</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div><strong>Record ID:</strong> ${recordId}</div>
                <div><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>
                <div><strong>Patient:</strong> Sample Patient</div>
                <div><strong>Doctor:</strong> Dr. <?php echo $doctor_name; ?></div>
            </div>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; color: var(--dark);"><strong>Symptoms:</strong></label>
            <div style="background: white; padding: 10px; border-radius: 5px; border: 1px solid #ddd;">
                Fever, cough, headache, fatigue.
            </div>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; color: var(--dark);"><strong>Diagnosis:</strong></label>
            <div style="background: white; padding: 10px; border-radius: 5px; border: 1px solid #ddd;">
                Viral infection with mild dehydration.
            </div>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; color: var(--dark);"><strong>Treatment:</strong></label>
            <div style="background: white; padding: 10px; border-radius: 5px; border: 1px solid #ddd;">
                Rest, hydration, paracetamol for fever.
            </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px;">
            <button class="btn btn-primary" onclick="printRecord()">
                <i class="fas fa-print"></i> Print Record
            </button>
        </div>
    `;
    showModal('viewRecordModal');
}

function printRecord() {
    const printContent = document.getElementById('recordDetails').innerHTML;
    const originalContent = document.body.innerHTML;
    
    document.body.innerHTML = `
        <html>
            <head>
                <title>Medical Record - Dr. <?php echo $doctor_name; ?></title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    h1 { color: #1976d2; border-bottom: 2px solid #1976d2; padding-bottom: 10px; }
                    .section { margin: 20px 0; }
                    .label { font-weight: bold; color: #333; }
                    .value { margin-left: 10px; }
                </style>
            </head>
            <body>
                <h1>Medical Record</h1>
                ${printContent}
            </body>
        </html>
    `;
    
    window.print();
    document.body.innerHTML = originalContent;
    showModal('viewRecordModal');
}

// Calculate BMI
function calculateBMI() {
    const weight = document.querySelector('input[name="weight"]')?.value;
    const height = document.querySelector('input[name="height"]')?.value;
    
    if (weight && height) {
        const heightM = height / 100;
        const bmi = (weight / (heightM * heightM)).toFixed(1);
        const bmiResult = document.getElementById('bmiResult');
        if (bmiResult) {
            bmiResult.value = bmi;
            
            // Add BMI category
            let category = '';
            if (bmi < 18.5) category = 'Underweight';
            else if (bmi < 25) category = 'Normal';
            else if (bmi < 30) category = 'Overweight';
            else category = 'Obese';
            
            bmiResult.value = `${bmi} (${category})`;
        }
    }
}

// Add BMI calculation to weight and height inputs
document.addEventListener('DOMContentLoaded', function() {
    const weightInput = document.querySelector('input[name="weight"]');
    const heightInput = document.querySelector('input[name="height"]');
    
    if (weightInput) weightInput.addEventListener('input', calculateBMI);
    if (heightInput) heightInput.addEventListener('input', calculateBMI);
});

// Generate Report
function generateReport() {
    const reportType = document.getElementById('reportType').value;
    const startDate = document.getElementById('reportStart').value;
    const endDate = document.getElementById('reportEnd').value;
    
    if (!reportType) {
        alert('Please select a report type');
        return;
    }
    
    const reportContent = document.getElementById('reportContent');
    const reportResults = document.getElementById('reportResults');
    
    // Sample report data
    let reportHTML = `
        <h4 style="color: var(--primary); margin-bottom: 15px;">${getReportTitle(reportType)}</h4>
        <div style="margin-bottom: 15px;">
            <small>Period: ${startDate} to ${endDate}</small><br>
            <small>Generated on: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}</small>
        </div>
    `;
    
    switch(reportType) {
        case 'patient_summary':
            reportHTML += generatePatientSummary();
            break;
        case 'appointment_stats':
            reportHTML += generateAppointmentStats();
            break;
        case 'prescription_report':
            reportHTML += generatePrescriptionReport();
            break;
        default:
            reportHTML += '<p>Report data would appear here.</p>';
    }
    
    reportContent.innerHTML = reportHTML;
    reportResults.style.display = 'block';
}

function getReportTitle(type) {
    const titles = {
        'patient_summary': 'Patient Summary Report',
        'appointment_stats': 'Appointment Statistics Report',
        'prescription_report': 'Prescription Report',
        'diagnosis_report': 'Diagnosis Report',
        'revenue_report': 'Revenue Report'
    };
    return titles[type] || 'Report';
}

function generatePatientSummary() {
    return `
        <table class="data-table">
            <thead>
                <tr>
                    <th>Patient</th>
                    <th>Age</th>
                    <th>Last Visit</th>
                    <th>Total Visits</th>
                    <th>Primary Condition</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>John Doe</td>
                    <td>45</td>
                    <td>2024-01-15</td>
                    <td>12</td>
                    <td>Hypertension</td>
                </tr>
                <tr>
                    <td>Jane Smith</td>
                    <td>38</td>
                    <td>2024-01-10</td>
                    <td>8</td>
                    <td>Diabetes</td>
                </tr>
                <tr>
                    <td>Robert Johnson</td>
                    <td>52</td>
                    <td>2024-01-05</td>
                    <td>15</td>
                    <td>Asthma</td>
                </tr>
            </tbody>
        </table>
        
        <div style="margin-top: 20px; padding: 15px; background: white; border-radius: 8px; border: 1px solid #ddd;">
            <h5 style="color: var(--dark); margin-bottom: 10px;">Summary Statistics</h5>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                <div style="text-align: center;">
                    <div style="font-size: 24px; font-weight: bold; color: var(--primary);">42</div>
                    <div style="font-size: 12px; color: #666;">Total Patients</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 24px; font-weight: bold; color: var(--success);">28</div>
                    <div style="font-size: 12px; color: #666;">Active Patients</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 24px; font-weight: bold; color: var(--warning);">14</div>
                    <div style="font-size: 12px; color: #666;">New This Month</div>
                </div>
            </div>
        </div>
    `;
}

function generateAppointmentStats() {
    return `
        <div style="margin-bottom: 20px;">
            <h5 style="color: var(--dark); margin-bottom: 10px;">Appointment Statistics</h5>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="text-align: center; padding: 15px; background: white; border-radius: 8px; border: 1px solid #ddd;">
                    <div style="font-size: 24px; font-weight: bold; color: var(--primary);">8</div>
                    <div style="font-size: 12px; color: #666;">Today's Appointments</div>
                </div>
                <div style="text-align: center; padding: 15px; background: white; border-radius: 8px; border: 1px solid #ddd;">
                    <div style="font-size: 24px; font-weight: bold; color: var(--success);">42</div>
                    <div style="font-size: 12px; color: #666;">This Month</div>
                </div>
                <div style="text-align: center; padding: 15px; background: white; border-radius: 8px; border: 1px solid #ddd;">
                    <div style="font-size: 24px; font-weight: bold; color: var(--warning);">12</div>
                    <div style="font-size: 12px; color: #666;">Pending</div>
                </div>
                <div style="text-align: center; padding: 15px; background: white; border-radius: 8px; border: 1px solid #ddd;">
                    <div style="font-size: 24px; font-weight: bold; color: var(--danger);">3</div>
                    <div style="font-size: 12px; color: #666;">Cancelled</div>
                </div>
            </div>
        </div>
    `;
}

function generatePrescriptionReport() {
    return `
        <table class="data-table">
            <thead>
                <tr>
                    <th>Prescription ID</th>
                    <th>Patient</th>
                    <th>Medication</th>
                    <th>Dosage</th>
                    <th>Frequency</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>RX-001</td>
                    <td>John Doe</td>
                    <td>Lisinopril</td>
                    <td>10mg</td>
                    <td>Once daily</td>
                    <td><span class="badge badge-active">Active</span></td>
                </tr>
                <tr>
                    <td>RX-002</td>
                    <td>Jane Smith</td>
                    <td>Metformin</td>
                    <td>500mg</td>
                    <td>Twice daily</td>
                    <td><span class="badge badge-active">Active</span></td>
                </tr>
                <tr>
                    <td>RX-003</td>
                    <td>Robert Johnson</td>
                    <td>Albuterol</td>
                    <td>2 puffs</td>
                    <td>As needed</td>
                    <td><span class="badge badge-active">Active</span></td>
                </tr>
            </tbody>
        </table>
    `;
}

function printReport() {
    const reportContent = document.getElementById('reportContent').innerHTML;
    const originalContent = document.body.innerHTML;
    
    document.body.innerHTML = `
        <html>
            <head>
                <title>Medical Report - Dr. <?php echo $doctor_name; ?></title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    h1 { color: #1976d2; }
                    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                </style>
            </head>
            <body>
                <h1>Medical Report - Dr. <?php echo $doctor_name; ?></h1>
                ${reportContent}
            </body>
        </html>
    `;
    
    window.print();
    document.body.innerHTML = originalContent;
}

// Notification system
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `message ${type}`;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '1001';
    notification.style.minWidth = '300px';
    notification.innerHTML = `
        <div>
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
            ${message}
        </div>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 3000);
}

// Initialize date inputs
document.addEventListener('DOMContentLoaded', function() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        if (!input.value) {
            input.value = '<?php echo $today; ?>';
        }
        input.min = '2023-01-01';
        input.max = '<?php echo date('Y-m-d', strtotime('+1 year')); ?>';
    });
    
    // Initialize time input
    const timeInputs = document.querySelectorAll('input[type="time"]');
    timeInputs.forEach(input => {
        if (!input.value) {
            const now = new Date();
            input.value = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
        }
    });
});
</script>

</body>
</html>